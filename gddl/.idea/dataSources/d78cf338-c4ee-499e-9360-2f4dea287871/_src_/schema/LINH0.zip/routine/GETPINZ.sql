create Function getPinz   (zhilbid In Number)
Return  Varchar2 As
Begin
	Declare
		lvs_pinz Varchar2(10);
		Begin
			Select p.pinz
      Into lvs_pinz
      From fahb f,ranlpzb p
      Where f.ranlpzb_id = p.Id
      And f.zhilb_id = zhilbid;
			Return  lvs_pinz;
		Exception When Others Then
			Return '';
		End;
End;

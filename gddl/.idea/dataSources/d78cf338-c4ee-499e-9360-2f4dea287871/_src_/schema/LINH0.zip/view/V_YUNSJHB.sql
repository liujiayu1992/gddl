create view V_YUNSJHB as
select  '是' as bucjh,
id, riq, diancxxb_id, meikxxb_id, jihkjb_id, ranlpzb_id, yunsfsb_id, faz_id, daoz_id, ches, duns, xingh, dunj, yuantc, yuantd, pic, pid, pizh, fahrq, daohrq, biaoz, beiz
from yunsjhb

union

select  '否' as bucjh,
id, riq, diancxxb_id, meikxxb_id, jihkjb_id, ranlpzb_id, yunsfsb_id, faz_id, daoz_id, ches, duns, xingh, dunj, yuantc, yuantd, pic, pid, pizh, fahrq, daohrq, biaoz, beiz
from yunsbcjhb


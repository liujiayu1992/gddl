create view VWCHEBJWCQK as
select a.nianf,a.yuef,a.changbb_id,a.jianc,'本月' as xiangm,
	a.hetmj,a.jiescbj,a.jiescbj - a.tjiescbj as tb,a.jiescbj - a.hjiescbj as hb
	from (select c.nianf,c.yuef,c.changbb_id,f.jianc ,c.hetmj,c.jiescbj,
	nvl((select daohl from hetlwcqkfkb where nianf = c.nianf and yuef = c.yuef
	and changbb_id = c.changbb_id and fahdwb_id = c.fahdwb_id),0) daohl,
	nvl((select jiescbj from chebjfxb where nianf+1 =c.nianf and yuef = c.yuef
	and changbb_id = c.changbb_id and fahdwb_id = c.fahdwb_id),0) tjiescbj,
	nvl((select daohl from hetlwcqkfkb where nianf+1 = c.nianf and yuef = c.yuef
	and changbb_id = c.changbb_id and fahdwb_id = c.fahdwb_id),0) tdaohl,
	nvl((select jiescbj from chebjfxb where nianf =decode(c.yuef,1,c.nianf-1,c.nianf)
	and yuef = decode(c.yuef,1,12,c.yuef-1)
	and changbb_id = c.changbb_id and fahdwb_id = c.fahdwb_id),0) hjiescbj,
	nvl((select daohl from hetlwcqkfkb where nianf =decode(c.yuef,1,c.nianf-1,c.nianf)
	and yuef = decode(c.yuef,1,12,c.yuef-1)
	and changbb_id = c.changbb_id and fahdwb_id = c.fahdwb_id),0) hdaohl
	from chebjfxb c,fahdwb f where c.fahdwb_id =f.id ) a
	union
	select a.nianf,a.yuef,a.changbb_id,a.jianc,'累计' as xiangm,
	a.hetmj,a.jiescbj,a.jiescbj - a.tjiescbj as tb,a.jiescbj - a.hjiescbj as hb
	from (select c.nianf,c.yuef,c.changbb_id,f.jianc,
	nvl((select sum(hetmj)/count(id) from chebjfxb where nianf = c.nianf and yuef <= c.yuef
	and changbb_id = c.changbb_id and fahdwb_id = c.fahdwb_id),0) hetmj,
	nvl((select sum(jiescbj)/count(id) from chebjfxb where nianf = c.nianf and yuef <= c.yuef
	and changbb_id = c.changbb_id and fahdwb_id = c.fahdwb_id),0) jiescbj,
	nvl((select sum(jiescbj)/count(id) from chebjfxb where nianf+1 = c.nianf and yuef <= c.yuef
  and changbb_id = c.changbb_id and fahdwb_id = c.fahdwb_id),0) tjiescbj,
  nvl((select sum(jiescbj)/count(id) from chebjfxb where nianf =decode(c.yuef,1,c.nianf-1,c.nianf)
  and yuef = decode(c.yuef,1,12,c.yuef-1) and changbb_id = c.changbb_id
  and fahdwb_id = c.fahdwb_id),0) hjiescbj from chebjfxb c,fahdwb f where c.fahdwb_id = f.id) a


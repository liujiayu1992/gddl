create PROCEDURE UPyunsshulb(v_id IN NUMBER,v_jingz in number,v_fenx in varchar2,
v_yuetjkjbid IN NUMBER,v_yuns out number ) IS
BEGIN

 DECLARE

 flag varchar2(50);

  BEGIN

  flag :='false';

  select nvl( ( select zhi from xitxxb where mingc='需计算运损供货单位' and leib='月报' and zhuangt=1 and zhi=gongysb_id),'false') into flag from yuetjkjb where id=v_yuetjkjbid ;

  if flag='false' then
  v_yuns:=0;
  return;
  end if;

  if  v_fenx='本月' then

    select
     round_new( nvl(v_jingz*(select zhi from xitxxb where mingc='默认运损率' and danw='火车' and leib='数量'),0),0)
     into  v_yuns from dual;
  end if;

   if v_fenx='累计' then

    select

   (
    select sum(nvl(yuns,0)) from (
      select yuns from yueslb where yuetjkjb_id=v_yuetjkjbid  and fenx='本月'
      union
      select yuns from yueslb where yuetjkjb_id= ( select id from yuetjkjb where
      riq= Add_Months( ( select k.riq from yuetjkjb k where k.id=v_yuetjkjbid  ),-1)
      and gongysb_id=( select k.gongysb_id from yuetjkjb k where k.id=v_yuetjkjbid )
      and diancxxb_id=( select k.diancxxb_id from yuetjkjb k where k.id=v_yuetjkjbid)  and fenx='累计' )  )

    )  into v_yuns  from dual;



   end if;



  return ;

  END;

END UPyunsshulb;

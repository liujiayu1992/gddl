create trigger TRIGGER_MEIKXXB
	before insert or update or delete
	on MEIKXXB
	for each row
Declare
     v_changbb_id changbb.id%Type;
Begin
     if inserting  and substr(:new.meikbm,1,1)='N' then
           select min(id)  into v_changbb_id  from changbb;
           AddInterfaceTask ('gongysmksqb',:new.id,0,v_changbb_id,'xml',:new.id,sysdate);
     elsif deleting and substr(:new.meikbm,1,1)='N' then
           select min(id)  into v_changbb_id  from changbb;
           AddInterfaceTask ('gongysmksqb',:old.id,1,v_changbb_id,'xml',:old.id,sysdate);
     elsif updating   and substr(:new.meikbm,1,1)='N' then
           if  :new.meikdwmc<>:old.meikdwmc or
                :new.meikdwqc<>:old.meikdwqc or
                :new.meikdqb_id<>:old.meikdqb_id then
                select min(id)  into v_changbb_id  from changbb;
                AddInterfaceTask ('gongysmksqb',:new.id,2,v_changbb_id,'xml',:new.id,sysdate);
           end if ;
     end if;
    exception
       when others then
        if inserting then
           zengjrz('trigger_meikxxb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_meikxxb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_meikxxb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
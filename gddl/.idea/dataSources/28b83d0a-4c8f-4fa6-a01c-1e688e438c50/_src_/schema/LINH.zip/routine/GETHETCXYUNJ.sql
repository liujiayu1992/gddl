create FUNCTION        "GETHETCXYUNJ" (v_hetb_id number)--caolin合同查询用
Return  number as
begin
     declare
     v_yunj number;
     begin
          select max(decode(danwb.bianm,'元/千卡',round(yunj*hetjgb.xiax,2),yunj))jiag
            into v_yunj
            from hetjgb,danwb
            where hetjgb.xiax =(
            select max(xiax)shangx
            from hetjgb,zhibb
            where hetb_id=v_hetb_id and hetjgb.zhibb_id=zhibb.id
            ) and  hetb_id=v_hetb_id and hetjgb.jijdwid=danwb.id;
            return v_yunj;
     end;
end;

 
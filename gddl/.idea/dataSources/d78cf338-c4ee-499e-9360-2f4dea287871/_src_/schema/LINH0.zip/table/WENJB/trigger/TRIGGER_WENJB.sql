create trigger TRIGGER_WENJB
	before insert or update or delete
	on WENJB
	for each row
Declare
   changbb_id number ;   
Begin
     if inserting    then
       select id into changbb_id from changbb where diancxxb_id=:new.diancxxb_id;
           AddInterfaceTask ('jjfxwjb',:new.id,0,changbb_id,'xml',:new.id,:new.riq);
     elsif deleting then
       select id into changbb_id from changbb where diancxxb_id=:new.diancxxb_id;
           AddInterfaceTask ('jjfxwjb',:old.id,1,changbb_id,'xml',:old.id,:old.riq);
     elsif updating then
       select id into changbb_id from changbb where diancxxb_id=:new.diancxxb_id;
           AddInterfaceTask ('jjfxwjb',:new.id,2,changbb_id,'xml',:new.id,:new.riq);
     end if;
    exception
       when others then
        if inserting then
           zengjrz('trigger_wenjb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_wenjb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_wenjb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;

create view SCYB as
select a.riq as riq,biaomdjhs,biaomdj ,m.jingmjg as jingmjg,m.jingmjghs as jingmjghs,p.cunyl as cunyl
from
(select to_date(nianf||'-'||yuef,'yyyy-mm') as riq from CHENGBMXYBB c
 where c.jihkj = '全厂'
   and c.fahdw = '全厂'
   and c.dangyjlj = '本月'
 union
 select distinct riq from Pandcyb) a,
(select c.biaomdj as biaomdjhs,
       round_new(decode(rucrz,
                        0,
                        0,
                        (zonghj - zengzs - nvl(kuangyfs, 0) - yunfse) *
                        29.271 / rucrz),
                 2) as biaomdj,
       c.meij as jingmjg,
       c.zengzs+c.meij as jingmjghs,
       to_date(nianf||'-'||yuef,'yyyy-mm') as riq
  from CHENGBMXYBB c
 where c.jihkj = '全厂'
   and c.fahdw = '全厂'
   and c.dangyjlj = '本月') m,
   (select sum(cunyl) cunyl,riq from Pandcyb group by riq) p
where a.riq = m.riq(+)
and a.riq = p.riq(+)


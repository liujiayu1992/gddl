create function GetHuaybmFromZhilId(lngZhilb_ID number) return varchar2 is
  Result varchar2(2000);
begin
  DECLARE
    v_mingc varchar2(200);
    CURSOR h_bm IS
    select zm.bianm
          from zhuanmb zm, zhuanmlb lb,zhillsb ls
          where lb.mingc='化验编码'
          and zm.zhuanmlb_id=lb.id
          and zm.zhillsb_id=ls.id
          and ls.zhilb_id=lngZhilb_ID;
  BEGIN
    OPEN h_bm;
      loop
        FETCH h_bm INTO v_mingc;
        EXIT WHEN h_bm %NOTFOUND;
        if Result is null then
           Result :=v_mingc;
        else
           Result := Result|| ','|| v_mingc ;
        end if;
      end loop;
    CLOSE h_bm;
    return(Result);
  END;
end GetHuaybmFromZhilId;

create FUNCTION        "DAYCOUNT" (datDate in date) return number is
begin
  return to_char(last_day(datDate),'dd');
end daycount;

 
create view VWJIESXX as
select
--  基础信息
j.id as jiesb_id                    --  结算表id
,j.yansbh                           --  验收编号                  （托收号）
,d.id as diancxxb_id                --  电厂信息表id
,d.jianc as diancmc                 --  电厂名称
,dq.id as meikdqb_id                --  煤矿地区表id              （二级单位）
,dq.meikdqmc as meikdqmc            --  煤矿地区名称
,m.id as meikxxb_id                 --  煤矿信息表id              （三级单位）
,m.meikdwmc                         --  煤矿单位名称
,j.jiesbh                           --  结算编号
,j.chezxxb_id                       --  车站信息id                （代表车站）
,j.pinz                             --  品种                      （字符串）
,j.ches                             --  车数                      （字符串）
,c.ches as cheps                    --  车皮数                    （数量）
,j.jiesrq                           --  结算日期
,j.fahksrq                          --  发货开始日起
,j.fahjzrq                          --  发货截止日期
,j.daibcc                           --  代表车次
,j.fapbh                            --  发票编号
,j.yuanshr                          --  原收货人
,j.kaisysrq                         --  开始验收日期
,j.jiesysrq                         --  结束验收日期
,j.shoukdw                          --  收款单位
,j.kaihyh                           --  开户银行
,j.zhangh                           --  帐号
,j.duifdd                           --  兑付地点
,j.fukfs                            --  付款方式
,j.ranlbmjbr                        --  燃料部门经办人
,j.ranlbmjbrq                       --  燃料部门经办日期
,j.changcwjbr                       --  厂财务经办人
,j.changcwjbrq                      --  厂财务经办日期
,j.ruzrq                            --  入帐日期
,j.jieszxjbr                        --  结算中心经办人
,j.jieszxjbrq                       --  结算中心经办日期
,j.gongsrlbjbr                      --  公司燃料部经办人
,j.gongsrlbjbrq                     --  公司燃料部经办日期
,j.beiz                             --  备注
,j.daxje                            --  大写金额
,j.jizlx                            --  机组类型                  （自己填的一项数据）

--  质价标准
          --  数量
,j.jiessl                           --  结算数量

,j.gongfsl                          --  供方数量
,j.yanssl                           --  验收数量
,j.shulzjbz                         --  数量折价标准              （单价）
,j.shulzjje                         --  数量折价金额
,j.yingk                            --  盈亏
,j.yingd                            --  盈吨
,j.kuid                             --  亏吨
,j.kuidjf                           --  亏吨拒付
          --  热量
,j.relsx                            --  热量上限                  （大卡）
,j.relxx                            --  热量下限                  （大卡）
,j.gongfrl                          --  供方热量                  （大卡）
,j.yansrl                           --  验收热量                  （大卡）
,j.yingkrl                          --  盈亏热量                  （大卡）
,j.relzjbz                          --  热量折价标准              （单价）
,j.relzjje                          --  热量折价金额
          --  水分
,j.shuifsx                          --  水分上限
,j.shuifxx                          --  水分下限
,j.yanssf                           --  验收水分
,j.shuifzjbz                        --  水分折价标准              （单价）
,j.shuifzjje                        --  水分折价金额
          --  硫分
,j.liusx                            --  硫上限
,j.liuxx                            --  硫下限
,j.gongfl                           --  供方硫
,j.yansl                            --  验收硫
,j.liuzjbz                          --  硫折价标准                （单价）
,j.liuzjje                          --  硫折价金额
          --  灰分
,j.huifsx                           --  灰分上限
,j.huifxx                           --  灰分下限
,j.yanshf                           --  验收灰分
,j.huifzjbz                         --  灰分折价标准              （单价）
,j.huifzjje                         --  灰分折价金额
          --  挥发分
,j.huiffsx                          --  挥发分上限
,j.huiffxx                          --  挥发分下限
,j.yanshff                          --  验收挥发分
,j.huiffzjbz                        --  挥发分折价标准            （单价）
,j.huiffzjje                        --  挥发分折价金额
          --  灰熔点
,j.gongfhrd                         --  供方灰熔点
,j.yanshrd                          --  验收灰熔点
,j.huirdzjbz                        --  灰熔点折价标准            （单价）
,j.huirdzjje                        --  灰熔点折价金额

--价款信息
,j.hetjg                            --  合同价格
,j.jiskc                            --  计税扣除                  （其他扣款，用户自己维护）
          --  煤款
,j.hej                              --  合计                      （煤款运费合计 含税）
,j.jiasje                           --  价税金额                  （含税价）
,j.jiakje                           --  价款金额                  （不含税价款）
,j.jiakhj                           --  价款合计                  （不含税价款，与价款合计一样）
,j.jiaksk                           --  税款
,j.jiaksl                           --  价款税率
          --  运费
,j.yunzfhj                          --  运杂费合计                （所有运费+所有运杂费  下面的项目相加  含税）
,j.tielyf                           --  铁路运费                  （含税）
,j.buhsyf                           --  不含税运费                （铁路运费不含税）
,j.yunfsl                           --  运费税率
,j.yunfsk                           --  运费税款
,j.zaf                              --  杂费                      （发站杂费，到站杂费）
,j.kuangqyf                         --  矿区运费
,j.qicyf                            --  汽车运费
,j.qitkkje                          --  其它扣款金额
,c.daozzf                           --  到站杂费
,(j.zaf - c.daozzf) as fazzf        --  发站杂费
          --  单价
,(case when j.jiessl > 0 then round(j.jiasje/j.jiessl,8) else 0 end) as danj     --  含税单价
,(case when j.jiessl > 0 then round(j.jiakje/j.jiessl,8) else 0 end) as buhsdj   --  不含税单价
,(case when j.jiessl > 0 then round(j.tielyf/j.jiessl,8) else 0 end) as yunfdj   --  含税运费单价
,(case when j.jiessl > 0 then round(j.buhsyf/j.jiessl,8) else 0 end) as buhsyfdj   --  含税运费单价
,(case when j.jiessl > 0 then round(c.daozzf/j.jiessl,8) else 0 end) as daozzfdj   --  到站杂费单价
,(case when j.jiessl > 0 then round((j.zaf-c.daozzf)/j.jiessl,8) else 0 end) as fazzfdj  --  发站杂费单价
,(case when j.jiessl > 0 then round(j.kuangqyf/j.jiessl,8) else 0 end) as kuangyfdj      --  矿运费单价
,(case when j.jiessl > 0 then round(j.qitkkje/j.jiessl,8) else 0 end) as qitzfdj         --  其它杂费单价
,(case when j.jiessl > 0 then round(j.qicyf/j.jiessl,8) else 0 end) as qicyfdj           --  汽车运费单价
,( case when j.YANSRL >0 and j.JIESSL>0 then round(((j.HEJ/j.JIESSL)
*7000/j.YANSRL),2) else 0 end) as biaomdj                            --    标煤单价
,( case when j.YANSRL >0 and j.JIESSL>0 then round((((j.HEJ-j.JIAKSK -
j.YUNFSK)/j.JIESSL)*7000/j.YANSRL),2) else 0 end) as biaomdjbhs      --    标煤单价不含税
,(case when j.JIESSL>0 then round(j.hej/j.jiessl,2) else 0 end) as zonghmj       --    综合煤价(天然煤价)
,(case when j.JIESSL>0 then round((j.hej-j.jiaksk-j.yunfsk)/j.jiessl,2) else 0 end) as zonghmjbhs           --    综合煤价不含税
,(case when j.jiessl>0 and j.yansrl>0 then round((j.hej*100/j.jiessl/j.yansrl),2) else 0 end) as jij          --    基价
--  未用到
,j.bukyqjk                          --  补扣以前价款          （上次结算时遗留账目）
,j.bukyqyzf                         --  补扣以前运杂费        （上次结算时遗留账目）
,j.yunzf                            --  运杂费                （未用数据）
,j.qityf                            --  其它运费              （未用数据）
,j.qitkk                            --  其它扣款              （未用数据）
,j.yinhs                            --  印花税                （未用数据）
,j.zhilbz                           --  质量标准              （未用数据）
,j.jieslx                           --  结算类型              （未用数据）
,j.guot                             --  国铁                  （未用数据）
,j.dit                              --  地铁                  （未用数据）
,j.guotyf                           --  国铁运费              （未用数据）
,j.dityf                            --  地铁运费              （未用数据）
,j.zhuanxyf                         --  专线运费              （未用数据）
,j.duantyf                          --  短途运费              （未用数据）
,j.fujf                             --  附加费                （未用数据）
,j.shifyfje                         --  实付运费金额          （未用数据）
,j.qitj                             --  其它价                （未用数据）
,j.dianfj                           --  垫付价                （未用数据）
,j.fengs                            --  不知道                （未用数据）
,j.chuz                             --  不知道                （未用数据）
,j.daok                             --  不知道                （未用数据）
,j.qityfdj                          --  其它运费单价          （未用数据）
,j.quscdj                           --  取送车单价            （未用数据）
,j.biangfdj                         --  变更费单价            （未用数据）
,j.qityzfdj                         --  其它运杂费单价        （未用数据）
,j.jiesbm                           --  结算编码              （未用数据）
,j.yunj                             --  运价                  （未用数据）

from jiesb j , meikxxb m, diancxxb d , meikdqb dq
, (select jiesb_id,count(*) as ches,(round_new(sum(cpb.biaoz),0)+
round_new(sum(cpb.yingd),0) - round_new(sum(cpb.kuid),0))*sum(dzdj.dj) as daozzf from chepb cpb,
(select f.id, case when sum(dzf.zhi) >0 then round_new(sum(f.biaoz+f.yingd-f.kuid)/sum(dzf.zhi),7)
else 0 end as dj
from daozzfb dzf, fahb f  where dzf.fahb_id = f.id group by f.id) dzdj
where cpb.fahb_id = dzdj.id group by jiesb_id) c
where j.diancxxb_id = d.id and j.meikxxb_id = m.id
and m.meikdqb_id = dq.id  and c.jiesb_id = j.id
WITH READ ONLY


 --select * from daozzfb  --需按车皮分摊
 --select * FROM jieszbb


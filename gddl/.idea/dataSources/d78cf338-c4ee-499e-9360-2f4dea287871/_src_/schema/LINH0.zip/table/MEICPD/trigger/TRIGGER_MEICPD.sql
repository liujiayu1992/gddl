create trigger TRIGGER_MEICPD
	before insert or update or delete
	on MEICPD
	for each row
Declare
       v_renwbs number;
Begin

     if inserting then
         select id into v_renwbs --如果没有总表则不发出任何任务
         from panmyqkbgzb where to_char(riq,'yyyymmdd')=to_char(:new.riq,'yyyymmdd') and changbb_id=:new.changbb_id;
          AddInterfaceTask ('pandtjb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);

     elsif deleting then
         select id into v_renwbs
         from panmyqkbgzb where to_char(riq,'yyyymmdd')=to_char(:old.riq,'yyyymmdd') and changbb_id=:old.changbb_id;
          AddInterfaceTask ('pandtjb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);

     elsif updating then
         select id into v_renwbs
         from panmyqkbgzb where to_char(riq,'yyyymmdd')=to_char(:old.riq,'yyyymmdd') and changbb_id=:old.changbb_id;
          AddInterfaceTask ('pandtjb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_meicpd',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_meicpd',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_meicpd',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
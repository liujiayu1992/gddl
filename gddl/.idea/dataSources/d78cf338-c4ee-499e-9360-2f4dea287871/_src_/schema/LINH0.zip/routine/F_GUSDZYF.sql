create function f_gusdzyf(fah_id in long) return number is
  rtn number;
begin
  Select g.Yingdyf+g.Daozzf Into rtn
  From fahgjb g
  Where g.Fahb_Id = fah_id;
  return(rtn);
    exception
      when no_data_found then
         rtn := 0;
         return(rtn);
      when others then
         rtn := 0;
         return(rtn);
end f_gusdzyf;
create FUNCTION getChezxx2 (fahdwbid NUMBER,niand NUMBER,yued NUMBER) return VARCHAR2 is
begin
    declare
      fazs VARCHAR2(1000) :='';
      v_loopcounter integer :=1;
      CURSOR my_cursor IS
       select distinct chezxxb.jianc
                    from fahb,( Select h.Id As meijb_id, v.Id As fahdwb_id
From Hetxxb h,Vwfahdwqc v
Where h.Meikdqfdw_Id = v.Id)
                    gonghs ,chepb ,chezxxb,meikxxb
                    where
                        chezxxb.id=fahb.faz_id
                       and chepb.fahb_id=fahb.id
                       and  gonghs.meijb_id=fahb.meijb_id

                       and to_char(chepb.guohsj,'YYYY')=niand
                       and to_number(to_char(chepb.guohsj,'MM'))=yued
                       and fahb.hedbz=1
                       and gonghs.fahdwb_id=fahdwbid
                       and meikxxb.id=fahb.meikxxb_id
                       and meikxxb.tongjbz=1
                    ;
      my_rec my_cursor%ROWTYPE;
    begin

      OPEN my_cursor;
        LOOP
          FETCH my_cursor INTO my_rec;
            EXIT WHEN my_cursor%NOTFOUND;
          IF v_loopcounter = 1 THEN
            fazs := my_rec.jianc;
          ELSE
            fazs := fazs|| ',' ||my_rec.jianc;
          END IF;
          v_loopcounter := v_loopcounter + 1;
        END LOOP;
      CLOSE my_cursor;
      RETURN fazs;
    END;
END;

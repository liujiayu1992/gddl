create trigger TRIGGER_RANLKCQK
	before insert or update or delete
	on RANLKCQK
	for each row
Begin
     if inserting then
        if :new.pinz='油' then
          AddInterfaceTask ('shouhcrbyb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);
        end if;
     elsif deleting then
        if :old.pinz='油' then
          AddInterfaceTask ('shouhcrbyb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);
        end if;
     elsif updating then
         if :old.pinz='油' then
           if :new.benrkc<>:old.benrkc  then
              AddInterfaceTask ('shouhcrbyb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
           end if ;
         end if;
     end if;
    exception
    when others then
        if inserting then
           zengjrz('trigger_ranlkcqk',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_ranlkcqk',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_ranlkcqk',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
create view VWRULRCRZWCQK as
select nianf,yuef,changbb_id,'本月' as xiangm,rucmrz,nvl(trucmrz,0) trc ,nvl(rucmrz-trucmrz,0) ruczzl,
	round_new(decode(trucmrz,null,100,0,100,(rucmrz-trucmrz)*100/trucmrz),2) rucmrzlv,
	rulmrz,nvl(trulmrz,0) trl,nvl(rulmrz-trulmrz,0) as rulzzl,
	round_new(decode(trulmrz,null,100,0,100,(rulmrz-trulmrz)*100/trulmrz),2) rulmrzlv,
	rezc,nvl(rezc-trezc,0) as czzl from
	(select nianf,yuef,changbb_id,rucmrz*1000 rucmrz,rulmrz*1000 rulmrz,rezc*1000 rezc,
	nvl((select rucmrz*1000 from yuedfxsj where nianf + 1=b.nianf
	and yuef = b.yuef and changbb_id = b.changbb_id),0) trucmrz,
  nvl((select rulmrz*1000 from yuedfxsj where nianf+1=b.nianf
  and yuef = b.yuef and changbb_id = b.changbb_id),0) trulmrz,
  nvl((select rezc*1000 from yuedfxsj where nianf+1=b.nianf
  and yuef = b.yuef and changbb_id = b.changbb_id),0) trezc
   from yuedfxsj b) union
  select nianf,yuef,changbb_id,'累计' as xiangm,rucmrz,nvl(trucmrz,0) trc ,nvl(rucmrz-trucmrz,0) ruczzl,
  round_new(decode(trucmrz,null,100,0,100,(rucmrz-trucmrz)*100/trucmrz),2) rucmrzlv,
  rulmrz,nvl(trulmrz,0) trl,nvl(rulmrz-trulmrz,0) as rulzzl,
  round_new(decode(trulmrz,null,100,0,100,(rulmrz-trulmrz)*100/trulmrz),2) rulmrzlv,
  rezc,nvl(rezc-trezc,0) as czzl from
  (select nianf,yuef,changbb_id,
  nvl((select sum(rucmrz*1000) from yuedfxsj where nianf = b.nianf
  and yuef <= b.yuef and changbb_id = b.changbb_id),0) rucmrz,
  nvl((select sum(rulmrz*1000) from yuedfxsj where nianf = b.nianf
  and yuef <= b.yuef and changbb_id = b.changbb_id),0) rulmrz,
  nvl((select sum(rezc*1000) from yuedfxsj where nianf = b.nianf
  and yuef <= b.yuef and changbb_id = b.changbb_id),0) rezc,
  nvl((select sum(rucmrz*1000) from yuedfxsj where nianf+1 = b.nianf
  and yuef <= b.yuef and changbb_id = b.changbb_id),0) trucmrz,
  nvl((select sum(rulmrz*1000) from yuedfxsj where nianf+1 = b.nianf
  and yuef <= b.yuef and changbb_id = b.changbb_id),0) trulmrz,
  nvl((select sum(rezc*1000) from yuedfxsj where nianf+1 = b.nianf
  and yuef <= b.yuef and changbb_id = b.changbb_id),0) trezc
  from yuedfxsj b)


create view VWGJJSXX as
select c.id                     --  车皮表id
, c.biaoz                       --  标重
, c.yingd                       --  盈吨
, c.kuid                        --  亏吨
, c.yuns                        --  运损
, c.jihkjb_id                   --  计划口径
, c.guohsj                      --  过衡时间
, vf.meikdqb_id                 --  煤矿地区id
, vf.meikxxb_id                 --  煤矿信息id
, vf.ranlpzb_id                 --  燃料品种id
, zl.farl                       --  厂方热量
, zl.quansf                     --  厂方水分
, zl.shoudjhf                   --  厂方灰分
, zl.huiff                      --  厂方挥发分
, zl.liuf                       --  厂方硫分
, vf.jiag                       --  价格    （单价）
, vf.jij                        --  基价    （单价）
, vf.yunf                       --  运费    （单价）
, vf.fazzf                      --  发站杂费（单价）
, vf.daozzf                     --  到站杂费（单价）
, vf.kuangyf                    --  矿运费  （单价）
, vf.qitzf                      --  其它杂费（单价）
, vf.qiyf                       --  汽车运费（单价）
, vf.jiag + vf.yunf + vf.fazzf + vf.daozzf
+ vf.kuangyf + vf.qitzf + vf.qiyf as daoczhj
                                --  到厂综合价(单价)
, vf.meiksj as meiksj           --  煤款税价 （单价）
, vf.yunfsj as yunfsj           --  运费税价 （单价）
, vf.biaomdj                    --  标煤单价（单价）
, vf.yansrl as diwfrl_js        --  验收热量
, vf.yanssf as quansf_js        --  验收水分
, vf.yanshf as shoudjhf_js      --  验收灰分
, vf.yanshff as ganzwhjhff_js   --  验收挥发分
, vf.yansl as liuf_js           --  验收硫分
, 0 as zhuangt                  --  估价 结算状态  0:估价   1:结算
 from chepb c, vwfahgjxx vf, zhilb zl, fahb f
 where c.fahb_id = vf.fahb_id and c.jiesb_id = 0
 and c.fahb_id = f.id and f.zhilb_id = zl.id
union
select c.id,c.biaoz, c.yingd, c.kuid, c.yuns, c.jihkjb_id, c.guohsj
, vj.meikdqb_id, vj.meikdqb_id, f.ranlpzb_id, zl.farl
, zl.quansf, zl.shoudjhf, zl.huiff, zl.liuf, vj.danj
, vj.jij, vj.yunfdj, vj.fazzfdj,  vj.daozzfdj, vj.kuangqyf
, vj.qitzfdj, vj.qicyfdj, vj.danj + vj.yunfdj + vj.fazzfdj
+ vj.daozzfdj + vj.kuangyfdj +  vj.qitzfdj + vj.qityf as daoczhj
, vj.danj - vj.buhsdj as meiksj, vj.yunfdj - vj.buhsyf as yunfsj, vj.biaomdj
, vj.yansrl, vj.yanssf, vj.yanshf, vj.yanshff, vj.yansl, 1 as zhuangt
from chepb c, fahb f, vwjiesxx vj , jieszbb zb, zhilb zl
where c.jiesb_id = vj.jiesb_id and c.fahb_id = f.id
and c.jieszbb_id = zb.id and f.zhilb_id = zl.id


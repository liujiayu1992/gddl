create view VWFAHB as
select yuanid as id,diancxxb_id,fahdwb_id,meikxxb_id,meijb_id,fahrq,daohrq,chec,faz_id,daoz_id,yuanshdw,
 jihkjb_id,sum(biaoz) as biaoz,sum(maoz) as maoz,sum(piz) as piz,sum(yingd) as yingd,sum(yuns) as yuns,sum(koud) as koud,
 sum(ches) as ches,changbb_id,zhilb_id,jiesb_id,yunfl_id,huikl_id,yunsfs,ranlpzb_id,kuangfzlb_id,yuandz_id,
 yuanshdwb_id,sum(kuid) as kuid,jiesslbz,jieszlbz,hedbz from fahb
 group by yuanid,diancxxb_id,fahdwb_id,meikxxb_id,meijb_id,fahrq,daohrq,chec,faz_id,daoz_id,yuanshdw,
 jihkjb_id,changbb_id,zhilb_id,jiesb_id,yunfl_id,huikl_id,yunsfs,ranlpzb_id,kuangfzlb_id,yuandz_id,
 yuanshdwb_id,jiesslbz,jieszlbz,hedbz


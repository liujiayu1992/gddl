create view VWSHIHDY as
select max(id) id,gongysb_id,gongys,shihpzb_id,shihpz,yunsdwb_id,yunsdw
from shihcptmp
group by gongysb_id,gongys,shihpzb_id,shihpz,yunsdwb_id,yunsdw

 

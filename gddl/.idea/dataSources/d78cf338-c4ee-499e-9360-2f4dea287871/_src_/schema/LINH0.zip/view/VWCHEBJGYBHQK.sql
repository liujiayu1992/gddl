create view VWCHEBJGYBHQK as
select  c.nianf,c.fahdwb_id,c.changbb_id,
  	(select jiescbj from chebjfxb where nianf = c.nianf and yuef =1 and fahdwb_id= c.fahdwb_id and changbb_id =c.changbb_id) as Jan,
	(select jiescbj from chebjfxb where nianf = c.nianf and yuef =2 and fahdwb_id= c.fahdwb_id and changbb_id =c.changbb_id) as Feb,
	(select jiescbj from chebjfxb where nianf = c.nianf and yuef =3 and fahdwb_id= c.fahdwb_id and changbb_id =c.changbb_id) as Mar,
	(select jiescbj from chebjfxb where nianf = c.nianf and yuef =4 and fahdwb_id= c.fahdwb_id and changbb_id =c.changbb_id) as Apr,
	(select jiescbj from chebjfxb where nianf = c.nianf and yuef =5 and fahdwb_id= c.fahdwb_id and changbb_id =c.changbb_id) as May,
	(select jiescbj from chebjfxb where nianf = c.nianf and yuef =6 and fahdwb_id= c.fahdwb_id and changbb_id =c.changbb_id) as Jun,
	(select jiescbj from chebjfxb where nianf = c.nianf and yuef =7 and fahdwb_id= c.fahdwb_id and changbb_id =c.changbb_id) as Jul,
	(select jiescbj from chebjfxb where nianf = c.nianf and yuef =8 and fahdwb_id= c.fahdwb_id and changbb_id =c.changbb_id) as Aug,
	(select jiescbj from chebjfxb where nianf = c.nianf and yuef =9 and fahdwb_id= c.fahdwb_id and changbb_id =c.changbb_id) as Sep,
	(select jiescbj from chebjfxb where nianf = c.nianf and yuef =10 and fahdwb_id= c.fahdwb_id and changbb_id =c.changbb_id) as Oct,
	(select jiescbj from chebjfxb where nianf = c.nianf and yuef =11 and fahdwb_id= c.fahdwb_id and changbb_id =c.changbb_id) as Nov,
  (select jiescbj from chebjfxb where nianf = c.nianf and yuef =12 and fahdwb_id= c.fahdwb_id and changbb_id =c.changbb_id) as Dec
  from (select distinct nianf,fahdwb_id,changbb_id from chebjfxb) c


create trigger TRIGGER_FUJB
	before insert or update or delete
	on FUJB
	for each row
Declare
   changbb_id number ;    
Begin
  
     if inserting    then
     select id into changbb_id from changbb where id_jit=:new.diancxxb_id;
           AddInterfaceTask ('jjfxfjb',:new.id,0,changbb_id,'xml',:new.id,sysdate);
     elsif deleting then
     select id into changbb_id from changbb where id_jit=:old.diancxxb_id;
           AddInterfaceTask ('jjfxfjb',:old.id,1,changbb_id,'xml',:old.id,sysdate);
     elsif updating then
     select id into changbb_id from changbb where id_jit=:new.diancxxb_id;
           AddInterfaceTask ('jjfxfjb',:new.id,2,changbb_id,'xml',:new.id,sysdate);
     end if;
    exception
       when others then
        if inserting then
           zengjrz('trigger_fujb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_fujb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_fujb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;

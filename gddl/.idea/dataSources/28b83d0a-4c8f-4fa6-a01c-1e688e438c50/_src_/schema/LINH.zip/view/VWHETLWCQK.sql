create view VWHETLWCQK as
select daoh.jihkj, daoh.gongys, daoh.diancxxb_id, daoh.riq, nianht.hetl nhtl, daoh.fenx, het.hetl, daoh.daohl
from (select kj.jihkjb_id, jh.mingc as jihkj, kj.diancxxb_id,  kj.riq, kj.gongysb_id, gys.mingc as gongys,
     sl.fenx,sum(sl.jingz) as daohl from yueslb sl,yuetjkjb kj,jihkjb jh,gongysb gys
     where sl.yuetjkjb_id=kj.id and kj.jihkjb_id=jh.id and kj.gongysb_id=gys.id
     group by kj.diancxxb_id,kj.riq,sl.fenx,kj.jihkjb_id,jh.mingc,kj.gongysb_id,gys.mingc) daoh,
     (select ht.jihkjb_id, decode(jh.mingc,null,'总计',jh.mingc) as jihkj, ht.diancxxb_id, htsl.riq, ht.gongysb_id,
     decode(gys.mingc,null,'合计',gys.mingc) as gongys, sum(hetl) as hetl from hetb ht,hetslb htsl,jihkjb jh,gongysb gys
     where ht.id=htsl.hetb_id  and ht.jihkjb_id=jh.id and ht.gongysb_id=gys.id
     group by ht.diancxxb_id,htsl.riq,ht.jihkjb_id,jh.mingc,ht.gongysb_id,gys.mingc) het,
     (select ht.jihkjb_id, decode(jh.mingc,null,'总计',jh.mingc) as jihkj, ht.diancxxb_id, htsl.riq, ht.gongysb_id,
     decode(gys.mingc,null,'合计',gys.mingc) as gongys, sum(hetl) as hetl from hetb ht,hetslb htsl,jihkjb jh,gongysb gys
     where ht.id=htsl.hetb_id  and ht.jihkjb_id=jh.id and ht.gongysb_id=gys.id
     group by ht.diancxxb_id,htsl.riq,ht.jihkjb_id,jh.mingc,ht.gongysb_id,gys.mingc) nianht
where daoh.jihkjb_id=het.jihkjb_id(+) and daoh.gongysb_id=het.gongysb_id(+)  and daoh.diancxxb_id = het.diancxxb_id(+) and daoh.riq = het.riq(+)
and daoh.jihkjb_id=nianht.jihkjb_id(+) and daoh.gongysb_id=nianht.gongysb_id(+) and daoh.diancxxb_id = nianht.diancxxb_id(+) and daoh.riq = nianht.riq(+)

 

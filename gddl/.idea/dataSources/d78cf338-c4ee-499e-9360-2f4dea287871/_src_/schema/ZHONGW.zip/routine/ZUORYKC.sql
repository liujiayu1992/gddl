create function Zuorykc(lngDiancxxb_id in number,datDate in date) return number is
  Result number(10,2);
begin
    declare
        dblJingjkc number(10,2);

        begin
          select hc.kuc into dblJingjkc  from shouhcrbyb hc
                        where diancxxb_id =lngDiancxxb_id
                        and riq=datDate-1;
        return dblJingjkc;
        Exception
        WHEN NO_DATA_FOUND  THEN
             return  0;
        When Others Then
             Return  0;
    End;
end Zuorykc;

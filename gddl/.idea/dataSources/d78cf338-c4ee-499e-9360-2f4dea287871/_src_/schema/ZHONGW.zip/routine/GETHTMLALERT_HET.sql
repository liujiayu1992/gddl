create function getHtmlAlert_het(PagePath in varchar2,PageName in varchar2, ParameterName in varchar2, Parameter in varchar2,StrValue in varchar2) return varchar2 is
  Result varchar2(400);
  begin
         declare
                strTitle varchar2(200);
         begin
           strTitle := StrValue;
           if (StrValue is null or StrValue='()') then
               Result:='';
           else
                 Result:='<a target=_blank title='||strTitle||' href='||PagePath||'/app?service=page/'||PageName||'&'||ParameterName||'='||Parameter||'>'||StrValue||'</a>';
           end if;
           return(Result);
         end;
end getHtmlAlert_het;

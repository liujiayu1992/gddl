create trigger TRIGGER_UD_YUEZLB
	before insert or update or delete
	on YUEZLB
	for each row
Declare
    v_diancxxb_id number(15);
    v_riq date;
  Begin
    if inserting then
      select  diancxxb_id,riq into v_diancxxb_id,v_riq  from yuetjkjb t where t.id=:new.yuetjkjb_id;
      AddInterfaceTask('yuezlb', :new.id,0, v_diancxxb_id, 'xml', :new.id, v_riq );
    elsif deleting then
      select  diancxxb_id,riq into v_diancxxb_id,v_riq  from yuetjkjb t where t.id=:old.yuetjkjb_id;
      AddInterfaceTask('yuezlb', :old.id,1 , v_diancxxb_id, 'xml', :old.id,v_riq);
    elsif updating then
      select  diancxxb_id,riq into v_diancxxb_id,v_riq  from yuetjkjb t where t.id=:old.yuetjkjb_id;
      AddInterfaceTask('yuezlb', :old.id, 2, v_diancxxb_id, 'xml', :old.id,v_riq);
    end if;
    exception
    when others then
    return ;
  End;


create FUNCTION        "GETHTMLALLALERT" (PagePath in varchar2,PageName in varchar2, Str in varchar2,StrValue in varchar2) return varchar2 is
  Result varchar2(200);
  begin
         declare
                strTitle varchar2(100);
         begin
           strTitle := StrValue;
           if (StrValue is null or StrValue='()') then

               Result:='';
           elsif length(StrValue)>12 then

                 Result:='<a target=_blank title='||strTitle||' href='||PagePath||'/app?service=page/'||PageName||Str||'>'||substr(StrValue,0,12)||'...'||'</a>';
           else
                 Result:='<a target=_blank title='||strTitle||' href='||PagePath||'/app?service=page/'||PageName||Str||'>'||StrValue||'</a>';
           end if;
           return(Result);
         end;
end getHtmlAllAlert;



 
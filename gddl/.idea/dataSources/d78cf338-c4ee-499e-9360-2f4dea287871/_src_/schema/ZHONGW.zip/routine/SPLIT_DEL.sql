create function split_del(in_var varchar2,in_del varchar2)
 return split_type PIPELINED
 as
  temp_str varchar2(32767):=in_var;
  temp_delimiter  varchar2(20):=',';--默认为逗号
  temp_index number:=0;
 begin
      temp_delimiter:=in_del;
      if length(temp_delimiter)=0 or temp_delimiter is null then
        temp_delimiter:=',';
      end if;
      while instr(temp_str,temp_delimiter)>=0 loop
         temp_index:=instr(temp_str,temp_delimiter);
         if(temp_index>0) then
            pipe row(substr(temp_str,1,temp_index-1));
            temp_str:=substr(temp_str,temp_index+1);
         else
            pipe row(temp_str);
            exit;
         end if;
       end loop;
      exception
       when others then
       pipe row('');
 end;

create view VWMEIK as
SELECT ID AS code ,mingc AS meikmc,quanc AS meikqc,(select g.mingc from gongysb g where g.id = meikxxb.meikdq_id) as gongys
FROM meikxxb

 

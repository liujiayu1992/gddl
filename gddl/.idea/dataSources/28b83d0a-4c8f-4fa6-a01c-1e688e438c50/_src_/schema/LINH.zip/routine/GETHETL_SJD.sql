create FUNCTION        "GETHETL_SJD" (datKais in date,
                                       datJies in Date,
                                       datDate in date,
                                       hetl    number) return number is
  Result number;
begin
  if to_char(datDate, 'yyyy-mm') > to_char(datKais, 'yyyy-mm') and
     to_char(datDate, 'yyyy-mm') < to_char(datJies, 'yyyy-mm') then
    return hetl;
  end if;

  if to_char(datDate, 'yyyy-mm') = to_char(datKais, 'yyyy-mm') then
    return round(hetl * (last_day(datDate) - datKais + 1) /
                 (last_day(datDate) - datDate + 1),
                 0);
  end if;

  if to_char(datDate, 'yyyy-mm') = to_char(datJies, 'yyyy-mm') then
    return round(hetl * (datJies - datDate + 1) /
                 (last_day(datDate) - datDate + 1),
                 0);
  end if;
  return 0;
end getHetl_Sjd;

 
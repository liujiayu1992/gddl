create function getDanpcjsmx(zhibbm in varchar, colname in varchar, jiesb_id in number,xuh in number) return number is
  Result varchar2(200);
  --返回某jiesb对应的danpcjsmxb中的数据

  rvalue varchar2(200);

begin
  begin
         execute immediate 'select to_char('|| colname ||') from danpcjsmxb d,zhibb z where d.zhibb_id=z.id
                 and jiesdid='|| jiesb_id ||' and d.xuh='|| xuh ||' and z.bianm='''|| zhibbm ||''''
                 into rvalue;

         if not (rvalue is null)  then
            Result:=rvalue;
         else
            Result:='0';
         end if;
         
         EXCEPTION
              when NO_DATA_FOUND then
                Result:='0';
  end;

  return Result;
end getDanpcjsmx;

create trigger TRIGGER_RIGJB
	before insert or update or delete
	on RICBB
	for each row
Declare
Begin
     if inserting then
           AddInterfaceTask ('rigjb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);
     elsif deleting then
           AddInterfaceTask ('rigjb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);
     elsif updating then
           AddInterfaceTask ('rigjb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
     end if;
    exception
       when others then
        if inserting then
           zengjrz('trigger_rigjb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_rigjb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_rigjb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;

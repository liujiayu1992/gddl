create view V_KUANGFJSZBB as
Select Id,meijb_id,jiesslbz,jieszlbz,tuosbh,
CASE WHEN k.Farl<100 THEN k.Farl ELSE ROUND_NEW(k.Farl*0.0041816,2) END AS FARL,
CASE WHEN k.Farl>=100 THEN k.Farl ELSE ROUND_NEW(k.Farl/0.0041816,0) END AS QNET,
k.liuf As Stad,
k.Ganzjl As Std,
round_new(k.liuf*(100-100-k.quansf)/(100-k.Kongqgzjsf)	,2) As Star,
k.shoudjhf As Aar,
k.Kongqgzjhf As Aad,
k.Ganzjhf As Ad,
k.quansf As Mt,
k.Kongqgzjsf As Mad,
k.huiff As Vdaf,
k.Kongqgzjhff As Vad,
round_new((100-k.Kongqgzjsf)/(100-k.quansf)*k.Kongqgzjhff,2) As Var,
k.huird
From kuangfjszbb k
 With Read Only

create view SHENCQKYBB as
select nvl(s1.biaomdjhs, 0) as biaomdjhs,
         nvl(s1.biaomdj, 0) as biaomdj,
         nvl(s1.jingmjghs, 0) as jingmjghs,
         nvl(s1.cunyl, 0) as cunyl,
         nvl(s2.laiyl, 0) as laiyl,
         nvl(s2.zhangmcm,0) as cunml,
         nvl(s2.shijcm, 0) as shijcm,
         nvl(s2.yuns, 0) as yuns,
         s.riq
    from (select scyb1.riq
            from scyb1
          union
          select scyb.riq from scyb) s,
         scyb s1,
         scyb1 s2
   where s.riq = s1.riq(+)
     and s.riq = s2.riq


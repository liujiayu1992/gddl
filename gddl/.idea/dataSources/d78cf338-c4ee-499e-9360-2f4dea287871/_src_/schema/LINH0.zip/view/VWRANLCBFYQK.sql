create view VWRANLCBFYQK as
select nianf,yuef,changbb_id,'本月' xiangm,shoudl,shoudjj,faddwrlcb,faddwgdcb,yuglr from ranlcbfyb
	union select nianf,yuef,changbb_id,'累计' xiangm,
	(select sum(shoudl) from ranlcbfyb) shoudl,
	(select round_new(decode(sum(shoudl),0,0,sum(shoudjj*shoudl)/sum(shoudl)),2) from ranlcbfyb) shoudjj,
	(select round_new(decode(sum(shoudl),0,0,sum(faddwrlcb*shoudl)/sum(shoudl)),2) from ranlcbfyb) faddwrlcb,
	(select round_new(decode(sum(shoudl),0,0,sum(faddwgdcb*shoudl)/sum(shoudl)),2) from ranlcbfyb) faddwgdcb,
	(select sum(yuglr) from ranlcbfyb) yuglr from ranlcbfyb


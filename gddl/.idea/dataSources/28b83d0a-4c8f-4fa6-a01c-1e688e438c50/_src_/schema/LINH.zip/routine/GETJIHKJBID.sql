create FUNCTION        "GETJIHKJBID" (strJihkjbName In varchar2)
Return  number as
begin
     declare
     jihkjbid number;
     begin
     select max(id) into jihkjbid from jihkjb j where j.mingc=strJihkjbName;
     return jihkjbid;
     end;
End;

 
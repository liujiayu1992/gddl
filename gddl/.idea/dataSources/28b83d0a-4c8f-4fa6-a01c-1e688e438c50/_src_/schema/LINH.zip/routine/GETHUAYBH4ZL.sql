create FUNCTION        "GETHUAYBH4ZL" (zhilbId long)  return varchar2 is
       Result varchar2(2000);
-- 根据质量id 得到化验编号
  begin
      declare
      tmp varchar2(500);
      cursor huay is
          select distinct zm.bianm
          from zhuanmb zm,zhillsb z
          where zm.zhuanmlb_id = 100663
                and zm.zhillsb_id = z.id
                and z.zhilb_id = zhilbId;
      begin
          open huay;
               loop
                     fetch huay into tmp;
                     EXIT when huay%NOTFOUND;
                     if Result is null then
                        Result:=tmp;
                     Else
                        Result:=Result||';'||tmp;
                     end if;
               end loop;
          close huay;
      end;
      if Result is null then
         Result := '';
      end if;
      return(Result);
  end getHuaybh4zl;

 
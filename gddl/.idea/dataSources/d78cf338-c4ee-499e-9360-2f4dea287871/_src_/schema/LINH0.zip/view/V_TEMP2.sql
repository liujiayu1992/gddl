create view V_TEMP2 as
select 
Lj.Id,
       Lj.Nianf,
       Lj.Yuef,
       Dw.Xuh,
       Lj.Jihkjb_Id,
       Lj.Jihkj,
       Lj.Fahdwb_Id,
       Lj.Fahdw,
       Lj.Dangyjlj,
       Lj.Yunsfs,
       Lj.Rucml,
       Lj.Zonghj,
       Lj.Meij,
       Lj.Zengzs,
       Lj.Kuangyf,
       Lj.Kuangyfs,
       Lj.Jiaohqzf,
       Lj.Tielyf,
       Lj.Yunfse,
       Lj.Daozzf,
       Lj.Qicyf,
       Lj.Qicyfs,
       Lj.Qitfy,
       Lj.Rucrz,
       Lj.Biaomdj,
       Lj.Biaoz,
       Lj.Changbb_Id
   from (
SELECT Id, nianf, yuef, xuh, jihkjb_id, jihkj, fahdwb_id, fahdw, dangyjlj,
           rucml, zonghj, meij, zengzs, kuangyf, kuangyfs, jiaohqzf, tielyf, yunfse, daozzf,
           qicyf, qicyfs, qitfy, rucrz, biaomdj, biaoz, changbb_id, yunsfs
           FROM CHENGBMXYBB
          WHERE NIANF = 2008
            AND YUEF = 8
            AND changbb_id = 1
            AND DANGYJLJ = '本月'
 UNION
SELECT Id, nianf, yuef, xuh, jihkjb_id, jihkj, fahdwb_id,		 fahdw, '本月' As dangyjlj,
 0 As rucml, 0 As zonghj, 0 As meij, 0 As zengzs, 0 As		 kuangyf, 0 As kuangyfs,
 0 As jiaohqzf, 0 As tielyf, 0 As yunfse, 0 As daozzf, 0 As		 qicyf, 0 As qicyfs,
 0 As qitfy, 0 As rucrz, 0 As biaomdj, 0 As biaoz,		 changbb_id, yunsfs
 
 FROM CHENGBMXYBB
 WHERE NIANF = 2008
 AND YUEF =7
 AND changbb_id = 1
 AND DANGYJLJ = '累计'
         UNION
SELECT Id, nianf, yuef, xuh, jihkjb_id, jihkj, fahdwb_id, fahdw, dangyjlj,
           rucml, zonghj, meij, zengzs, kuangyf, kuangyfs, jiaohqzf, tielyf, yunfse, daozzf,
           qicyf, qicyfs, qitfy, rucrz, biaomdj, biaoz, changbb_id, yunsfs
           FROM CHENGBMXYBB
          WHERE NIANF =  2008
            AND YUEF =7
            AND changbb_id = 1
            AND DANGYJLJ = '累计') lj,
        (SELECT cb.fahdw, sum(cb.rucml) as rucml,Max(Decode(Dangyjlj, '累计', 0, Xuh)) As Xuh
           FROM CHENGBMXYBB cb
          WHERE NIANF =  2008
            AND ( (YUEF = 8 and DANGYJLJ = '本月') or (YUEF =7 and DANGYJLJ = '累计'))
            AND changbb_id = 1
          group by cb.fahdw
         having sum(cb.rucml) <> 0) dw
  where lj.fahdw = dw.fahdw


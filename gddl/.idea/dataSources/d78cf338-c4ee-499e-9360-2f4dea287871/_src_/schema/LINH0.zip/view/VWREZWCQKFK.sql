create view VWREZWCQKFK as
select f.jianc, b.nianf,b.yuef,b.changbb_id,'本月' as xiangm,b.rucrz  rucrz,
	nvl(trucrz , 0) as tqrz,(b.rucrz - nvl(trucrz, 0)) as zzl,
	b.qunpjrz  qunpjrz,round_new(decode(b.qunpjrz,0,0,(b.rucrz - b.qunpjrz)
	* 100 / b.qunpjrz),2) as btqb, b.hetrz hetrz,
	(b.rucrz - b.hetrz) as bhtb from
	(select nianf,yuef,changbb_id,fahdwb_id,rucrz,qunpjrz,hetrz,jiesrz,
	nvl((select rucrz from rezwcqkfkb where r.nianf+1 =nianf and r.yuef = yuef
	and r.changbb_id = changbb_id and r.fahdwb_id = fahdwb_id),0) trucrz,
	nvl((select qunpjrz from rezwcqkfkb where r.nianf+1 =nianf and r.yuef = yuef
	and r.changbb_id = changbb_id and r.fahdwb_id = fahdwb_id),0) tqunpjrz,
	nvl((select hetrz from rezwcqkfkb where r.nianf+1 =nianf and r.yuef = yuef
	and r.changbb_id = changbb_id and r.fahdwb_id = fahdwb_id),0) thetrz,
	nvl((select jiesrz from rezwcqkfkb where r.nianf+1 =nianf and r.yuef = yuef
	and r.changbb_id = changbb_id and r.fahdwb_id = fahdwb_id),0) tjiesrz
	from rezwcqkfkb r) b,fahdwb f where b.fahdwb_id = f.id
	union select f.jianc,b.nianf,b.yuef,b.changbb_id, '累计' as xiangm,b.rucrz rucrz,
	nvl(trucrz , 0) as tqrz,(b.rucrz - nvl(trucrz, 0)) as zzl,
	b.qunpjrz  qunpjrz,round_new(decode(b.qunpjrz,0,0,(b.rucrz - b.qunpjrz)
	* 100 / b.qunpjrz),2) as btqb, b.hetrz  hetrz,
	(b.rucrz - b.hetrz) as bhtb from
	(select nianf,yuef,changbb_id,fahdwb_id,
	nvl((select sum(rucrz)/count(*) from rezwcqkfkb where nianf = r.nianf and yuef <= r.yuef
	and changbb_id = r.changbb_id and fahdwb_id = r.fahdwb_id),0) rucrz,
	nvl((select sum(qunpjrz)/count(*) from rezwcqkfkb where nianf = r.nianf and yuef <= r.yuef
	and changbb_id = r.changbb_id and fahdwb_id = r.fahdwb_id),0) qunpjrz,
  nvl((select sum(hetrz)/count(*) from rezwcqkfkb where nianf = r.nianf and yuef <= r.yuef
  and changbb_id = r.changbb_id and fahdwb_id = r.fahdwb_id),0) hetrz,
  nvl((select sum(jiesrz)/count(*) from rezwcqkfkb where nianf = r.nianf and yuef <= r.yuef
  and changbb_id = r.changbb_id and fahdwb_id = r.fahdwb_id),0) jiesrz,
  nvl((select sum(rucrz)/count(*) from rezwcqkfkb where nianf+1 = r.nianf and yuef <= r.yuef
  and changbb_id = r.changbb_id and fahdwb_id = r.fahdwb_id),0) trucrz,
  nvl((select sum(qunpjrz)/count(*) from rezwcqkfkb where nianf+1 = r.nianf and yuef <= r.yuef
  and changbb_id = r.changbb_id and fahdwb_id = r.fahdwb_id),0) tqunpjrz,
  nvl((select sum(hetrz)/count(*) from rezwcqkfkb where nianf+1 = r.nianf and yuef <= r.yuef
  and changbb_id = r.changbb_id and fahdwb_id = r.fahdwb_id),0) thetrz,
  nvl((select sum(jiesrz)/count(*) from rezwcqkfkb where nianf+1 = r.nianf and yuef <= r.yuef
  and changbb_id = r.changbb_id and fahdwb_id = r.fahdwb_id),0) tjiesrz
  from rezwcqkfkb r) b, fahdwb f where b.fahdwb_id = f.id


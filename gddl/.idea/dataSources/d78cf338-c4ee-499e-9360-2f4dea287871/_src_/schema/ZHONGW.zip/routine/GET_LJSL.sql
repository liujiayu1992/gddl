create function get_ljsl(lngDiancxxb_id in number,datDate in
date,StrZhi in varchar2) return number is
  Result number(10,2);
begin
    declare
        ljslzhi number(10,2);
        begin
          if StrZhi='dangrgm' then
             select sum(dangrgm) into ljslzhi  from shouhcrbb
                        where diancxxb_id =lngDiancxxb_id
                        and riq>=First_day(datDate)
                        and riq<=datDate
                        group by diancxxb_id;
          elsif StrZhi='haoyqkdr' then
               select sum(haoyqkdr) into ljslzhi  from shouhcrbb
                          where diancxxb_id =lngDiancxxb_id
                          and riq>=First_day(datDate)
                          and riq<=datDate
                          group by diancxxb_id;
           end if;
        return ljslzhi;
        Exception
        WHEN NO_DATA_FOUND  THEN
             return  0;
        When Others Then
        Return  0;
End;
end;

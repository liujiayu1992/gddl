create FUNCTION getJizyxqk (rq date) return VARCHAR2 is
begin
    declare
      qingk VARCHAR2(500) :='';
      v_loopcounter integer :=1;
      CURSOR my_cursor IS
        select  d.jizh, nvl(d.jizzk,' ') AS jizzk from dianlrb d where d.riq=rq;
      my_rec my_cursor%ROWTYPE;
    begin
      OPEN my_cursor;
        LOOP
          FETCH my_cursor INTO my_rec;
            EXIT WHEN my_cursor%NOTFOUND;
            IF v_loopcounter = 1 THEN
              qingk := my_rec.jizh||my_rec.jizzk;
            ELSE
                qingk := qingk||chr(13)||my_rec.jizh||my_rec.jizzk;
            END IF;
          v_loopcounter := v_loopcounter + 1;
        END LOOP;
      CLOSE my_cursor;
      RETURN qingk;
    END;
END;

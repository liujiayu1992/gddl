create view V_PIC_CHEPH as
Select z.Id,GETCAIYCHEPH(z.Id) As cheh
       From Zhilb z
        With Read Only


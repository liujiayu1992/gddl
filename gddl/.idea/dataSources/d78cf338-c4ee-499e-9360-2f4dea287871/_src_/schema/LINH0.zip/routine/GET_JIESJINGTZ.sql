create Function Get_JiesJingtz (jiesbid In Number
                       )
 Return  Number As
 Begin
  Declare
   v_shul Number;
   Begin
       Select Sum(t.biaoz) - Sum(kuid) + Sum(yingd)
       Into v_shul
       From (
         Select round_new(Sum(c.biaoz),0) As biaoz,round_new(Sum(c.kuid),0) As kuid,round_new(Sum(c.yingd),0) As yingd
         From fahb f,chepb c
         Where f.Id = c.fahb_id
         And c.Jiesb_Id = jiesbid
         Group By f.Zhilb_Id
       ) t;
    Return  v_shul;
   Exception When Others Then
    Return 0;
   End;
End;

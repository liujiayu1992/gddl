create trigger TRG_JK_ASSAYCODE
	before insert
	on JK_ASSAYCODE
	for each row
declare
  -- local variables here
begin
  select Seq_Jk_Assaycode.Nextval into :new.id from dual;
end trg_jk_assaycode;

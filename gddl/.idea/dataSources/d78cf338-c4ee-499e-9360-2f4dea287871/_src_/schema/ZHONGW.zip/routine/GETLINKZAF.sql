create function getLinkZaf(strIDdianc in varchar2,strLabel in varchar2)return varchar2 is

begin
     if strIDdianc = '-1' then
     return strLabel;
     else
        return '<a href="#" onclick="openLinkZaf('||chr(39)||strIDdianc||chr(39)||')">'||strLabel||'</a>';
     end if;
end getLinkZaf;

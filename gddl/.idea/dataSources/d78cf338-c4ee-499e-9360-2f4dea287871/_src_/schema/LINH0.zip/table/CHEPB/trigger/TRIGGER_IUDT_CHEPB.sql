create trigger TRIGGER_IUDT_CHEPB
	after insert or update or delete
	on CHEPB
	for each row
DECLARE

  V_NEWFAHBID FAHB.ID%TYPE;

  V_ORIFAHBID FAHB.ID %TYPE;

  v_ches fahb.ches%TYPE;

  v_maoz fahb.maoz%TYPE;

  v_piz fahb.piz%TYPE;

  v_yuns fahb.yuns%type;

  v_biaoz fahb.biaoz%type;

  v_koud fahb.koud%type;

  v_kouz fahb.kouz%type;

  v_yingd fahb.yingd%type;

BEGIN

  IF INSERTING THEN--新增的车皮，更新相应的发货记录

   V_NEWFAHBID:=:NEW_VALUE.FAHB_ID;

   v_ches   :=1;

   v_maoz   :=:NEW_VALUE.maoz;

   v_piz    :=:NEW_VALUE.piz;

   v_yuns   :=:NEW_VALUE.yuns;

   v_biaoz  :=:NEW_VALUE.biaoz;

   v_koud   :=:NEW_VALUE.koud;

   v_kouz   :=:NEW_VALUE.kouz;

   v_yingd  :=:NEW_VALUE.yingd;

   UPdatefahb(V_NEWFAHBID ,v_ches ,v_maoz ,v_piz ,v_yuns ,v_biaoz ,v_koud ,v_kouz ,v_yingd );

  ELSIF UPDATING THEN

   V_ORIFAHBID:=:OLD_VALUE.FAHB_ID;

   V_NEWFAHBID:=:NEW_VALUE.FAHB_ID;



   IF V_ORIFAHBID = V_NEWFAHBID THEN---还是同一个发货,更改数值字段值

   v_ches   :=0;

   v_maoz   :=:NEW_VALUE.maoz-:OLD_VALUE.maoz;

   v_piz    :=:NEW_VALUE.piz-:OLD_VALUE.piz;

   v_yuns   :=:NEW_VALUE.yuns-:OLD_VALUE.yuns;

   v_biaoz  :=:NEW_VALUE.biaoz-:OLD_VALUE.biaoz;

   v_koud   :=:NEW_VALUE.koud-:OLD_VALUE.koud;

   v_kouz   :=:NEW_VALUE.kouz-:OLD_VALUE.kouz;

   v_yingd  :=:NEW_VALUE.yingd-:OLD_VALUE.yingd;

   UPdatefahb(V_ORIFAHBID ,v_ches ,v_maoz ,v_piz ,v_yuns ,v_biaoz ,v_koud ,v_kouz ,v_yingd );

   ELSE

   v_ches   :=1;--更改车皮对应另外的一条发货,车数增加

   v_maoz   :=:NEW_VALUE.maoz;

   v_piz    :=:NEW_VALUE.piz;

   v_yuns   :=:NEW_VALUE.yuns;

   v_biaoz  :=:NEW_VALUE.biaoz;

   v_koud   :=:NEW_VALUE.koud;

   v_kouz   :=:NEW_VALUE.kouz;

   v_yingd  :=:NEW_VALUE.yingd;

     UPdatefahb(V_NEWFAHBID ,v_ches ,v_maoz ,v_piz ,v_yuns ,v_biaoz ,v_koud ,v_kouz ,v_yingd );

   v_ches   :=-1;---原发货减少一条车皮

   v_maoz   :=-:OLD_VALUE.maoz;

   v_piz    :=-:OLD_VALUE.piz;

   v_yuns   :=-:OLD_VALUE.yuns;

   v_biaoz  :=-:OLD_VALUE.biaoz;

   v_koud   :=-:OLD_VALUE.koud;

   v_kouz   :=-:OLD_VALUE.kouz;

   v_yingd  :=-:OLD_VALUE.yingd;

   UPdatefahb(V_ORIFAHBID ,v_ches ,v_maoz ,v_piz ,v_yuns ,v_biaoz ,v_koud ,v_kouz ,v_yingd );

   END IF;

  ELSIF DELETING THEN---删除车皮，调整对于的发货记录

   V_ORIFAHBID:=:OLD_VALUE.FAHB_ID;

   v_ches   :=-1;

   v_maoz   :=-:OLD_VALUE.maoz;

   v_piz    :=-:OLD_VALUE.piz;

   v_yuns   :=-:OLD_VALUE.yuns;

   v_biaoz  :=-:OLD_VALUE.biaoz;

   v_koud   :=-:OLD_VALUE.koud;

   v_kouz   :=-:OLD_VALUE.kouz;

   v_yingd  :=-:OLD_VALUE.yingd;

   UPdatefahb(V_ORIFAHBID ,v_ches ,v_maoz ,v_piz ,v_yuns ,v_biaoz ,v_koud ,v_kouz ,v_yingd );

  END IF;

END;

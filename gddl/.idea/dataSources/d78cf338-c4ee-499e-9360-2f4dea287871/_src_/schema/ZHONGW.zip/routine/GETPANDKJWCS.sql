create function getPandkjwcs(diancxxbid in number, panddate in date) return number is
begin
   declare
          cusl_kj number;
          begin
               select round(sum(rb.dangrgm)/daycount(panddate)*0.005,0) into cusl_kj from shouhcrbb rb,vwdianc dc
               where rb.diancxxb_id=dc.id and rb.riq>=panddate and rb.riq< last_day(panddate)
                     and dc.id=diancxxbid;

              return cusl_kj;
          end;
end getPandkjwcs;

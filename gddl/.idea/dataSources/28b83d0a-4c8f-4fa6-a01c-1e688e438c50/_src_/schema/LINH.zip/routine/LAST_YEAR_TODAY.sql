create FUNCTION        "LAST_YEAR_TODAY" (datDate in date) return date is
begin
  return  add_months(last_day(datDate),-13)+1;
end last_year_today;

 
create view VWSHIHYSDWDY as
select max(id) id,yunsdwb_id,yunsdw from shihcptmp
where yunsdwb_id <>0 group by yunsdwb_id,yunsdw


create view VWHUOYCYFZFS as
select f.diancxxb_id, f.gongysb_id, f.meikxxb_id, f.pinzb_id, f.faz_id,
       f.jihkjb_id, f.fahrq, f.daohrq, f.zhilb_id, c.caiyrq caiyrq, f.chec
       from fahb f,caiyb c
       where f.zhilb_id = c.zhilb_id and f.yunsfsb_id = 1


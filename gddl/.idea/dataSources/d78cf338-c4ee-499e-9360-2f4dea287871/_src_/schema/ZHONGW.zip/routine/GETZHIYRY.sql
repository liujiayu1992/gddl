create function GetZhiyry(mid number) return varchar2 is
  Result varchar2(2000);
begin
  DECLARE
    v_mingc varchar2(2000) ;
    CURSOR C_chezxxb IS
      select r.quanc
      from zhiyryglb c,renyxxb r
      where c.renyxxb_id=r.id and c.yangpdhb_id=mid;
  BEGIN
    OPEN C_chezxxb;
    loop
      FETCH C_chezxxb
        INTO v_mingc;
      if C_chezxxb%FOUND then
        Result := Result || v_mingc || ',';
      end if;
      EXIT WHEN C_chezxxb%NOTFOUND;
    end loop;
    CLOSE C_chezxxb;
    if Length(Result) > 0 then
      Result := substr(Result, 0, Length(Result) - 1);
    end if;
    return(Result);
  END;
end GetZhiyry;

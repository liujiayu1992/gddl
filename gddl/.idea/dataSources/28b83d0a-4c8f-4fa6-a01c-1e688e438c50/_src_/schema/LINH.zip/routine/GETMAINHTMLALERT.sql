create FUNCTION        "GETMAINHTMLALERT" (leix in varchar2,PagePath in varchar2,PageName in varchar2, ParameterName in varchar2, Parameter in varchar2,StrValue in varchar2,Fabrq in varchar2,BiaotSize in number) return varchar2 is
  Result varchar2(200);
  begin
         declare
                strTitle varchar2(100);
         begin
           strTitle := StrValue;
           if (StrValue is null or StrValue='()') then
               Result:='';
           elsif leix='main' then

               if BiaotSize>=0 then
                     if  length(StrValue)>9 then
                         Result:='<a target=_blank title='||strTitle||Fabrq||' href='||PagePath||'/app?service=page/'||PageName||'&'||ParameterName||'='||Parameter||'>'||substr(StrValue,0,9)||'...'||'</a>';
                     else
                         Result:='<a target=_blank title='||strTitle||Fabrq||' href='||PagePath||'/app?service=page/'||PageName||'&'||ParameterName||'='||Parameter||'>'||StrValue||'</a>';
                     end if;
               elsif length(StrValue)>12 then
                   Result:='<a target=_blank title='||strTitle||Fabrq||' href='||PagePath||'/app?service=page/'||PageName||'&'||ParameterName||'='||Parameter||'>'||substr(StrValue,0,12)||'...'||'</a>';
               else
                   Result:='<a target=_blank title='||strTitle||Fabrq||' href='||PagePath||'/app?service=page/'||PageName||'&'||ParameterName||'='||Parameter||'>'||StrValue||'</a>';
               end if;

            else
                 Result:='<a target=_blank title='||strTitle||Fabrq||' href='||PagePath||'/app?service=page/'||PageName||'&'||ParameterName||'='||Parameter||'>'||StrValue||'</a>';
             end if;
           return(Result);
         end;
end getMainHtmlAlert;

 
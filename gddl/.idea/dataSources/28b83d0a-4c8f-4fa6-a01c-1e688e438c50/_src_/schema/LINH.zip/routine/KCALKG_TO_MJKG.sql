create FUNCTION        "KCALKG_TO_MJKG" (value in number, xiaosw in number) return number is
  Result number;
begin
  declare

     begin
          if (abs(value)>1000) then

             Result:=Round_new(value/1000*4.1816, xiaosw);

          else

             Result:=value;
          end if;
     end;
  return(Result);
end kcalkg_to_Mjkg;

 
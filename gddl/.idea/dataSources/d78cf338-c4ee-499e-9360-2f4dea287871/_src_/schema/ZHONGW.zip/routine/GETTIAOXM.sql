create Function gettiaoxm
Return varchar2 as
begin
     declare
     xl varchar2(13);
     begin
     select xl_tiaoxm.nextval into xl from dual;
     if LENGTH(xl) < 13 then
       return substr('0000000000000' || xl,length(xl)+1,13);
     else
       return xl;
     end if;
     end;
    -- return result;
End;

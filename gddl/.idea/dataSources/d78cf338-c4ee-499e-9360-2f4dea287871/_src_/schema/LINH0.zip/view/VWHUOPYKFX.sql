create view VWHUOPYKFX as
select f.nianf,f.yuef,f.changbb_id,f.fahdw_id,f.jianc,'本月' xiangm,
  (select sum(yingd) from fahgjb where to_number(to_char(riq,'yyyy')) = f.nianf
  and to_number(to_char(riq,'mm')) = f.yuef and fahdw_id = f.fahdw_id) yingd,
  (select sum(kuid) from fahgjb where to_number(to_char(riq,'yyyy')) = f.nianf
  and to_number(to_char(riq,'mm')) = f.yuef and fahdw_id = f.fahdw_id) kuid,
  (select sum(yingd-kuid) from fahgjb where to_number(to_char(riq,'yyyy')) = f.nianf
  and to_number(to_char(riq,'mm')) = f.yuef and fahdw_id = f.fahdw_id) yingk,
  nvl((select sum(yingd) from fahgjb where to_number(to_char(riq,'yyyy'))+1 = f.nianf
  and to_number(to_char(riq,'mm')) = f.yuef and fahdw_id = f.fahdw_id),0) tyingd,
  nvl((select sum(kuid) from fahgjb where to_number(to_char(riq,'yyyy'))+1 = f.nianf
  and to_number(to_char(riq,'mm')) = f.yuef and fahdw_id = f.fahdw_id),0) tkuid,
  nvl((select sum(yingd-kuid) from fahgjb where to_number(to_char(riq,'yyyy'))+1 = f.nianf
  and to_number(to_char(riq,'mm')) = f.yuef and fahdw_id = f.fahdw_id),0) tyingk
  from (select distinct g.fahdw_id,to_number(to_char(g.riq,'yyyy')) nianf
  ,to_number(to_char(g.riq,'mm')) yuef,h.changbb_id,d.jianc
  from fahgjb g,fahb h,fahdwb d where g.fahb_id = h.id and g.fahdw_id=d.id) f union
  select f.nianf,f.yuef,f.changbb_id,f.fahdw_id,f.jianc,'累计' xiangm,
  (select sum(yingd) from fahgjb where to_number(to_char(riq,'yyyy')) = f.nianf
  and to_number(to_char(riq,'mm')) <= f.yuef and fahdw_id = f.fahdw_id) yingd,
  (select sum(kuid) from fahgjb where to_number(to_char(riq,'yyyy')) = f.nianf
  and to_number(to_char(riq,'mm')) <= f.yuef and fahdw_id = f.fahdw_id) kuid,
  (select sum(yingd-kuid) from fahgjb where to_number(to_char(riq,'yyyy')) = f.nianf
  and to_number(to_char(riq,'mm')) <= f.yuef and fahdw_id = f.fahdw_id) yingk,
  nvl((select sum(yingd) from fahgjb where to_number(to_char(riq,'yyyy'))+1 = f.nianf
  and to_number(to_char(riq,'mm')) <= f.yuef and fahdw_id = f.fahdw_id),0) tyingd,
  nvl((select sum(kuid) from fahgjb where to_number(to_char(riq,'yyyy'))+1 = f.nianf
  and to_number(to_char(riq,'mm')) <= f.yuef and fahdw_id = f.fahdw_id),0) tkuid,
  nvl((select sum(yingd-kuid) from fahgjb where to_number(to_char(riq,'yyyy'))+1 = f.nianf
  and to_number(to_char(riq,'mm')) <= f.yuef and fahdw_id = f.fahdw_id),0) tyingk
  from (select distinct g.fahdw_id,to_number(to_char(g.riq,'yyyy')) nianf
  ,to_number(to_char(g.riq,'mm')) yuef,h.changbb_id,d.jianc
  from fahgjb g,fahb h,fahdwb d where g.fahb_id = h.id and g.fahdw_id=d.id) f


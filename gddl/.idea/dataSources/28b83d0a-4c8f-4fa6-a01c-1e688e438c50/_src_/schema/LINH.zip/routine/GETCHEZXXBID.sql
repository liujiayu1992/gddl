create FUNCTION        "GETCHEZXXBID" (strChezName In varchar2)
Return  number as
begin
     declare
     chezxxbid number;
     begin
     --用max(id) 不用id是防止车站名称重复
     select max(id) into chezxxbid from chezxxb c where c.leib='车站' and c.mingc=strChezName;
     return chezxxbid;
     end;
End;

 
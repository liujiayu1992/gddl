create trigger TRIGGER_PANMYQKBGZB
	before insert or update or delete
	on PANMYQKBGZB
	for each row
Declare
       v_renwbs number;
       cursor cur_pandyb is
          select id
          from pandcyb
          where pandcyb.riq=:new.riq and pandcyb.changbb_id=:new.changbb_id;
       cursor cur_pandyb_del is
          select id
          from pandcyb
          where pandcyb.riq=:old.riq and pandcyb.changbb_id=:old.changbb_id;
      cursor cur_pandmdb is
          select id
          from meicmd
          where meicmd.riq=:new.riq and meicmd.changbb_id=:new.changbb_id;
      cursor cur_pandmdb_del is
          select id
          from meicmd
          where meicmd.riq=:old.riq and meicmd.changbb_id=:old.changbb_id;
      cursor cur_pandtjb is
          select id
          from meicpd
          where meicpd.riq=:new.riq and meicpd.changbb_id=:new.changbb_id;
     cursor cur_pandtjb_del is
          select id
          from meicpd
          where meicpd.riq=:old.riq and meicpd.changbb_id=:old.changbb_id;
      cursor cur_pandwzcmb is
          select id
          from weizcm
          where weizcm.riq=:new.riq and weizcm.changbb_id=:new.changbb_id;
       cursor cur_pandwzcmb_del is
          select id
          from weizcm
          where weizcm.riq=:old.riq and weizcm.changbb_id=:old.changbb_id;
      cursor cur_pandbmryzzb is
          select id
          from pandbp
          where pandbp.riq=:new.riq and pandbp.changbb_id=:new.changbb_id;
      cursor cur_pandbmryzzb_del is
          select id
          from pandbp
          where pandbp.riq=:old.riq and pandbp.changbb_id=:old.changbb_id;
Begin

     if inserting then
     --发送5个基础数据的增加任务
          --账面煤
          AddInterfaceTask ('pandb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);

          --盘点油量
          open cur_pandyb;
          LOOP
          fetch cur_pandyb into v_renwbs;
          EXIT WHEN cur_pandyb%NOTFOUND;

           AddInterfaceTask ('pandyb',v_renwbs,0,:new.changbb_id,'xml',v_renwbs,:new.riq);
          END LOOP;
          close cur_pandyb;

         --煤场密度
         open cur_pandmdb;
          LOOP
          fetch cur_pandmdb into v_renwbs;
          EXIT WHEN cur_pandmdb%NOTFOUND;

           AddInterfaceTask ('pandmdb',v_renwbs,0,:new.changbb_id,'xml',v_renwbs,:new.riq);
          END LOOP;
          close cur_pandmdb;
         --煤场体积
         open cur_pandtjb;
          LOOP
          fetch cur_pandtjb into v_renwbs;
          EXIT WHEN cur_pandtjb%NOTFOUND;

          AddInterfaceTask ('pandtjb',v_renwbs,0,:new.changbb_id,'xml',v_renwbs,:new.riq);
          END LOOP;
          close cur_pandtjb;
         --其它存煤
         open cur_pandwzcmb;
          LOOP
          fetch cur_pandwzcmb into v_renwbs;
          EXIT WHEN cur_pandwzcmb%NOTFOUND;

          AddInterfaceTask ('pandwzcmb',v_renwbs,0,:new.changbb_id,'xml',v_renwbs,:new.riq);
          END LOOP;
          close cur_pandwzcmb;
           --人员职责
         open cur_pandbmryzzb;
          LOOP
          fetch cur_pandbmryzzb into v_renwbs;
          EXIT WHEN cur_pandbmryzzb%NOTFOUND;

          AddInterfaceTask ('pandbmryzzb',v_renwbs,0,:new.changbb_id,'xml',v_renwbs,:new.riq);
          END LOOP;
          close cur_pandbmryzzb;

     elsif deleting then

          AddInterfaceTask ('pandb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);
          --删除分表内容，因为在程序操作时先删除总表，这样分表就失去了厂别、日期等信息
          AddInterfaceTask ('pandzmy',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);
          AddInterfaceTask ('pandzmm',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);

           --盘点油量
          open cur_pandyb_del;
          LOOP
          fetch cur_pandyb_del into v_renwbs;
          EXIT WHEN cur_pandyb_del%NOTFOUND;
           AddInterfaceTask ('pandyb',v_renwbs,1,:old.changbb_id,'xml',v_renwbs,:old.riq);
          END LOOP;
          close cur_pandyb_del;
         --煤场密度
         open cur_pandmdb_del;
          LOOP
          fetch cur_pandmdb_del into v_renwbs;
          EXIT WHEN cur_pandmdb_del%NOTFOUND;
           AddInterfaceTask ('pandmdb',v_renwbs,1,:old.changbb_id,'xml',v_renwbs,:old.riq);
          END LOOP;
          close cur_pandmdb_del;
         --煤场体积
         open cur_pandtjb_del;
          LOOP
          fetch cur_pandtjb_del into v_renwbs;
          EXIT WHEN cur_pandtjb_del%NOTFOUND;
          AddInterfaceTask ('pandtjb',v_renwbs,1,:old.changbb_id,'xml',v_renwbs,:old.riq);
          END LOOP;
          close cur_pandtjb_del;
         --其它存煤
         open cur_pandwzcmb_del;
          LOOP
          fetch cur_pandwzcmb_del into v_renwbs;
          EXIT WHEN cur_pandwzcmb_del%NOTFOUND;
          AddInterfaceTask ('pandwzcmb',v_renwbs,1,:old.changbb_id,'xml',v_renwbs,:old.riq);
          END LOOP;
          close cur_pandwzcmb_del;
           --人员职责
         open cur_pandbmryzzb_del;
          LOOP
          fetch cur_pandbmryzzb_del into v_renwbs;
          EXIT WHEN cur_pandbmryzzb_del%NOTFOUND;
          AddInterfaceTask ('pandbmryzzb',v_renwbs,1,:old.changbb_id,'xml',v_renwbs,:old.riq);
          END LOOP;
          close cur_pandbmryzzb_del;
     elsif updating then
          AddInterfaceTask ('pandb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
     end if;
    exception
    when others then
        if inserting then
           zengjrz('trigger_panmyqkbgzb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_panmyqkbgzb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_panmyqkbgzb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
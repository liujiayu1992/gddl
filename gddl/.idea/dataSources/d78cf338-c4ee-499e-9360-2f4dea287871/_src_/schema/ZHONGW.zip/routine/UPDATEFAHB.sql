create PROCEDURE UPdatefahb(fahbid IN NUMBER,v_ches in number,v_maoz in number,

v_piz in number,v_jingz in number,v_yingk in number,v_yuns in number,

v_biaoz in number,v_koud in number,v_kous in number,v_kouz in number,

v_koum in number,v_sanfsl in number,v_zongkd in number,v_yingd in number ) IS

BEGIN



  DECLARE



  BEGIN



    update fahb set ches=ches+v_ches,maoz=maoz+v_maoz,piz=piz+v_piz,jingz=jingz+v_jingz,yingk=yingk+v_yingk,

    yuns=yuns+v_yuns,biaoz=biaoz+v_biaoz,koud=koud+v_koud,kous=kous+v_kous,kouz=kouz+v_kouz,sanfsl=sanfsl+v_sanfsl,

    zongkd=zongkd+v_zongkd,koum=koum+v_koum,yingd=yingd+v_yingd where id=fahbid;



    --删除空发货记录

    delete from fahb where id=fahbid and ches<=0;



  END;

END updatefahb;

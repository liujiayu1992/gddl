create view VWFAHDWQC as
select id,meikxxb.meikdwqc as fahdw from meikxxb
union
select id,fahdwb.quanc as fahdw from fahdwb
union
select id,meikdqb.meikdqqc as fahdw from  meikdqb WITH READ ONLY


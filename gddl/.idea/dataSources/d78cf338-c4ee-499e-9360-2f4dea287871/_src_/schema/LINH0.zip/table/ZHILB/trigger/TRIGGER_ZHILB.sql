create trigger TRIGGER_ZHILB
	before insert or update or delete
	on ZHILB
	for each row
Declare
  v_changb_id number(10);
Begin
  --审核情况下删除增加都能发出指令；审核状态下修改也能发出指令；审核回退都能发出指令；
  if inserting and :new.shangjshzt=1 then
      select distinct fh.changbb_id into v_changb_id from fahb fh
           where fh.zhilb_id=:new.id;
      AddInterfaceTask ('zhilb',:new.id,0,v_changb_id,'xml',:new.id,sysdate);
  elsif  deleting and :old.shangjshzt=1   then
      select distinct fh.changbb_id into v_changb_id from fahb fh
           where fh.zhilb_id=:old.id;
      AddInterfaceTask ('zhilb',:old.id,1,v_changb_id,'xml',:old.id,sysdate);
  elsif  updating   then
      select distinct fh.changbb_id into v_changb_id from fahb fh
           where fh.zhilb_id=:old.id;
      if :old.shangjshzt<>:new.shangjshzt and :new.shangjshzt=1 then
          AddInterfaceTask ('zhilb',:new.id,0,v_changb_id,'xml',:new.id,sysdate);
      elsif :old.shangjshzt<>:new.shangjshzt and :new.shangjshzt=0 then
           AddInterfaceTask ('zhilb',:old.id,1,v_changb_id,'xml',:old.id,sysdate);
      elsif :old.shangjshzt=1 then
            AddInterfaceTask ('zhilb',:new.id,2,v_changb_id,'xml',:new.id,sysdate);
      end if;
  end if;
  if updating and :new.shenhzt=1 then
      --2016-10 通过燃料系统录入工业分析结果，并提交工业分析结果时，用公式更新“Qgrd”的值，保持与化验系统接口的数据源一致
      --round_new(((100 / (100 - z.kongqgzjsf)) *  (z.ganzjgwrz * 1000))/1000,  2)
      :new.qgr_d := round_new(((100 / (100 - :new.kongqgzjsf)) *  (:new.ganzjgwrz * 1000))/1000,  2);
  end if;
  exception
  when others then
        if inserting then
           zengjrz('trigger_zhilb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_zhilb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_zhilb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;

create trigger TRIGGER_JIESB
	before insert or update or delete
	on JIESB
	for each row
Declare
  v_id          jiesb.id%Type;
Begin
     if inserting then
        if :new.kuangfjs<>1 then
          AddInterfaceTask ('jiesb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.jiesrq);
          AddInterfaceTask ('jiesyfb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.jiesrq);
          AddInterfaceTask ('jieszbsjb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.jiesrq);
        end if;
     elsif deleting then
       if :old.kuangfjs<>1 then
          if :old.kuangfjs=0 then
            AddInterfaceTask ('jiesb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.jiesrq);
            AddInterfaceTask ('jiesyfb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.jiesrq);
            AddInterfaceTask ('jieszbsjb',:new.id,1,:new.changbb_id,'xml',:new.id,:new.jiesrq);
          else--2
             select id into v_id
             from jiesb js
             where js.jiesbh=:old.jiesbh and js.kuangfjs=1 ;
             AddInterfaceTask ('jiesb',v_id,1,:old.changbb_id,'xml',:old.id,:old.jiesrq);
             AddInterfaceTask ('jiesyfb',v_id,1,:old.changbb_id,'xml',:old.id,:old.jiesrq);
             AddInterfaceTask ('jieszbsjb',v_id,1,:new.changbb_id,'xml',:new.id,:new.jiesrq);
          end if;
       end if;
     elsif updating then
       if :old.kuangfjs<>1 then
          if (:new.DIANCXXB_ID<>:old.DIANCXXB_ID or
             :new.CHANGBB_ID<>:old.CHANGBB_ID or
             :new.JIESBH<>:old.JIESBH or
             :new.FAHDWB_ID<>:old.FAHDWB_ID or
             :new.MEIKXXB_ID<>:old.MEIKXXB_ID or
             :new.CHEZXXB_ID<>:old.CHEZXXB_ID or
             :new.FAHKSRQ<>:old.FAHKSRQ or
             :new.FAHJZRQ<>:old.FAHJZRQ or
             :new.PINZ<>:old.PINZ or
             :new.KAISYSRQ<>:old.KAISYSRQ or
             :new.JIESYSRQ<>:old.JIESYSRQ or
             :new.SHOUKDW<>:old.SHOUKDW or
             :new.KAIHYH<>:old.KAIHYH or
             :new.DAIBCC<>:old.DAIBCC or
             :new.yuanshr<>:old.yuanshr or
             :new.zhangh<>:old.zhangh or
             :new.fapbh<>:old.fapbh or
             :new.fukfs<>:old.fukfs or
             :new.duifdd<>:old.duifdd or
             :new.ches<>:old.ches or
             :new.jiessl<>:old.jiessl or
             :new.JIESLX<>:old.JIESLX or
             :new.JIESRQ<>:old.JIESRQ or
             :new.yingd<>:old.yingd or
             :new.kuid<>:old.kuid or
             :new.SHULZJBZ<>:old.SHULZJBZ or
             :new.QITKK<>:old.QITKK or
             :new.JIASJE<>:old.JIASJE or
             :new.JIAKHJ<>:old.JIAKHJ or
             :new.JIAKSK<>:old.JIAKSK or
 	           :new.ruzrq<>:old.ruzrq or
             :new.JIAKSL<>:old.JIAKSL)and :old.kuangfjs=0 then
             AddInterfaceTask ('jiesb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.jiesrq);
          end if;
           if (:new.DIANCXXB_ID<>:old.DIANCXXB_ID or
             :new.CHANGBB_ID<>:old.CHANGBB_ID or
             :new.JIESBH<>:old.JIESBH or
             :new.FAHDWB_ID<>:old.FAHDWB_ID or
             :new.MEIKXXB_ID<>:old.MEIKXXB_ID or
             :new.CHEZXXB_ID<>:old.CHEZXXB_ID or
             :new.FAHKSRQ<>:old.FAHKSRQ or
             :new.FAHJZRQ<>:old.FAHJZRQ or
             :new.PINZ<>:old.PINZ or
             :new.KAISYSRQ<>:old.KAISYSRQ or
             :new.JIESYSRQ<>:old.JIESYSRQ or
             :new.SHOUKDW<>:old.SHOUKDW or
             :new.KAIHYH<>:old.KAIHYH or
             :new.DAIBCC<>:old.DAIBCC or
             :new.yuanshr<>:old.yuanshr or
             :new.zhangh<>:old.zhangh or
             :new.fapbh<>:old.fapbh or
             :new.fukfs<>:old.fukfs or
             :new.duifdd<>:old.duifdd or
             :new.ches<>:old.ches or
             :new.jiessl<>:old.jiessl or
             :new.JIESLX<>:old.JIESLX or
             :new.JIESRQ<>:old.JIESRQ or
             :new.yingd<>:old.yingd or
             :new.kuid<>:old.kuid or
             :new.SHULZJBZ<>:old.SHULZJBZ or
             :new.QITKK<>:old.QITKK or
             :new.JIASJE<>:old.JIASJE or
             :new.JIAKHJ<>:old.JIAKHJ or
             :new.JIAKSK<>:old.JIAKSK or
 	           :new.ruzrq<>:old.ruzrq or
             :new.JIAKSL<>:old.JIAKSL) and :old.kuangfjs=2 then
             select id into v_id
             from jiesb js
             where js.jiesbh=:old.jiesbh and js.kuangfjs=1 ;
             AddInterfaceTask ('jiesb',v_id,1,:new.changbb_id,'xml',:new.id,:new.jiesrq);
             AddInterfaceTask ('jiesb',v_id,0,:new.changbb_id,'xml',:new.id,:new.jiesrq);
          end if;
          --jiesyf
          if (:new.DIANCXXB_ID<>:old.DIANCXXB_ID or
             :new.CHANGBB_ID<>:old.CHANGBB_ID or
             :new.JIESBH<>:old.JIESBH or
             :new.FAHDWB_ID<>:old.FAHDWB_ID or
             :new.MEIKXXB_ID<>:old.MEIKXXB_ID or
             :new.CHEZXXB_ID<>:old.CHEZXXB_ID or
             :new.FAHKSRQ<>:old.FAHKSRQ or
             :new.FAHJZRQ<>:old.FAHJZRQ or
             :new.PINZ<>:old.PINZ or
             :new.KAISYSRQ<>:old.KAISYSRQ or
             :new.JIESYSRQ<>:old.JIESYSRQ or
             :new.SHOUKDW<>:old.SHOUKDW or
             :new.KAIHYH<>:old.KAIHYH or
             :new.DAIBCC<>:old.DAIBCC or
             :new.yuanshr<>:old.yuanshr or
             :new.zhangh<>:old.zhangh or
             :new.fapbh<>:old.fapbh or
             :new.fukfs<>:old.fukfs or
             :new.duifdd<>:old.duifdd or
             :new.ches<>:old.ches or
             :new.jiessl<>:old.jiessl or
             :new.JIESLX<>:old.JIESLX or
             :new.JIESRQ<>:old.JIESRQ or
             :new.yingd<>:old.yingd or
             :new.kuid<>:old.kuid or
             :new.GUOTYF<>:old.GUOTYF or
             :new.ZHUANXYF<>:old.ZHUANXYF or
             :new.KUANGQYF<>:old.KUANGQYF or
             :new.DITYF<>:old.DITYF or
             :new.DUANTYF<>:old.DUANTYF or
             :new.YUNFSL<>:old.YUNFSL or
	           :new.ruzrq<>:old.ruzrq or
             :new.QITYF<>:old.QITYF)and :old.kuangfjs=0 then
             AddInterfaceTask ('jiesyfb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.jiesrq);
          end if;
          if (:new.DIANCXXB_ID<>:old.DIANCXXB_ID or
             :new.CHANGBB_ID<>:old.CHANGBB_ID or
             :new.JIESBH<>:old.JIESBH or
             :new.FAHDWB_ID<>:old.FAHDWB_ID or
             :new.MEIKXXB_ID<>:old.MEIKXXB_ID or
             :new.CHEZXXB_ID<>:old.CHEZXXB_ID or
             :new.FAHKSRQ<>:old.FAHKSRQ or
             :new.FAHJZRQ<>:old.FAHJZRQ or
             :new.PINZ<>:old.PINZ or
             :new.KAISYSRQ<>:old.KAISYSRQ or
             :new.JIESYSRQ<>:old.JIESYSRQ or
             :new.SHOUKDW<>:old.SHOUKDW or
             :new.KAIHYH<>:old.KAIHYH or
             :new.DAIBCC<>:old.DAIBCC or
             :new.yuanshr<>:old.yuanshr or
             :new.zhangh<>:old.zhangh or
             :new.fapbh<>:old.fapbh or
             :new.fukfs<>:old.fukfs or
             :new.duifdd<>:old.duifdd or
             :new.ches<>:old.ches or
             :new.jiessl<>:old.jiessl or
             :new.JIESLX<>:old.JIESLX or
             :new.JIESRQ<>:old.JIESRQ or
             :new.yingd<>:old.yingd or
             :new.kuid<>:old.kuid or
             :new.GUOTYF<>:old.GUOTYF or
             :new.ZHUANXYF<>:old.ZHUANXYF or
             :new.KUANGQYF<>:old.KUANGQYF or
             :new.DITYF<>:old.DITYF or
             :new.DUANTYF<>:old.DUANTYF or
             :new.YUNFSL<>:old.YUNFSL or
	           :new.ruzrq<>:old.ruzrq or
             :new.QITYF<>:old.QITYF)and :old.kuangfjs=2 then
             select id into v_id
             from jiesb js
             where js.jiesbh=:old.jiesbh and js.kuangfjs=1 ;
             AddInterfaceTask ('jiesyfb',v_id,1,:new.changbb_id,'xml',:new.id,:new.jiesrq);
             AddInterfaceTask ('jiesyfb',v_id,0,:new.changbb_id,'xml',:new.id,:new.jiesrq);
          end if;
          --
          if (:new.yansrl<>:old.yansrl or
          :new.yansl<>:old.yansl or
          :new.gongfsl<>:old.gongfsl or
          :new.jiessl<>:old.jiessl or
          :new.shulzjbz<>:old.shulzjbz or
          :new.shulzjje<>:old.shulzjje or
          :new.yanssl<>:old.yanssl or
          :new.liuzjbz<>:old.liuzjbz or
          :new.liuzjje<>:old.liuzjje or
          :new.relzjbz<>:old.relzjbz or
          :new.relzjje<>:old.relzjje)and :old.kuangfjs=0  then
             AddInterfaceTask ('jieszbsjb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.jiesrq);
          end if;
          if (:new.yansrl<>:old.yansrl or
          :new.yansl<>:old.yansl or
          :new.gongfsl<>:old.gongfsl or
          :new.jiessl<>:old.jiessl or
          :new.shulzjbz<>:old.shulzjbz or
          :new.shulzjje<>:old.shulzjje or
          :new.yanssl<>:old.yanssl or
          :new.liuzjbz<>:old.liuzjbz or
          :new.liuzjje<>:old.liuzjje or
          :new.relzjbz<>:old.relzjbz or
          :new.relzjje<>:old.relzjje)and :old.kuangfjs=2  then
           select id into v_id
             from jiesb js
             where js.jiesbh=:old.jiesbh and js.kuangfjs=1 ;
             AddInterfaceTask ('jieszbsjb',v_id,1,:new.changbb_id,'xml',:new.id,:new.jiesrq);
             AddInterfaceTask ('jieszbsjb',v_id,0,:new.changbb_id,'xml',:new.id,:new.jiesrq);
          end if;
        end if;
     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_jiesb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_jiesb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_jiesb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
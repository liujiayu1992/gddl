create FUNCTION getQicrjh_Chelzt(qicrjhbId long,chelxxbId long) return varchar2 is
Result varchar2(200);
-- 得到汽车日计划派车的当日车辆状态，
--   如果是1就直接返回那个日计划的日期和计划名称，否则是空值
  begin
       declare
       cursor Chelzt is
            select to_char(jh.riq,'yyyy-MM-dd')||','||jh.mingc as zhuangt from qicrjhcpb gl,qicrjhb jh
                   where gl.qicrjhb_id=jh.id
                         and jh.riq=to_date(to_char((select riq from qicrjhb
                             where id=qicrjhbId),'yyyy-MM-dd'),'yyyy-MM-dd')
                                   and gl.chelxxb_id=chelxxbId and jh.id<>qicrjhbId
                                   and gl.zhuangt=1;
            begin
                open Chelzt;
                     fetch Chelzt into Result;
                     while Chelzt%found  loop

                           exit when Result is not null;

                           fetch Chelzt into Result;
                     end loop;
                close Chelzt;
            end;

           return(Result);
  end getQicrjh_Chelzt;

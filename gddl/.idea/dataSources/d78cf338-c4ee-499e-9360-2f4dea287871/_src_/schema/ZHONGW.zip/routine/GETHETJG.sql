create function getHetjg(m_id in Number,m_shangx in Number,m_xiax in Number,m_tiaojbm in varchar2) return number is
begin
    declare
        jizzb  number(10,2):=0;
        jiag number(10,2);
        rezsx number(10,2);
        rezxx number(10,2);
        jia number(20,5);
        tiaojbm varchar2(20);
        danwmc varchar2(20);

        cursor H_JG is select shangx ,xiax,jij,t.bianm,dw.bianm from hetjgb hj,tiaojb t,danwb dw
               where hj.hetb_id=m_id and hj.tiaojb_id=t.id and hj.jijdwid=dw.id ;
        begin
        --------------

          if m_tiaojbm='大于' then
                jizzb:=m_xiax;
          elsif  m_tiaojbm='大于等于' then
                jizzb:=m_xiax;
          elsif m_tiaojbm='小于' then
                jizzb:=m_shangx;
          elsif m_tiaojbm='小于等于'  then
                jizzb:=m_shangx;
          elsif m_tiaojbm='等于' then
                jizzb:=m_xiax;
          elsif m_tiaojbm='区间' then
                jizzb:=m_xiax;
          end if;
        --------------
        open H_JG;
        if jizzb=0 then

            fetch H_JG into rezsx,rezxx,jiag,tiaojbm,danwmc;
           close H_JG;
        else
                   loop
                        fetch H_JG into rezsx,rezxx,jiag,tiaojbm,danwmc;
                        exit when H_JG%notfound ;
                            -- jizzb shangx,xiax;
                        if  tiaojbm='区间' then
                            if jizzb <= rezsx and jizzb >= rezxx then
                            jia:=jiag;
                            end if;
                      elsif  tiaojbm='等于' then
                            if jizzb = rezsx and jizzb = rezxx then
                            jia:=jiag;
                            end if;
                       elsif tiaojbm='大于'then
                             if jizzb > rezxx  then
                             jia:=jiag;
                             end if;
                       elsif tiaojbm='小于'then
                             if jizzb < rezsx then
                             jia:=jiag;
                             end if;
                       elsif tiaojbm='大于等于' then
                             if jizzb>=rezxx then
                             jia:=jiag;
                             end if;
                       elsif tiaojbm='小于等于' then
                             if jizzb<= rezsx then
                             jia:=jiag;
                             end if;
                       end if;
                   end loop;
               close H_JG;
       end if;
                     if danwmc='元/千卡' then
                        --jia:= round(jiag*(jizzb*7000/29.271),5);
                        jia:= round(jiag*jizzb,5);
                     elsif danwmc='元/吨' then
                        jia:= jiag;
                     end if;
                 return(jia);
        end;
end ;

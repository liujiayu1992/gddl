create Function getJianycph (jiesbid Number) Return Varchar2 Is
Begin
    Declare
      cheph Varchar2(4000) :='';
      v_loopcounter Integer :=1;
      Cursor my_cursor Is
        Select cheph From chepb Where jiesb_id=jiesbid Order By xuh;
      my_rec my_cursor%Rowtype;
    Begin
      Open my_cursor;
        Loop
          Fetch my_cursor Into my_rec;
            Exit When my_cursor%Notfound;
            If v_loopcounter = 1 Then
              cheph := my_rec.cheph;
            Else
                cheph := cheph||','||my_rec.cheph;
            End If;
          v_loopcounter := v_loopcounter + 1;
        End Loop;
      Close my_cursor;
      Return cheph;
    End;
End;

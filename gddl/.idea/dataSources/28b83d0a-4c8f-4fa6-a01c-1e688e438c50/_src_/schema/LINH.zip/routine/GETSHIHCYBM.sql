create FUNCTION        "GETSHIHCYBM" (cyriq in date,Xuh in number)
  Return  varchar2 as
  begin
       begin
            return to_char(cyriq,'yymmdd') || trim(to_char(Xuh,'000'));
       end;
  end;

 
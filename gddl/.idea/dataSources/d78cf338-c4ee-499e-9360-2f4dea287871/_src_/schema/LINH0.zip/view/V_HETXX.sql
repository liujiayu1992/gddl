create view V_HETXX as
Select Id,faz,heth,meikdqfdw_id,diancxxb_id,
    qiandrq,qissj,guoqsj,(Select quanc From fahdwb Where Id = meikdqfdw_id) As gonghsqc,fahr
    From (
        Select hetxxb.Id, j.faz As faz,hetxxb.heth,hetxxb.meikdqfdw_id ,
        hetxxb.diancxxb_id,hetxxb.qiandrq,hetxxb.qissj,hetxxb.guoqsj,hetxxb.fahr
        From hetxxb ,nianjhhtb j
        Where bucxybz =0
        And hetxxb.Id = j.hetxxb_id
        And hetxxb.Id In ( Select hetxxb_id From hetjsxyb )
      Union
        Select
        b.Id As Id,j.faz As faz,
        b.bucxybh As ,h.meikdqfdw_id,h.diancxxb_id,
        b.qiandrq,b.qissj,b.guoqsj,b.fahr
        From
        (Select * From hetxxb Where bucxybz = 0) h,
        (Select * From hetxxb Where bucxybz = 1) b,nianjhhtb j
        Where h.heth = b.heth
        And h.Id = j.hetxxb_id
  ) t
With Read Only


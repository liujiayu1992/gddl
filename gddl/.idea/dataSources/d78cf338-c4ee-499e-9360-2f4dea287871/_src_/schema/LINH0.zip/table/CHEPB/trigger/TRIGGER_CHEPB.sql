create trigger TRIGGER_CHEPB
	before insert or update or delete
	on CHEPB
	for each row
Declare
  v_id          fahb.changbb_id%Type;
  v_bz          fahb.hedbz%Type;
Begin
       if updating then
              select changbb_id into v_id from fahb f
               where f.id=:new_value.fahb_id;

              select hedbz into v_bz from fahb f
               where f.id=:new_value.fahb_id;

              if :new_value.fahb_id<>:old_value.fahb_id then
		 --fahb_id 改变时,需要记录更新前、更新后两发货的任务
       		 AddInterfaceTask ('fahb',:new_value.fahb_id,0,v_id,'xml',:new_value.fahb_id,:new_value.guohsj);
       		 AddInterfaceTask ('fahb',:old_value.fahb_id,0,v_id,'xml',:old_value.fahb_id,:new_value.guohsj);
 	       end if;
               if :new_value.MAOZ<>:old_value.MAOZ or
                  :new_value.PIZ<>:old_value.PIZ or
                  :new_value.BIAOZ<>:old_value.BIAOZ or
                  :new_value.YINGK<>:old_value.YINGK or
                  :new_value.YUNS<>:old_value.YUNS or
                  :new_value.YUNSL<>:old_value.YUNSL or
                  :new_value.KOUD<>:old_value.KOUD or
                  :new_value.YINGD<>:old_value.YINGD or
                  :new_value.KUID<>:old_value.KUID or
                   :new_value.jiesb_id<>:old_value.jiesb_id or--取代更新指令
                  to_char(:new_value.guohsj,'yyyy-mm-dd')<>to_char(:old_value.guohsj,'yyyy-mm-dd') or
                  :new_value.KOUSSL<>:old_value.KOUSSL then
                  AddInterfaceTask ('fahb',:old_value.fahb_id,2,v_id,'xml',:new_value.fahb_id,:new_value.guohsj);
                end if;
               if :new_value.meijb_id<>:old_value.meijb_id then
                 AddInterfaceTask ('fahb',:old_value.fahb_id,3,v_id,'修改meijb_id',:new_value.jiesb_id,:new_value.guohsj);
               end if;
      elsif inserting then
                select changbb_id into v_id from fahb f
                where f.id=:new_value.fahb_id;
                AddInterfaceTask ('fahb',:new_value.fahb_id,2,v_id,'xml',:new_value.fahb_id,:new_value.guohsj);
      elsif deleting then
                select changbb_id into v_id from fahb f
                where f.id=:old_value.fahb_id;
                AddInterfaceTask ('fahb',:old_value.fahb_id,2,v_id,'xml',:old_value.fahb_id,:old_value.guohsj);
      end if;
      exception
        when others then
        if inserting then
           zengjrz('trigger_chepb',:new_value.fahb_id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_chepb',:old_value.fahb_id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_chepb',:old_value.fahb_id,'修改',SQLCODE,SQLERRM);
        end if;
End;
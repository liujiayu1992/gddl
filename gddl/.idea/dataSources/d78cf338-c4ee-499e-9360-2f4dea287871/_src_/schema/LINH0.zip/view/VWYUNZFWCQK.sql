create view VWYUNZFWCQK as
select  nianf,yuef,changbb_id,'本月' xiangm, hej bhej,thej thej,(hej-nvl(thej,0)) zzl,tielyf btielyf,ttielyf ttielyf
	,fazzf bfazzf,tfazzf tfazzf,daozzf bdaozzf,tdaozzf tdaozzf,changnzf bchangnzf,tchangnzf tchangnzf
	,qiyf bqiyf,tqiyf tqiyf,haiyf bhaiyf,thaiyf thaiyf from
	(select y.nianf,y.yuef,y.changbb_id,
	nvl((select hej from yunzfwcqk where nianf = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) hej,
	nvl((select tielyf from yunzfwcqk where nianf = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) tielyf,
	nvl((select fazzf from yunzfwcqk where nianf = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) fazzf,
	nvl((select daozzf from yunzfwcqk where nianf = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) daozzf,
	nvl((select changnzf from yunzfwcqk where nianf = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) changnzf,
	nvl((select qiyf from yunzfwcqk where nianf = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) qiyf,
	nvl((select haiyf from yunzfwcqk where nianf = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) haiyf,
	nvl((select hej from yunzfwcqk where nianf+1 = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) thej,
	nvl((select tielyf from yunzfwcqk where nianf+1 = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) ttielyf,
	nvl((select fazzf from yunzfwcqk where nianf+1 = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) tfazzf,
	nvl((select daozzf from yunzfwcqk where nianf+1 = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) tdaozzf,
	nvl((select changnzf from yunzfwcqk where nianf+1 = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) tchangnzf,
  nvl((select qiyf from yunzfwcqk where nianf+1 = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) tqiyf,
  nvl((select haiyf from yunzfwcqk where nianf+1 = y.nianf and yuef = y.yuef and changbb_id = y.changbb_id),0) thaiyf
  from yunzfwcqk y) union
  select  nianf,yuef,changbb_id,'累计' xiangm, hej bhej,thej thej,(hej-nvl(thej,0)) zzl,tielyf btielyf,ttielyf ttielyf
  ,fazzf bfazzf,tfazzf tfazzf,daozzf bdaozzf,tdaozzf tdaozzf,changnzf bchangnzf,tchangnzf tchangnzf
  ,qiyf bqiyf,tqiyf tqiyf,haiyf bhaiyf,thaiyf thaiyf from
  (select y.nianf,y.yuef,y.changbb_id,
  nvl((select sum(hej)/count(*) from yunzfwcqk where nianf = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) hej,
  nvl((select sum(tielyf)/count(*) from yunzfwcqk where nianf = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) tielyf,
  nvl((select sum(fazzf)/count(*) from yunzfwcqk where nianf = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) fazzf,
  nvl((select sum(daozzf)/count(*) from yunzfwcqk where nianf = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) daozzf,
  nvl((select sum(changnzf)/count(*) from yunzfwcqk where nianf = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) changnzf,
  nvl((select sum(qiyf)/count(*) from yunzfwcqk where nianf = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) qiyf,
  nvl((select sum(haiyf)/count(*) from yunzfwcqk where nianf = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) haiyf,
  nvl((select sum(hej)/count(*) from yunzfwcqk where nianf+1 = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) thej,
  nvl((select sum(tielyf)/count(*) from yunzfwcqk where nianf+1 = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) ttielyf,
  nvl((select sum(fazzf)/count(*) from yunzfwcqk where nianf+1 = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) tfazzf,
  nvl((select sum(daozzf)/count(*) from yunzfwcqk where nianf+1 = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) tdaozzf,
  nvl((select sum(changnzf)/count(*) from yunzfwcqk where nianf+1 = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) tchangnzf,
  nvl((select sum(qiyf)/count(*) from yunzfwcqk where nianf+1 = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) tqiyf,
  nvl((select sum(haiyf)/count(*) from yunzfwcqk where nianf+1 = y.nianf and yuef <= y.yuef and changbb_id = y.changbb_id),0) thaiyf
  from yunzfwcqk y)


create trigger TRIGGER_NIANDJHFB
	before insert or update or delete
	on NIANDJHFB
	for each row
Begin

     if inserting and :new.shenhzt=1 then
          AddInterfaceTask ('niancgjh',:new.id,0,:new.changbb_id,'xml',:new.id, to_date(:new.niand||'-01-01','yyyy-mm-dd'));
          AddInterfaceTask ('niancgjhfb',:new.id,0,:new.changbb_id,'xml',:new.id, to_date(:new.niand||'-01-01','yyyy-mm-dd'));
     elsif deleting and :old.shenhzt=1 then
          AddInterfaceTask ('niancgjh',:old.id,1,:old.changbb_id,'xml',:old.id, to_date(:old.niand||'-01-01','yyyy-mm-dd'));
          AddInterfaceTask ('niancgjhfb',:new.id,1,:new.changbb_id,'xml',:new.id, to_date(:new.niand||'-01-01','yyyy-mm-dd'));
     elsif updating and :new.shenhzt=1 then
          AddInterfaceTask ('niancgjh',:new.id,2,:new.changbb_id,'xml',:new.id,to_date(:new.niand||'-01-01','yyyy-mm-dd'));
          AddInterfaceTask ('niancgjhfb',:new.id,2,:new.changbb_id,'xml',:new.id, to_date(:new.niand||'-01-01','yyyy-mm-dd'));
     end if ;

     exception
     when others then
        if inserting then
           zengjrz('trigger_niandjhfb',:new.id,'增加',SQLCODE,SQLERRM);
           zengjrz('trigger_niancgjhfb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_niandjhfb',:old.id,'删除',SQLCODE,SQLERRM);
            zengjrz('trigger_niancgjhfb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_niandjhfb',:old.id,'修改',SQLCODE,SQLERRM);
            zengjrz('trigger_niancgjhfb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;

create view VWGONGYSMK_HET as
select rownum wid,id,mingc,fuid,jib,diancxxb_id from
(select 2 jib,0 fuid,g.id,g.mingc,gl.diancxxb_id
        from gongysb g, gongysdcglb gl
        where g.id = gl.gongysb_id and g.leix = 1
union
select 3 jib,g.id fuid,d.id,d.mingc,gl.diancxxb_id
       from  gongysmkglb ml,gongysdcglb gl,gongysb g,hetb h,diancxxb d
       where ml.gongysb_id = gl.gongysb_id
       and g.id = gl.gongysb_id and g.leix = 1
       and g.id=h.gongysb_id
       and h.xufdwmc=d.quanc

)


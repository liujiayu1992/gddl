create Package Pkg_Gusmj Is
  Type c_hetjsxyb Is Ref Cursor;

  Procedure p_GetHetxy(Choice In Number,
                      Cur Out c_hetjsxyb,
                      Xianm In Number,
                      Fanw In Varchar2,
                      Biaoz In Number,
                      Zhib In Number,
                      hetid In Number);

End Pkg_Gusmj;

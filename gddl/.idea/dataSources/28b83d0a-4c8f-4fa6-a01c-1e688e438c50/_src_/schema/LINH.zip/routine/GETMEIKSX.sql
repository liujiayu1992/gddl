create FUNCTION        "GETMEIKSX" (lngMeikxxb_id In number,lngDiancxxb_id In number,strShuxbm In varchar2)
Return  number as
begin
     declare  zhi number;
     begin

         select nvl(min(gl.zhi),0) into zhi from meikxxb m,meiksxglb gl
           where m.id=gl.meikxxb_id and m.id=lngMeikxxb_id and
                 gl.diancxxb_id=lngDiancxxb_id and gl.shifsy=1 and shuxbm=''||strShuxbm||'';

         if not (zhi is null) then

            Return zhi;
         else

            Return 0;
         end if;
     end;
End;

 
create view VWFAHDW as
select meikxxb.id,meikxxb.meikdwmc as fahdw
from meikxxb,changkglb
where meikxxb.id=changkglb.Meikxxb_Id
and changkglb.zhuangt=1
union
select id,fahdwb.jianc as fahdw
from fahdwb
where zhuangt=1
union
select meikdqb.id,meikdqb.meikdqmc as fahdw
from meikdqb,changkglb
where meikdqb.id=changkglb.Meikxxb_Id
and changkglb.zhuangt=1
WITH READ ONLY


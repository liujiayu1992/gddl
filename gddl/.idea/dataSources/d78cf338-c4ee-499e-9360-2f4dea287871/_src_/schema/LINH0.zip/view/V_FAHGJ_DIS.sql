create view V_FAHGJ_DIS as
Select Distinct f.Id As Fahb_Id,
                  k.Id As Meikxxb_Id,
                  z.Id As Faz_Id,
                  f.Fahrq,
                  c.Biaoz,
                  y.Zongje,c.jiesb_id,c.jiesb_id1,d.yunfdjb_id
    From Fahb f,
         Meikxxb k,
         Chezxxb z,
         Chepb c,
         Danjcpb d,
         (Select Yunfdjb_Id As Id, Sum(Zhi) As Zongje
            From Feiyb
           Where Shuib = 0
           And Leix = 0
           Group By Yunfdjb_Id
          Having Sum(Zhi) >= 0) y
   Where f.Id = c.Fahb_Id
     And f.Meikxxb_Id = k.Id
     And f.Faz_Id = z.Id
     And c.Id = d.Chepb_Id
     And d.Yunfdjb_Id = y.Id
     And c.Tuosbh Is Not Null
     And c.Id > 0
With Read Only


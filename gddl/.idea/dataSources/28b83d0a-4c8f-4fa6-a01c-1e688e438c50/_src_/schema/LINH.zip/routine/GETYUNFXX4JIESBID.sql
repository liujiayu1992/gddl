create FUNCTION        "GETYUNFXX4JIESBID" (jiesbid in number, colName in varchar2) return number is
   -- 根据jiesb_id和jiesyfb表的一个列名，查询出该列对应的值
  Result number;
  yunf number;
  begin
     execute immediate 'select nvl(sum('||colName||'), 0)
            from (select fh.jiesb_id, dj.yunfjsb_id, yf.'||colName||'
                    from fahb fh, chepb cp, danjcpb dj, jiesyfb yf
                   where fh.jiesb_id = '||jiesbid||'
                     and cp.fahb_id = fh.id
                     and dj.chepb_id = cp.id
                     and dj.yunfjsb_id = yf.id
                   group by rollup(fh.jiesb_id, dj.yunfjsb_id, yf.'||colName||')
                  having grouping(yf.'||colName||') = 0)' into yunf;

             if not (yunf is null) then
                 Result:=yunf;
             else
                 Result:=0;
             end if;
       return (Result);
 end getYunfxx4Jiesbid;

 
create trigger TRG_JK_TRUCKENTER
	before insert
	on JK_TRUCKENTER
	for each row
declare
  -- local variables here
begin
  select SEQ_JK_TRUCKENTER.Nextval into :new.id from dual;
end trg_jk_truckenter;


create view V_FAHGJ as
Select Distinct f.Id As fahb_id,k.Id As meikxxb_id,z.Id As
  faz_id,f.fahrq,c.biaoz,y.zongje,c.jiesb_id,c.jiesb_id1,d.yunfdjb_id,f.Yunsfs
  From fahb f,meikxxb k,chezxxb z,chepb c,danjcpb d,(
  Select Yunfdjb_Id As id,Sum(zhi) As zongje From feiyb fy
  Where fy.Leix = 0
  Group By fy.Yunfdjb_Id ) y
  Where f.Id = c.fahb_id
  And f.meikxxb_id = k.Id
  And f.faz_id = z.Id
  And c.Id = d.chepb_id
  And d.yunfdjb_id = y.Id
  And c.tuosbh Is Not Null
  And c.Id > 0
With Read Only


create view VWHETLWCQKFK as
select hj.nianf,hj.yuef,hj.changbb_id,hj.dw dw, hj.xiangm,hj.jihl jihl,hj.daohl daohl
	,round_new(decode(hj.jihl,0,0,hj.daohl*100/hj.jihl),2) daohv
	,hj.nianhtl nianhtl,round_new(decode(hj.nianhtl,0,0,hj.daohl*100/hj.nianhtl),2) as nianhtwcl from
	(select nvl(f.jianc,'合计') as dw,h.nianf,h.yuef,h.changbb_id,'本月' as xiangm,sum(h.jihl) jihl,sum(h.daohl) daohl
	,sum(h.nianhtl) nianhtl from hetlwcqkfkb h,fahdwb f where h.fahdwb_id = f.id group by f.jianc,h.nianf,h.yuef,h.changbb_id
	union
	select nvl(f.jianc,'合计') as dw,h.nianf,h.yuef,h.changbb_id,'累计' as xiangm,
	(select sum(jihl) from hetlwcqkfkb where nianf =h.nianf and yuef <= h.yuef
	and changbb_id= h.changbb_id and fahdwb_id = h.fahdwb_id ) jihl,
	(select sum(daohl) from hetlwcqkfkb where nianf =h.nianf and yuef <= h.yuef
	and changbb_id= h.changbb_id and fahdwb_id = h.fahdwb_id ) daohl,
	(select sum(nianhtl) from hetlwcqkfkb where nianf =h.nianf and yuef <= h.yuef
	and changbb_id= h.changbb_id and fahdwb_id = h.fahdwb_id ) nianhtl
	from hetlwcqkfkb h,fahdwb f where h.fahdwb_id = f.id
	) hj


create view VWYUESL as
select dy.jihkjb_id,dy.gongysb_id,dy.diancxxb_id, dy.riq,
       nvl(sum(decode(dy.fenx,'本月',dy.jingz)),0) jbeny,
       nvl(sum(decode(dy.fenx,'累计',dy.jingz)),0) jleij,
       nvl(sum(decode(dy.fenx,'本月',sy.jingz)),0) jsy,
       nvl(sum(decode(dy.fenx,'累计',tq.jingz)),0) jtq,
       nvl(sum(decode(dy.fenx,'本月',dy.yuns)),0) ybeny,
       nvl(sum(decode(dy.fenx,'累计',dy.yuns)),0) yleij,
       nvl(sum(decode(dy.fenx,'本月',sy.yuns)),0) ysy,
       nvl(sum(decode(dy.fenx,'累计',tq.yuns)),0) ytq
      -- dy.shouml,nvl(sy.shouml,0) sy,nvl(tq.shouml,0) tq
       from
(select  k.diancxxb_id,k.jihkjb_id,k.gongysb_id,k.riq,y.fenx,y.jingz,
y.yuns
       from yueslb y, yuetjkjb k
where y.yuetjkjb_id = k.id --and k.riq = to_date('2008-05-01','yyyy-mm-dd')
) dy,
(select  k.diancxxb_id,k.jihkjb_id,k.gongysb_id,k.riq,y.fenx,y.jingz,
y.yuns
       from yueslb y, yuetjkjb k
where y.yuetjkjb_id = k.id --and k.riq = add_months(to_date('2008-05-01','yyyy-mm-dd'),-1)
) sy,
(select  k.diancxxb_id,k.jihkjb_id,k.gongysb_id,k.riq,y.fenx,y.jingz,
y.yuns
       from yueslb y, yuetjkjb k
where y.yuetjkjb_id = k.id --and k.riq = add_months(to_date('2008-05-01','yyyy-mm-dd'),-12)
) tq
where dy.diancxxb_id = sy.diancxxb_id (+) and dy.diancxxb_id = tq.diancxxb_id(+)
and dy.jihkjb_id = sy.jihkjb_id(+) and dy.jihkjb_id = tq.jihkjb_id(+)
and dy.gongysb_id = sy.gongysb_id (+) and dy.gongysb_id = tq.gongysb_id(+)
and dy.fenx = sy.fenx(+) and dy.fenx = tq.fenx(+)
and dy.riq = add_months(sy.riq(+),-1) and dy.riq = add_months(tq.riq(+),-12)
--and dy.diancxxb_id = 201
group by dy.jihkjb_id,dy.gongysb_id,dy.diancxxb_id, dy.riq


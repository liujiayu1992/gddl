create package OFS is

  procedure init_root;
  function os_user return varchar2;

  -- Cursor type to return directory entries.
  -- Includes all OFS_ITEMS columns, except id, parent_id, and data.
  -- It also includes dbms_lob.getlength(data) as size.
  type dir_cursor is ref cursor;

  -- Get directory entries.
  -- %param p_path    \dir1\dir2
  -- %param p_mask    hello*.da?[; mask2[; ...]]
  -- %param p_alldirs 'Y' - include all subdirs, 'N' - subdirs according mask
  -- %param p_crs     cursor with the matching directory entries
  procedure get_dir(p_path    in varchar2,
                    p_mask    in varchar2,
                    p_alldirs in varchar2,
                    p_crs     in out dir_cursor);

  -- Read file data.
  -- %param p_filename \dir1\dir2\file.ext
  function read_file(p_filename in varchar2) return blob;

  -- Write file data.
  -- File must be unlocked or locked by current OS user and not read_only.
  -- For new files, parent directory must not be read_only. New files in a
  -- compressed directory are implicitly compressed.
  -- %param p_filename \dir1\dir2\file.ext
  -- %param p_data temporary BLOB with all file data
  procedure write_file(p_filename in varchar2,
                       p_data     in blob);

  -- Create directory.
  -- Parent directory must not be read_only.
  -- %param p_dirname \dir1\dir
  procedure create_dir(p_dirname in varchar2);

  -- Delete file or directory.
  -- File must be unlocked or locked by current OS user and not read_only.
  -- Directory must not be read_only.
  -- Parent directory must not be read_only.
  -- %param p_dirname \dir1\dir or \dir1\file.ext
  procedure delete(p_itemname in varchar2);

  -- Set file or directory attribute.
  -- File must be unlocked or locked by current OS user.
  -- Compression is ignored on Oracle9.2 or earlier (utl_compress dependency).
  -- %param p_itemname The name of the file or directory
  -- %param p_attrname 'READ_ONLY', 'COMPRESSED' or 'LOCKED'
  -- %param p_value    'Y' or 'N'
  procedure set_attr(p_itemname in varchar2,
                     p_attrname in varchar2,
                     p_value    in varchar2);

  -- Get file or directory attribute.
  -- %param p_itemname The name of the file or directory
  -- %param p_attrname 'READ_ONLY', 'COMPRESSED' or 'LOCKED'
  -- %return 'Y' or 'N'
  function get_attr(p_itemname in varchar2,
                    p_attrname in varchar2) return varchar2;

  -- Get file or directory last modification date.
  function get_date(p_itemname in varchar2) return date;

  -- Lock file.
  -- File must be unlocked and not read_only.
  -- %param p_filename \dir1\dir2\file.ext
  procedure lock_file(p_filename in varchar2);

  -- Unlock file.
  -- File must be locked by current OS user
  -- %param p_filename \dir1\dir2\file.ext
  procedure unlock_file(p_filename in varchar2);

  -- Rename file or directory.
  -- File must be unlocked or locked by current OS user and not read_only.
  -- %param p_itemname \dir1\dir2\file.ext
  -- %param p_newname  newfile.ext
  procedure rename(p_itemname in varchar2, p_newname in varchar2);

  -- Move file or directory.
  -- File must be unlocked or locked by current OS user and not read_only.
  -- %param p_itemname \dir1\dir2\file.ext
  -- %param p_newdir   \dir1\dir2
  procedure move(p_itemname in varchar2, p_newdir in varchar2);

  -- Copy file or directory.
  -- File must be unlocked or locked by current OS user and not read_only.
  -- %param p_itemname \dir1\dir2\file.ext
  -- %param p_newdir   \dir1\dir2
  procedure copy(p_itemname in varchar2, p_newdir in varchar2);

  -- Tests if a specified file exists.
  -- %param p_filename \dir1\dir2\file.ext
  -- %return 'Y' or 'N'
  function file_exists(p_filename in varchar2) return char;

  -- Tests if a specified directory exists.
  -- %param p_path \dir1\dir2
  -- %return 'Y' or 'N'
  function directory_exists(p_path in varchar2) return char;

end OFS;

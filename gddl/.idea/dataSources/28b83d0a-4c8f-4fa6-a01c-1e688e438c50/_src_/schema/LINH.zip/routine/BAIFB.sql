create FUNCTION        "BAIFB" (dblFez in number, dblFenm in number) return number is
begin
     if (dblFenm is null) then
        return null;
     end if;

     if dblFenm=0 then
        return 0;
     end if;

     return round(dblFez/dblFenm*100,2);
end baifb;

 
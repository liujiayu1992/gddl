create function getJiesdzb_tz(Yansbhb_id in number,Zhibbm in varchar2,colname in varchar2) return varchar2 is

  zhibm varchar2(200);
begin
      execute immediate ' select to_char('|| colname ||') from jieszbsjb j,zhibb z  where j.zhibb_id=z.id and z.bianm='''||Zhibbm||''' and j.yansbhb_id='||Yansbhb_id
         into zhibm;
         if not (zhibm is null)  then

            return zhibm;
         else

            return '';
         end if;

end getJiesdzb_tz;

create FUNCTION gethetcxJiag(v_hetb_id number)--caolin合同查询用
Return  number as
begin
     declare
     v_jiag number;
     begin
          select max(decode(danwb.bianm,'元/千卡',round(jij*hetjgb.xiax,2),jij))jiag
            into v_jiag
            from hetjgb,danwb
            where hetjgb.xiax =(
            select max(xiax)shangx
            from hetjgb,zhibb
            where hetb_id=v_hetb_id and hetjgb.zhibb_id=zhibb.id
            ) and  hetb_id=v_hetb_id and hetjgb.jijdwid=danwb.id;
            return v_jiag;
     end;
end;

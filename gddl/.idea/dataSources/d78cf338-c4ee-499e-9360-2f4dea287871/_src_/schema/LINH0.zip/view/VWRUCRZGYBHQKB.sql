create view VWRUCRZGYBHQKB as
select nianf,fahdwb_id,changbb_id,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef =1 and fahdwb_id= r.fahdwb_id and changbb_id= r.changbb_id) as Jan,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef =2 and fahdwb_id= r.fahdwb_id and changbb_id= r.changbb_id) as Feb,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef =3 and fahdwb_id= r.fahdwb_id and changbb_id= r.changbb_id) as Mar,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef =4 and fahdwb_id= r.fahdwb_id and changbb_id= r.changbb_id) as Apr,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef =5 and fahdwb_id= r.fahdwb_id and changbb_id= r.changbb_id) as May,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef =6 and fahdwb_id= r.fahdwb_id and changbb_id= r.changbb_id) as Jun,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef =7 and fahdwb_id= r.fahdwb_id and changbb_id= r.changbb_id) as Jul,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef =8 and fahdwb_id= r.fahdwb_id and changbb_id= r.changbb_id) as Aug,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef =9 and fahdwb_id= r.fahdwb_id and changbb_id= r.changbb_id) as Sep,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef =10 and fahdwb_id= r.fahdwb_id and changbb_id= r.changbb_id) as Oct,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef =11 and fahdwb_id= r.fahdwb_id and changbb_id= r.changbb_id) as Nov,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef =12 and fahdwb_id= r.fahdwb_id and changbb_id= r.changbb_id) as Dec
	from (select distinct nianf,fahdwb_id,changbb_id from rezwcqkfkb) r


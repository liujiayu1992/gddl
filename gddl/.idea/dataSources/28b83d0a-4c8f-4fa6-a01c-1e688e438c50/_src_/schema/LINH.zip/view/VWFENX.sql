create view VWFENX as
select 1 as xuh,decode(1,1,'当日') as fenx from dual
union
select 2 as xuh,decode(1,1,'累计') as fenx from dual

 

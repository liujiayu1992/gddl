create FUNCTION        "GETGUSXX" (Fahb_id in number, colname in varchar2)
return varchar2 is
--最新估收信息
       zhi varchar2(50);
       Result varchar2(50);
begin
     execute immediate ' select * from (select to_char('|| colname ||') from guslsb where fahb_id='||Fahb_id||'
                          order by leix desc,id desc)t  where  rownum=1' into zhi;
                         if not (zhi is null)  then
                                Result:= zhi;
                         else
                                Result:='';
                         end if;
  return(Result);
end getGusxx;

 
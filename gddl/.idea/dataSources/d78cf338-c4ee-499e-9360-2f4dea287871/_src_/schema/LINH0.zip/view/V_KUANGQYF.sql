create view V_KUANGQYF as
SELECT meik_id,zhixrq,yuan_che,yuan_dun,shifyx,DAOZ_ID FROM kuangqyfb WHERE shifyx = 1
ORDER BY zhixrq desc


create view VWGONGHS as
Select Id,fahdwb_id gonghs,meikdqb_id meikdq,meikxxb_id meikdw ,zhixrq,beiz,chezxxb_id As chez
From gonghs


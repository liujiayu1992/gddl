create Function getZhilyq(hetid Number) Return Varchar2 Is
Begin
  Declare
    zhilyq        Varchar2(500) := '';
    v_loopcounter Integer := 1;
    Cursor my_cursor Is
      Select hetxmb.mingc || tiaoj || zhi || hetdwb.mingc As mingc
        From hetzlxyb, hetxmb, hetdwb
       Where hetzlxyb.xiangm = hetxmb.id
         And hetzlxyb.danw = hetdwb.id
         And hetzlxyb.hetxxb_id = hetid;
    my_rec my_cursor%Rowtype;
  Begin

    Open my_cursor;
    Loop
      Fetch my_cursor
        Into my_rec;
      Exit When my_cursor%Notfound;
      If v_loopcounter = 1 Then
        zhilyq := my_rec.mingc;
      Else
        zhilyq := zhilyq || '；' || my_rec.mingc;
      End If;
      v_loopcounter := v_loopcounter + 1;
    End Loop;
    Close my_cursor;
    Return zhilyq;
  End;
End;

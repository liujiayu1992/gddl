create function keyts_rijhm(lngDiancxxb_id in number,dangrhm in number,datRiq date) return number is
  Result number(10,2);
begin
    if nvl(dangrhm,0)>0 then
       return dangrhm;
    end if;

    --如果当日的耗煤为0，取最近10天有耗煤的平均值
    select avg(haoyqkdr) into Result from
        (select s.riq, s.haoyqkdr from shouhcrbb s where s.haoyqkdr>0
               and diancxxb_id=lngDiancxxb_id
               and s.riq>datRiq-60 --加入60天内的时间提高效率
               order by riq desc)
        where rownum<11;
    return Result;
end keyts_rijhm;

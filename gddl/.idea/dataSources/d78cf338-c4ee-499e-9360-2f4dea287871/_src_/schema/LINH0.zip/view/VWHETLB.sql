create view VWHETLB as
select "ID","HETXXB_ID","RIQ","HETL","FAZ","DAOZ","MEIZ","HEJ" from (
(select n.id, n.hetxxb_id,to_char(h.qissj,'yyyy')||'-01' as riq,n.y1 as hetl,n.faz,n.daoz,n.meiz,n.hej
from nianjhhtb n,hetxxb h where n.hetxxb_id=h.id )union
(select n.id,n.hetxxb_id,to_char(h.qissj,'yyyy')||'-02' as riq,n.y2 as hetl ,n.faz,n.daoz,n.meiz ,n.hej
from nianjhhtb n,hetxxb h where n.hetxxb_id=h.id )union
(select n.id,n.hetxxb_id,to_char(h.qissj,'yyyy')||'-03' as riq,n.y3 as hetl ,n.faz,n.daoz,n.meiz ,n.hej
from nianjhhtb n,hetxxb h where n.hetxxb_id=h.id )union
(select n.id,n.hetxxb_id,to_char(h.qissj,'yyyy')||'-04' as riq,n.y4 as hetl , n.faz,n.daoz,n.meiz ,n.hej
from nianjhhtb n,hetxxb h where n.hetxxb_id=h.id )union
(select n.id,n.hetxxb_id,to_char(h.qissj,'yyyy')||'-05' as riq,n.y5 as hetl,n.faz,n.daoz,n.meiz ,n.hej
from nianjhhtb n,hetxxb h where n.hetxxb_id=h.id )union
(select n.id,n.hetxxb_id,to_char(h.qissj,'yyyy')||'-06' as riq,n.y6 as hetl, n.faz,n.daoz,n.meiz ,n.hej
from nianjhhtb n,hetxxb h where n.hetxxb_id=h.id )union
(select n.id,n.hetxxb_id,to_char(h.qissj,'yyyy')||'-07' as riq,n.y7 as hetl, n.faz,n.daoz,n.meiz,n.hej
from nianjhhtb n,hetxxb h where n.hetxxb_id=h.id )union
(select n.id,n.hetxxb_id,to_char(h.qissj,'yyyy')||'-08' as riq,n.y8 as hetl ,n.faz,n.daoz,n.meiz ,n.hej
from nianjhhtb n,hetxxb h where n.hetxxb_id=h.id )union
(select n.id,n.hetxxb_id,to_char(h.qissj,'yyyy')||'-09' as riq,n.y9 as hetl, n.faz,n.daoz,n.meiz,n.hej
from nianjhhtb n,hetxxb h where n.hetxxb_id=h.id )union
(select n.id,n.hetxxb_id,to_char(h.qissj,'yyyy')||'-10' as riq,n.y10 as hetl, n.faz,n.daoz,n.meiz,n.hej
from nianjhhtb n,hetxxb h where n.hetxxb_id=h.id )union
(select n.id,n.hetxxb_id,to_char(h.qissj,'yyyy')||'-11' as riq,n.y11 as hetl, n.faz,n.daoz,n.meiz,n.hej
from nianjhhtb n,hetxxb h where n.hetxxb_id=h.id )union
(select n.id,n.hetxxb_id,to_char(h.qissj,'yyyy')||'-12' as riq,n.y12 as hetl, n.faz,n.daoz,n.meiz,n.hej
from nianjhhtb n,hetxxb h where n.hetxxb_id=h.id )
) ht

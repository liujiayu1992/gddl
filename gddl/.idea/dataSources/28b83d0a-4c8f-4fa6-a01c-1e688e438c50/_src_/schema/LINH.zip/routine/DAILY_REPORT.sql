create PROCEDURE        "DAILY_REPORT" (P_RIBRQ          DATE, --日报生成日期
                                         P_DCID           VARCHAR2, --传入的电厂标识
                                         X_RETURN_STATUS  OUT VARCHAR2,
                                         X_RETURN_MESSAGE OUT VARCHAR2) IS
BEGIN
  DECLARE
    L_RIBB_STATUS  NUMBER; --日报表状态
    L_FENKB_STATUS NUMBER; --分矿表状态

    /*    --得到有哪些单位需要生成日报信息。
    CURSOR CUR_DCID IS
      SELECT ID FROM DIANCXXB WHERE ID IN (P_DCID);*/

  BEGIN
    /*    --循环单位列表
    FOR R_DCID IN CUR_DCID LOOP*/
    --查询日报表中是否有前一日数据
    BEGIN
      SELECT NVL(COUNT(ID), 0)
        INTO L_RIBB_STATUS
        FROM SHOUHCRBB
       WHERE SHOUHCRBB.RIQ = P_RIBRQ - 1
         AND SHOUHCRBB.DIANCXXB_ID = P_DCID;
    EXCEPTION
      WHEN OTHERS THEN
        X_RETURN_STATUS  := 'F';
        X_RETURN_MESSAGE := '收耗存日报查询异常';
        RETURN;
    END;

    --如果没有上一日数据则不能生成日报
    IF L_RIBB_STATUS = 0 THEN
      X_RETURN_STATUS  := 'F';
      X_RETURN_MESSAGE := '上一日无数据，不能生成日报';
      RETURN;
    END IF;

    --查询日报表中是否有数据
    BEGIN
      SELECT NVL(COUNT(ID), 0)
        INTO L_RIBB_STATUS
        FROM SHOUHCRBB
       WHERE SHOUHCRBB.RIQ = P_RIBRQ
         AND SHOUHCRBB.DIANCXXB_ID = P_DCID;
    EXCEPTION
      WHEN OTHERS THEN
        X_RETURN_STATUS  := 'F';
        X_RETURN_MESSAGE := '收耗存日报查询异常';
        RETURN;
    END;

    --查询分矿表中是否有数据
    BEGIN
      SELECT NVL(COUNT(ID), 0)
        INTO L_FENKB_STATUS
        FROM SHOUHCFKB
       WHERE SHOUHCFKB.RIQ = P_RIBRQ
         AND SHOUHCFKB.DIANCXXB_ID = P_DCID;
    EXCEPTION
      WHEN OTHERS THEN
        X_RETURN_STATUS  := 'F';
        X_RETURN_MESSAGE := '收耗存分矿查询异常';
        RETURN;
    END;
    --当没有日报信息时系统自动生成日报
    IF L_RIBB_STATUS = 0 THEN
      BEGIN
        INSERT INTO SHOUHCRBB
          (ID,
           DIANCXXB_ID,
           RIQ,
           FADL,
           JINGZ,
           BIAOZ,
           YUNS,
           YINGD,
           KUID,
           FADY,
           GONGRY,
           QITY,
           CUNS,
           TIAOZL,
           SHUIFCTZ,
           PANYK,
           KUC,
           DANGRGM,
           HAOYQKDR,
           FEISCY,
           BUKDML,
           CHANGWML,
           KEDKC)
          (SELECT GETNEWID(P_DCID),
                  P_DCID,
                  P_RIBRQ,
                  NVL(FADL, 0),
                  NVL(JINGZ, 0),
                  NVL(BIAOZ, 0),
                  NVL(YUNS, 0),
                  NVL(YINGD, 0),
                  NVL(KUID, 0),
                  NVL(FADY, 0),
                  NVL(GONGRY, 0),
                  NVL(QITY, 0),
                  0,
                  0,
                  0,
                  0,
                  NVL(KUC, 0),
                  NVL(JINGZ, 0),
                  NVL(FADY, 0) + NVL(GONGRY, 0) + NVL(QITY, 0) + 0,
                  NVL(FEISCY, 0),
                  NVL(BUKDML, 0),
                  0,
                  NVL(KUC, 0)
             FROM (SELECT KUC, BUKDML
                     FROM SHOUHCRBB
                    WHERE DIANCXXB_ID = P_DCID
                      AND RIQ = P_RIBRQ - 1) KC,
                  (SELECT SUM(FADL) FADL
                     FROM RISCSJB
                    WHERE RIQ = P_RIBRQ
                      AND DIANCXXB_ID = P_DCID) FDL,
                  (SELECT NVL(ROUND_NEW(SUM(LAIMSL), 2), 0) LAIMSL,
                          NVL(ROUND_NEW(SUM(JINGZ), 2), 0) JINGZ,
                          NVL(ROUND_NEW(SUM(BIAOZ), 2), 0) BIAOZ,
                          NVL(ROUND_NEW(SUM(YUNS), 2), 0) YUNS,
                          NVL(ROUND_NEW(SUM(YINGD), 2), 0) YINGD,
                          NVL(ROUND_NEW(SUM(YINGD - YINGK), 2), 0) KUID
                     FROM FAHB
                    WHERE DAOHRQ = P_RIBRQ
                      AND DIANCXXB_ID = P_DCID) FAH,
                  (SELECT NVL(SUM(FADHY), 0) FADY,
                          NVL(SUM(GONGRHY), 0) GONGRY,
                          NVL(SUM(QITY), 0) QITY,
                          NVL(SUM(FEISCY), 0) FEISCY
                     FROM MEIHYB
                    WHERE RULRQ = P_RIBRQ
                      AND DIANCXXB_ID = P_DCID) HY);
      EXCEPTION
        WHEN OTHERS THEN
          X_RETURN_STATUS  := 'F';
          X_RETURN_MESSAGE := '收耗存日报保存失败';
          RETURN;
      END;
    END IF;
    --当没有分矿信息时，系统自动生成分矿数据
    IF L_FENKB_STATUS = 0 THEN
      BEGIN
        INSERT INTO SHOUHCFKB
          (ID,
           DIANCXXB_ID,
           RIQ,
           LAIMSL,
           REZ,
           MEIJ,
           YUNJ,
           MEIKXXB_ID,
           PINZB_ID,
           GONGYSB_ID,
           JIHKJB_ID)
          (SELECT GETNEWID(P_DCID),
                  F.DIANCXXB_ID,
                  P_RIBRQ,
                  NVL(ROUND_NEW(SUM(F.LAIMSL), 2), 0) LAIMSL,
                  NVL(DECODE(SUM(F.LAIMSL),
                             0,
                             0,
                             ROUND_NEW(SUM(Z.QNET_AR * F.LAIMSL) /
                                       SUM(F.LAIMSL),
                                       2)),
                      0) REZ,
                  NVL(DECODE(SUM(F.LAIMSL),
                             0,
                             0,
                             ROUND_NEW(SUM((G.MEIJ + G.MEIS) * F.LAIMSL) /
                                       SUM(F.LAIMSL),
                                       2)),
                      0) MEIJ,
                  NVL(DECODE(SUM(F.LAIMSL),
                             0,
                             0,
                             ROUND_NEW(SUM((G.YUNF + G.YUNFS) * F.LAIMSL) /
                                       SUM(F.LAIMSL),
                                       2)),
                      0) YUNJ,
                  F.MEIKXXB_ID,
                  F.PINZB_ID,
                  F.GONGYSB_ID,
                  F.JIHKJB_ID
             FROM FAHB F,
                  ZHILB Z,
                  DIANCXXB D,
                  (SELECT ID, FAHB_ID, MEIJ, MEIS, YUNF, YUNFS
                     FROM GUSLSB
                    WHERE ID IN (SELECT MAX(ID) ID
                                   FROM GUSLSB G,
                                        (SELECT FAHB_ID, MAX(LEIX) LEIX
                                           FROM GUSLSB
                                          GROUP BY FAHB_ID) G2
                                  WHERE G.FAHB_ID = G2.FAHB_ID
                                    AND G.LEIX = G2.LEIX
                                  GROUP BY G.FAHB_ID)) G
            WHERE F.ZHILB_ID = Z.ID(+)
              AND F.ID = G.FAHB_ID(+)
              AND F.DIANCXXB_ID = D.ID
              AND D.ID = P_DCID
              AND F.DAOHRQ = P_RIBRQ
            GROUP BY F.DIANCXXB_ID,
                     F.GONGYSB_ID,
                     F.MEIKXXB_ID,
                     F.PINZB_ID,
                     F.JIHKJB_ID);
      EXCEPTION
        WHEN OTHERS THEN
          X_RETURN_STATUS  := 'F';
          X_RETURN_MESSAGE := '收耗存分矿保存失败';
          RETURN;
      END;
    END IF;
    --每次完成一个单位的操作就提交一次
    COMMIT;
    /*    END LOOP;*/
    X_RETURN_STATUS  := 'T';
    X_RETURN_MESSAGE := '保存成功';
  END;
END DAILY_REPORT;

 
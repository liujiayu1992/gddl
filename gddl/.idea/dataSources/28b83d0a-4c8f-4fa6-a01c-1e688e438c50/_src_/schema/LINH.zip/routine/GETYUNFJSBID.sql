create FUNCTION        "GETYUNFJSBID" (v_Fahb_id in number) return number is
--通过发货得到运费
 Result number;
begin
  declare
         v_Yunfjsbid number;

         begin

             select distinct dj.yunfjsb_id into v_Yunfjsbid
                    from danjcpb dj,chepb c,yunfdjb yd
                    where dj.chepb_id=c.id
                          and dj.yunfdjb_id=yd.id
                          and yd.feiylbb_id=3
                          and c.fahb_id=v_Fahb_id
                          and rownum=1;

              if v_Yunfjsbid is not null then

                   Result:=  v_Yunfjsbid;
              end if;

              EXCEPTION
                  when NO_DATA_FOUND then
                    v_Yunfjsbid:=0;

              Result:= v_Yunfjsbid;
         end;

  return(Result);
end getYunfjsbid;

 
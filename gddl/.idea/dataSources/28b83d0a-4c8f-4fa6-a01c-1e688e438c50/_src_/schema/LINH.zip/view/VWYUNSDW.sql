create view VWYUNSDW as
SELECT ID AS code,mingc AS yunsdwmc,quanc AS yunsdwqc
FROM yunsdwb

 

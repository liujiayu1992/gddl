create view VWYOUPD_YM as
select id,yuemcmyzb_id,sum(pandssjkc)pandssjkc,sum(pandhjmyl)pandhjmyl,sum(pandhhmyl)pandhhmyl, sum(fadh)fadh,
sum(gongrh)gongrh,sum(qith)qith,sum(pandhccsh)pandhccsh,sum(pandhyssh)pandhyssh,
sum(pandhdcl)pandhdcl,sum(yuemzmkc)yuemzmkc,sum(yuemsjkc)yuemsjkc
,sum(pandhsfctz)pandhsfctz,sum(panyk)panyk
from (
select  yuemcmyzb_id id,yuemcmyzb_id,shuly pandssjkc,0 pandhjmyl,0 pandhhmyl,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='盘点时实际库存'
union all
select  yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,shuly pandhjmyl,0 pandhhmyl,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='盘点后进煤(油）量'
union all
select  yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,shuly pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='盘点后耗煤(油)量'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,shuly fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='  发电耗'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,shuly gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='  供热耗'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,shuly qith,0 pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='  其他耗'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,shuly pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='  盘点后储存损耗'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,shuly pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm=' 盘点后运输损耗'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,shuly pandhdcl ,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm=' 盘点后调出量'
union all
select  yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl ,shuly  pandhsfctz ,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm=' 盘点后水分差调整'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl ,0  pandhsfctz ,shuly  yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='月末24时实际库存'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl ,0  pandhsfctz ,0  yuemsjkc,shuly yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='月末24时帐面库存'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl ,0  pandhsfctz ,0  yuemsjkc,0 yuemzmkc,shuly panyk
from yuemcmyb f
where f.xiangm='盘盈(+)或盘亏(-)')
group by yuemcmyzb_id,id

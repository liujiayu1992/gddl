create trigger TRIGGER_JIEXSBB
	before insert or update or delete
	on JIEXSBB
	for each row
Begin
     if inserting then
          AddInterfaceTask ('shebyxqkb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);
     elsif deleting then
          AddInterfaceTask ('shebyxqkb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);
     elsif updating then
          AddInterfaceTask ('shebyxqkb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_jiexsbb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_jiexsbb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_jiexsbb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
create function jianjrizcz(chepbid number,dongz varchar2,biaomc varchar2,diancxxbid number)

return   varchar2 as

c_ren rizb.caozy%type;

c_shij rizb.caozsj%type;

reny  varchar2(500);

shij varchar2(500);



Cursor myc is

select  r.caozy,r.caozsj from rizb r where  r.mokmc='检斤修改' and r.caoz='更新' and r.biaom=biaomc and r.biaoid=chepbid and r.diancxxb_id=diancxxbid;

begin
reny:='';
shij:='';
open myc;
loop
fetch myc into c_ren,c_shij;

if(c_ren is  not null ) then
reny:=reny||','||c_ren;
shij:=shij||','||to_char(c_shij,'yyyy-MM-dd HH24:mi:ss');
c_ren:=null;

end if;

exit when myc%notfound or myc%notfound is null;
end loop;
close myc;

if (dongz='caozy') then

return reny;

else

return shij;

end if;
end;

create view V_YUNZF as
Select
y.id,y.xiangmbm As feiybm,y.xiangmmc As feiymc,y.shangjxmbm As shangjbm
from yunzfxm y where zhuangt=1
with read only


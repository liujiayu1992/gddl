create view VWNIANYUE as
select to_char(to_date(n.yvalue||'-'||y.mvalue,'yyyy-mm'),'yyyy-mm') yuef
 from nianfb n,yuefb y order by yvalue desc,mvalue desc

 

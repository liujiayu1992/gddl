create trigger TRIGGER_CHENGBMXYBB
	before insert or update or delete
	on CHENGBMXYBB
	for each row
Begin

     if inserting then
          AddInterfaceTask ('yuercbmdj',:new.id,0,:new.changbb_id,'xml',:new.id,to_date(:new.nianf||'-'||:new.yuef||'-01','yyyy-mm-dd'));
     elsif deleting then
          AddInterfaceTask ('yuercbmdj',:old.id,1,:old.changbb_id,'xml',:old.id,to_date(:old.nianf||'-'||:old.yuef||'-01','yyyy-mm-dd'));
     elsif updating then
          if :new.meij<>:old.meij or
             :new.zengzs<>:old.zengzs or
             :new.tielyf<>:old.tielyf or
             :new.yunfse<>:old.yunfse or
             :new.daozzf<>:old.daozzf or
             :new.qitfy<>:old.qitfy or
             :new.rucrz<>:old.rucrz or
             :new.biaomdj<>:old.biaomdj or
             :new.biaomdj<>:old.biaomdj or
             :new.jiaohqzf<>:old.jiaohqzf or
             :new.meij<>:old.meij or

             :new.changbb_id<>:old.changbb_id or
             :new.fahdwb_id<>:old.fahdwb_id or
             :new.jihkjb_Id<>:old.jihkjb_Id or
             :new.yunsfs<>:old.yunsfs
              then
             AddInterfaceTask ('yuercbmdj',:new.id,2,:new.changbb_id,'xml',:new.id,to_date(:new.nianf||'-'||:new.yuef||'-01','yyyy-mm-dd'));
          end if;

     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_chengbmxybb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_chengbmxybb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_chengbmxybb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
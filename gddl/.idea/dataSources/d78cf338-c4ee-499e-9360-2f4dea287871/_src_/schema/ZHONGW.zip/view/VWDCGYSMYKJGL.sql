create view VWDCGYSMYKJGL as
select gl.id,gy.quanc||'('||my.mingc||')' as gongysmy,gl.diancxxb_id,gl.gongysb_id,my.id as meiyxxb_id,kj.gongyskjb_id
from gongysb gy,diancgysglb gl,diancgysmykjb kj,meiyxxb my
where gy.id=gl.gongysb_id and gl.id=kj.diancgysglb_id and kj.meiyxxb_id=my.id
and gl.shiyzt=1 order by gy.quanc


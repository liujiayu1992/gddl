create trigger TRIGGER_CHEZXXB
	before insert or update
	on CHEZXXB
	for each row
Declare
 v_diancxxb_id number(15);
Begin
select min(id_jit) into  v_diancxxb_id from changbb  ;
  if inserting then
   AddInterfaceTask('chezxxb', :new.id,0, v_diancxxb_id, 'xml', :new.id,sysdate);
    elsif updating then
    AddInterfaceTask('chezxxb', :old.id, 2, v_diancxxb_id, 'xml', :old.id,sysdate);
  end if;
End;

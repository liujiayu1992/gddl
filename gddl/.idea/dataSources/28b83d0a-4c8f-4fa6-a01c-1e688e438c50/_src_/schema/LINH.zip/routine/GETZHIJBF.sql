create FUNCTION        "GETZHIJBF" (m_fahb_id in Number,flag in Number) return number is--qnet_ar单位为兆焦
begin
    declare
        m_xiax_zhilyq number(10,2);
        m_danw_zhilyq varchar2(15);
        m_meil number(10,2):=0;
        m_zhej number(10,2):=0;
        m_qnet_ar  number(10,3):=0;
        begin
        --------------因仅是低位发热量，取下限，找合同质量要求
        select nvl(max(xiax),0)xiax,nvl(max(danwb.bianm),'0')danwb,nvl(max(zhilb.qnet_ar),0)  into m_xiax_zhilyq,m_danw_zhilyq,m_qnet_ar
        from hetzlb,danwb,fahb,hetb,zhilb
        where fahb.zhilb_id=zhilb.id and hetzlb.danwb_id=danwb.id and hetzlb.hetb_id=hetb.id and hetb.id=fahb.hetb_id  and hetzlb.zhibb_id=2 and fahb.id=m_fahb_id;
        if m_danw_zhilyq='千卡千克'   then
              m_xiax_zhilyq:=round_new(m_xiax_zhilyq*0.0041816,3);
        end if;
        --------------判断是否是质价不符,批次热值小于质量下限为质价不符
        if m_xiax_zhilyq>0 and m_qnet_ar<m_xiax_zhilyq then
            select fahb.jingz into m_meil
            from fahb
            where fahb.id=m_fahb_id;
        end if;
        /*if flag=1 then
            return m_meil;
        els*/if m_meil<>0 then--如果是质价不符的 统一单位大卡千克 元/吨：规定：基数单位与指标单位应该一致。
                select (shangx-rez)/jis*kouj+jizzkj into m_zhej
                from(
                    select tiaojb.bianm,decode(danwb.bianm,'兆焦千克',round_new(h.shangx/0.0041816,0),h.shangx)shangx,
                   decode(danwb.bianm,'兆焦千克',round_new( h.xiax/0.0041816,0), h.xiax)xiax,
                   decode(jsdw.bianm,'兆焦千克',round_new( h.jis/0.0041816,0),  h.jis)jis,
                      h.kouj,
                    h.jizzkj,round_new(z.qnet_ar/0.0041816,0)rez
                    from hetzkkb h,fahb f,danwb,danwb jsdw,danwb jiagdw,zhilb z,tiaojb
                    where   h.hetb_id=f.hetb_id and f.id=m_fahb_id and h.zhibb_id=2 and h.danwb_id=danwb.id and h.jisdwid=jsdw.id
                    and h.koujdw=jiagdw.id and f.zhilb_id=z.id  and h.tiaojb_id=tiaojb.id
                 )  a
                 where a.rez >xiax and a.rez<shangx ;
                if m_zhej=0 then --如果质价不符但没有折价的仍算符合
                   m_meil:=0;
                end if;
             end if;
             if flag=1 then
                return m_meil;
             else return m_zhej;
             end if;
             Exception
              WHEN NO_DATA_FOUND  THEN
                   return  0;
              When Others Then
                   Return  0;
        end;
end ;

 
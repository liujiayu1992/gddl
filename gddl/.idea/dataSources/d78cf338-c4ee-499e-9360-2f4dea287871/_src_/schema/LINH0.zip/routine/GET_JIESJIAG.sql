create Function Get_JiesJiag (jiesbid In Number,zhilbid In Number
                       )
 Return  Number As
 Begin
  Declare
   v_danj Number;
   Begin
       Select d.Danj 
       Into v_danj
       From Jiesdjb d
       Where d.Jiesb_Id = jiesbid
       And d.Zhilb_Id = zhilbid;
    Return  v_danj;
   Exception When Others Then
    Return 0;
   End;
End;
create view YUESJ as
select decode(mei.riq,null,you.riq,mei.riq)riq,nvl(shouyl,0)shouyl,nvl(you.kuc,0)youkc,
nvl(shouml,0)shouml,nvl(mei.kuc,0)meikc
from(
select riq,sum(shouyl)shouyl,max(kuc)kuc
from zgdt.yueshcyb y
where  y.fenx='本月'
group by y.riq)you full join

(select riq,shouml,kuc
from zgdt.yueshchjb
where  yueshchjb.fenx='本月')mei
 on   mei.riq=you.riq


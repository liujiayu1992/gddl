create trigger TR_FAHB_YUNSFS_UPDATED
	after update
	on FAHB
	for each row
declare
  v_fahb_id Number :=0;
  v_fahb_yunsfs Varchar2(20) :='';
Begin
  If :Old.yunsfs != :New.yunsfs Then
    v_fahb_yunsfs :=:New.yunsfs;
    Update Rigjb Set yunsfs = v_fahb_yunsfs Where id = v_fahb_id;
    Update Fahgjb Set yunsfs = v_fahb_yunsfs Where id = v_fahb_id;
  End If;
end TR_FAHB_YUNSFS_UPDATED;
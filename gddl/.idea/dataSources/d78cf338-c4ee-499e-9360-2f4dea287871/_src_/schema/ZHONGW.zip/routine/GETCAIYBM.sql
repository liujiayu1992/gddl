create FUNCTION getCaiybm(cyriq in date)
	Return  varchar2 as
	begin
	     declare
	     intXuh number;
	     begin
	          select nvl(max(c.xuh),0)+1 into intXuh from caiyb c where c.caiyrq = cyriq;
	          return to_char(cyriq,'yymmdd') || trim(to_char(intXuh,'000'));
	     end;
	end;

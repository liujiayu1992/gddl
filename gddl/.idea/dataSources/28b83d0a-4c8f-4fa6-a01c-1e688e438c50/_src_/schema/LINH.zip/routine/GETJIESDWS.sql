create FUNCTION        "GETJIESDWS" (wenjbid NUMBER, mshij date) return VARCHAR2 is--接收单位
begin
    declare
      diancs VARCHAR2(1000) :='';
      v_loopcounter integer :=1;
      CURSOR my_cursor IS
      select diancxxb.mingc
      from  fabwjb,diancxxb
      where fabwjb.diancxxb_id=diancxxb.id
            and fabwjb.wenjb_id=wenjbid and fabwjb.shij=mshij;
      my_rec my_cursor%ROWTYPE;
    begin

      OPEN my_cursor;
        LOOP
          FETCH my_cursor INTO my_rec;
            EXIT WHEN my_cursor%NOTFOUND;
          IF v_loopcounter = 1 THEN
            diancs := my_rec.mingc;
          ELSE
            diancs := diancs|| ',' ||my_rec.mingc;
          END IF;
          v_loopcounter := v_loopcounter + 1;
        END LOOP;
      CLOSE my_cursor;
      RETURN diancs;
    END;
END;

 
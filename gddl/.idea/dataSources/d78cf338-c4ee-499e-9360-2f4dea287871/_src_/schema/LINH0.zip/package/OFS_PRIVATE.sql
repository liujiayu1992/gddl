create package OFS_private is
  -- business rules enforcement routines
  procedure change_clear;
  procedure change_verify_row(p_new_id in OFS_ITEMS.id%type,
    p_new_item_type in OFS_ITEMS.item_type%type,
    p_old_item_type in OFS_ITEMS.item_type%type,
    p_old_locked_by in OFS_ITEMS.locked_by%type,
    p_new_locked_by in OFS_ITEMS.locked_by%type,
    p_old_read_only in OFS_ITEMS.read_only%type,
    p_new_read_only in OFS_ITEMS.read_only%type,
    p_op in char);
  procedure change_register(p_id in OFS_ITEMS.id%type,
    p_parent_id in OFS_ITEMS.id%type, p_op in char);
  procedure change_verify;
  function os_user return varchar2;
  procedure set_os_user(p_user in varchar2);
  procedure force_unlock(p_id in OFS_ITEMS.id%type);

  -- test helper routines
  procedure test_count_recs(p_num in integer,
    p_ok_msg in varchar2, p_err_msg in varchar2);
  procedure test_count_cursor(p_crs in ofs.dir_cursor,
    p_num in integer, p_ok_msg in varchar2,
    p_err_msg in varchar2);
  procedure test_error(p_error in varchar2,
    p_ok_msg in varchar2, p_err_msg in varchar2);
  procedure test_attr(p_path in varchar2, p_attr in varchar2,
    p_val in varchar2, p_ok_msg in varchar2, p_err_msg in varchar2);
end;

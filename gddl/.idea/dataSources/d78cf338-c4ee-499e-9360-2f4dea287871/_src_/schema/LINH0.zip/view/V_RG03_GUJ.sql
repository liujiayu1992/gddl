create view V_RG03_GUJ as
Select q.Meikdqmc,
         c.Guohsj,
         f.Fahdwb_Id,
         c.Jihkjb_Id,
         z.Id As Zhilb_Id,
         Round_New(Round_New(z.Farl, 2) * 1000 / 4.1816, 0) As Farl,
         c.Biaoz,
         c.Maoz,
         c.Piz,
         c.Yingd,
         c.Kuid,
         c.Yuns,
         g.Meij,
         g.Yunf,
         g.Kuangyf,
         g.Daozzf,
         g.Qitzf
          From Fahb f, Chepb c, Meikdqb q, Zhilb z, Rigjb g
         Where f.Fahdwb_Id = q.Id
           And f.Id = c.Fahb_Id
           And f.Zhilb_Id = z.Id
           And g.Zhilb_Id = z.Id
           And c.Jiesb_Id = 0
           With Read Only


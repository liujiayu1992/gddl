create view VWGONGYSDQ as
SELECT G.ID,
       G.MINGC,
       G.XUH,
       DQ.ID    DQID,
       DQ.MINGC DQMC,
       DQ.XUH   DQXH,
       DQ.BIANM DQ_BIANM,
       S.ID     SID,
       S.QUANC  SMC,
       S.XUH    SXH,
       M.ID     MK_ID,
       M.BIANM  MK_BIANM,
       M.MINGC  MK_MINGC
  FROM MEIKXXB M, GONGYSB G, MEIKDQB DQ, SHENGFB S
 WHERE M.MEIKDQ_ID(+) = G.ID
   AND DQ.ID = G.FUID
   AND G.SHENGFB_ID = S.ID(+)
   AND G.LEIX = 0


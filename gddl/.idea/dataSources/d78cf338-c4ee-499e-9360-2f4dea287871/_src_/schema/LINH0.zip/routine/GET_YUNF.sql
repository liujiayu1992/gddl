create Function GET_YUNF (V_YUNFDJB_ID In Number,V_LEIX In Number,V_SHUIB In Number
      )
  Return  Number As
  Begin
  	Declare
  		lvs_yunf Number;
  		Begin
        Select Sum(zhi) Into lvs_yunf
				From feiyb fy Where fy.yunfdjb_id = V_YUNFDJB_ID And  leix = V_LEIX And shuib = V_SHUIB;
  			Return  lvs_yunf;
  		Exception When Others Then
  			Return 0;
  		End;
  End;

create view VWSHOUHC as
select s.riq,s.kuc,s.yuns,s.cuns from shouhcrbb s


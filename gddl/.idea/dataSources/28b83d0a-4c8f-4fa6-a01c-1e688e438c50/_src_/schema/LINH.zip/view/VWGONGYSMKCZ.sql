create view VWGONGYSMKCZ as
(select g.id,g.mingc,0 fuid,gl.diancxxb_id,2 jib
        from gongysb g, gongysdcglb gl
        where g.id = gl.gongysb_id
        and g.leix = 1
union
select m.id+ml.gongysb_id,m.mingc,ml.gongysb_id,gl.diancxxb_id,3 jib
       from meikxxb m, gongysmkglb ml,gongysdcglb gl, gongysb g
       where ml.meikxxb_id = m.id
       and ml.gongysb_id = gl.gongysb_id
       and g.id = gl.gongysb_id
       and g.leix = 1
       and m.zhuangt=1
union
select distinct c.id+kl.meikxxb_id+ml.gongysb_id,c.mingc,kl.meikxxb_id+ml.gongysb_id,gl.diancxxb_id,4 jib
       from chezxxb c, gongysmkglb ml, gongysdcglb gl, kuangzglb kl, gongysb g
       where c.id = kl.chezxxb_id
       and kl.meikxxb_id = ml.meikxxb_id
       and ml.gongysb_id = gl.gongysb_id
       and g.id = gl.gongysb_id
       and g.leix = 1 )

 

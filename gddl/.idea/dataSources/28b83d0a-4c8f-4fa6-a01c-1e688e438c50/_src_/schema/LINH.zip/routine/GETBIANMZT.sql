create FUNCTION        "GETBIANMZT" (zid IN NUMBER)
   RETURN VARCHAR2
IS
   Result   VARCHAR2 (100);
BEGIN
   DECLARE
      zhuangt   NUMBER;
   BEGIN
      SELECT shenhzt
        INTO zhuangt
        FROM zhillsb
       WHERE id IN zid;

      IF zhuangt = 0
      THEN
         result := '未录入';
      ELSIF zhuangt = 3
      THEN
         result := '一级未审核';
      ELSIF zhuangt = 2
      THEN
         result := '一级审核未通过';
      ELSIF zhuangt = 5
      THEN
         result := '二级未审核';
      ELSIF zhuangt = 4
      THEN
         result := '二级审核未通过';
      ELSIF zhuangt = 7
      THEN
         result := '二级审核通过';
      END IF;
   END;

   RETURN result;
END getBianmzt;

 
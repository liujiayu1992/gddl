create view V_HETXXB as
Select Id, Heth, Qissj, Guoqsj, Fahr, Hetid, Meikdqfdw_Id, Qiandrq,Changbb_Id,jihxz
  From (
        Select h.Id,
                h.Heth As Heth,
                h.Qissj,
                h.Guoqsj,
                h.Fahr,
                h.Id As Hetid,
                h.Meikdqfdw_Id,
                h.Qiandrq,
        h.Changbb_Id,
                h.jihxz
          From Hetxxb h
         Where h.Bucxybz = 0 and h.shenhbz = 0
        Union
        Select h.Id,
               h.Bucxybh As Heth,
               t.Qissj,
               t.Guoqsj,
               t.Fahr,
               t.Id As Hetid,
               t.Meikdqfdw_Id,
               t.Qiandrq,
  t.Changbb_Id,
               t.jihxz
          From Hetxxb h, Hetxxb t
         Where h.Bucxybz = 1
           And h.Heth = t.Heth
           And t.Bucxybz = 0
           And t.shenhbz = 0) t
With Read Only


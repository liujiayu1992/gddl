create FUNCTION        "GETGUSXX4ID" (id in number, colname in varchar2)
	return varchar2 is
	-- 根据id获取guslsb表里的估收信息
	     zhi varchar2(50);
	     Result varchar2(50);

	begin
	     execute immediate  'select '|| colname ||' as zhi from guslsb where id = '|| id into zhi;
	                         if not (zhi is null)  then
	                                Result:= zhi;
	                         else
	                                Result:='';
	                         end if;

	     return(Result);
	end getGusxx4id;

 
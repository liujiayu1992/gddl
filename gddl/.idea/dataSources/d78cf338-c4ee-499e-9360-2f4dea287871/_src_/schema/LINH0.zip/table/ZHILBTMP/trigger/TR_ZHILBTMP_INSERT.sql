create trigger TR_ZHILBTMP_INSERT
	before insert
	on ZHILBTMP
	for each row
Declare
      v_zhilbtmp_id  Zhilbtmp_LOG.Zhilbtmp_Id%Type;
      v_zhilb_id  ZHILBTMP_LOG.zhilb_id%Type;
      v_caiysj  ZHILBTMP_LOG.caiysj%Type;
      v_caiybh  ZHILBTMP_LOG.caiybh%Type;
      v_lury1  ZHILBTMP_LOG.lury1%Type;
      v_caiyry  ZHILBTMP_LOG.caiyry%Type;
      v_caiyfs  ZHILBTMP_LOG.caiyfs%Type;
      v_beiz1  ZHILBTMP_LOG.beiz1%Type;
      v_huaybh  ZHILBTMP_LOG.huaybh%Type;
      v_huaysj  ZHILBTMP_LOG.huaysj%Type;
      v_farl  ZHILBTMP_LOG.farl%Type;
      v_shoudjhf  ZHILBTMP_LOG.shoudjhf%Type;
      v_ganzjhf  ZHILBTMP_LOG.ganzjhf%Type;
      v_ganzwhjhff  ZHILBTMP_LOG.ganzwhjhff%Type;
      v_quansf  ZHILBTMP_LOG.quansf%Type;
      v_kongqgzjl  ZHILBTMP_LOG.kongqgzjl%Type;
      v_kongqgzjhf  ZHILBTMP_LOG.kongqgzjhf%Type;
      v_kongqgzjsf  ZHILBTMP_LOG.kongqgzjsf%Type;
      v_dantrl  ZHILBTMP_LOG.dantrl%Type;
      v_kongqgzjq  ZHILBTMP_LOG.kongqgzjq%Type;
      v_kongqgzjhff  ZHILBTMP_LOG.kongqgzjhff%Type;
      v_konggjt  ZHILBTMP_LOG.konggjt%Type;
      v_ganzjl  ZHILBTMP_LOG.ZHILBtmp_id%Type;
      v_huird  ZHILBTMP_LOG.huird%Type;
      v_ganzjgwrz  ZHILBTMP_LOG.ganzjgwrz%Type;
      v_huayy  ZHILBTMP_LOG.huayy%Type;
      v_lury2  ZHILBTMP_LOG.lury2%Type;
      v_beiz2  ZHILBTMP_LOG.beiz2%Type;
      v_shenhzt  ZHILBTMP_LOG.shenhzt%Type;
      v_shenhry  ZHILBTMP_LOG.shenhry%Type;
      v_leib  ZHILBTMP_LOG.leib%Type;
      v_fcad  ZHILBTMP_LOG.fcad%Type;
      v_hdaf  ZHILBTMP_LOG.hdaf%Type;
      v_daybz  ZHILBTMP_LOG.daybz%Type;
      v_ganzwhjgwrz  ZHILBTMP_LOG.ganzwhjgwrz%Type;
      v_sdaf  ZHILBTMP_LOG.sdaf%Type;
      v_shangjshzt ZHILBTMP_LOG.shangjshzt%Type;
      v_shenhrq ZHILBTMP_LOG.Shenhrq%Type;
Begin
      v_zhilbtmp_id := :New.Id;
      v_zhilb_id := :New.zhilb_id;
      v_caiysj := :New.caiysj;
      v_caiybh := :New.caiybh;
      v_lury1 := :New.lury1;
      v_caiyry := :New.caiyry;
      v_caiyfs := :New.caiyfs;
      v_beiz1 := :New.beiz1;
      v_huaybh := :New.huaybh;
      v_huaysj := :New.huaysj;
      v_farl := :New.farl;
      v_shoudjhf := :New.shoudjhf;
      v_ganzjhf := :New.ganzjhf;
      v_ganzwhjhff := :New.ganzwhjhff;
      v_quansf:= :New.quansf;
      v_kongqgzjl := :New.kongqgzjl;
      v_kongqgzjhf := :New.kongqgzjhf;
      v_kongqgzjsf := :New.kongqgzjsf;
      v_dantrl := :New.dantrl;
      v_kongqgzjq := :New.kongqgzjq;
      v_kongqgzjhff := :New.kongqgzjhff;
      v_konggjt := :New.konggjt;
      v_ganzjl := :New.ganzjl;
      v_huird := :New.huird;
      v_ganzjgwrz := :New.ganzjgwrz;
      v_huayy := :New.huayy;
      v_lury2 := :New.lury2;
      v_beiz2 := :New.beiz2;
      v_shenhzt := :New.shenhzt;
      v_shenhry := :New.shenhry;
      v_leib := :New.leib;
      v_fcad := :New.fcad;
      v_hdaf := :New.hdaf;
      v_daybz := :New.daybz;
      v_ganzwhjgwrz := :New.ganzwhjgwrz;
      v_sdaf := :New.sdaf;
      v_shangjshzt := :New.shangjshzt;
      v_shenhrq := :New.shenhrq;
      Insert Into zhilbtmp_log
        (Id, zhilbtmp_id, zhilb_id, caiysj, caiybh, lury1, caiyry, caiyfs, beiz1, huaybh, huaysj,
        farl, shoudjhf, ganzjhf, ganzwhjhff, quansf, kongqgzjl, kongqgzjhf, kongqgzjsf, dantrl,
        kongqgzjq, kongqgzjhff, konggjt, ganzjl, huird, ganzjgwrz, huayy, lury2, beiz2, shenhzt,
        shenhry, leib, fcad, hdaf, daybz, ganzwhjgwrz, sdaf, shangjshzt, shenhrq, leix)
      Values
        (Xl_Zhilbtmp_Id.Nextval, v_zhilbtmp_id, v_zhilb_id, v_caiysj, v_caiybh, v_lury1, v_caiyry, v_caiyfs, v_beiz1, v_huaybh, v_huaysj,
        v_farl, v_shoudjhf, v_ganzjhf, v_ganzwhjhff, v_quansf, v_kongqgzjl, v_kongqgzjhf, v_kongqgzjsf, v_dantrl,
        v_kongqgzjq, v_kongqgzjhff, v_konggjt, v_ganzjl, v_huird, v_ganzjgwrz, v_huayy, v_lury2, v_beiz2, v_shenhzt,
        v_shenhry, v_leib, v_fcad, v_hdaf, v_daybz, v_ganzwhjgwrz, v_sdaf, v_shangjshzt, v_shenhrq, 'Insert');
End;

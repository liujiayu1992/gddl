create Function Get_CaiyChes(zhilbid Number,jiesbid Number) Return Number Is
  Result Number(10);
Begin
   Declare
   v_ches chepb.Id%Type;
   Cursor C_chepb Is Select Count(c.Id) As ches
       From chepb c,fahb f
       Where f.Id = c.Fahb_Id
       And f.Zhilb_Id=zhilbid
       And c.Jiesb_Id=jiesbid;
   Begin
       Open C_chepb;
       Loop
           Fetch C_chepb Into v_ches;
                 If C_chepb%Found Then
                    Result:=v_ches;
                 End If;
                 Exit When C_chepb%Notfound;
           End Loop;
           Close C_chepb;
          Return(Result);
   End;
End Get_CaiyChes;
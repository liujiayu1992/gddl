create view VWLAIY as
Select sum(shourl) as shourl,riq,changbb_id
  From (
       select sum(f.biaoz) as shourl,
              to_char(f.guohsj, 'yyyy-mm-dd') as riq,
              changbb_id
         from fahbtmp f
        where ranlpzb_id in (select id from ranlpzb where leix = '油')
        and changbb_id in (select id from changbb)
        group by to_char(f.guohsj, 'yyyy-mm-dd'),changbb_id

        Union

        select sum(q.fahl) as shourl,
              to_char(q.jianpsj, 'yyyy-mm-dd') as riq,
              changbb_id
         from qichjjbtmp q
        where ranlpzb_id in (select id from ranlpzb where leix = '油')
         and changbb_id in (select id from changbb)
        group by to_char(q.jianpsj, 'yyyy-mm-dd'),changbb_id
        ) t
        group  by riq,changbb_id
With Read Only


create Function Get_JiesJingz (jiesbid In Number
                       )
 Return  Number As
 Begin
  Declare
   v_shul Number;
   Begin
       Select Sum(t.maoz) - Sum(piz)
       Into v_shul
       From (
         Select round_new(Sum(c.maoz),0) As maoz,round_new(Sum(c.Piz),0) As piz
         From fahb f,chepb c
         Where f.Id = c.fahb_id
         And c.Jiesb_Id = jiesbid
         Group By f.Zhilb_Id
       ) t;
    Return  v_shul;
   Exception When Others Then
    Return 0;
   End;
End;

create view TEMPVIEW as
(
 select rownum as id,a."MINGC",a."MEIKDQMC" from (
 select j.mingc,m.meikdqmc  from fahb f,zhilb z,meikdqb m,jihkjb j
 where f.zhilb_id = z.id
 and decode(Z.FARL,0,null,z.farl) is not null
 and f.jihkjb_id = j.id
 and f.fahdwb_id = m.id
 and to_char(f.daohrq,'yyyy') = '2011'
And m.meikdqmc <> '机车用煤'
 group by j.mingc,m.meikdqmc
 order by j.mingc desc,m.meikdqmc) a
 union
 select max(id)+1 as id,nvl('','本周合计') as mingc,nvl('','本周合计') from (select rownum as id,a.* from (
 select j.mingc,m.meikdqmc  from fahb f,zhilb z,meikdqb m,jihkjb j
 where f.zhilb_id = z.id
 and decode(Z.FARL,0,null,z.farl) is not null
 and f.jihkjb_id = j.id
 and f.fahdwb_id = m.id
 and to_char(f.daohrq,'yyyy') = '2011'
And m.meikdqmc <> '机车用煤'
 group by j.mingc,m.meikdqmc
 order by j.mingc desc,m.meikdqmc) a))

create trigger TRIGGER_YUEMCMYB
	before insert or update or delete
	on YUEMCMYB
	for each row
Declare
       v_riq yuemcmyzb.riq%Type;
       v_changbb_id yuemcmyzb.changbb_id%Type;
Begin
     if inserting then
        select  riq,changbb_id  into v_riq,v_changbb_id
        from yuemcmyzb
        where id=:new.yuemcmyzb_id;
        AddInterfaceTask ('yuemcmyb',:new.yuemcmyzb_id,0,v_changbb_id,'xml',:new.yuemcmyzb_id,v_riq);
     elsif deleting then
        select  riq ,changbb_id into v_riq,v_changbb_id
        from yuemcmyzb
        where id=:new.yuemcmyzb_id;
        AddInterfaceTask ('yuemcmyb',:old.yuemcmyzb_id,1,v_changbb_id,'xml',:old.yuemcmyzb_id,v_riq);
     elsif updating then
        select  riq  ,changbb_id into v_riq,v_changbb_id
        from yuemcmyzb
        where id=:new.yuemcmyzb_id;
        AddInterfaceTask ('yuemcmyb',:new.yuemcmyzb_id,2,v_changbb_id,'xml',:new.yuemcmyzb_id,v_riq);
     end if;
    exception
    when others then
        if inserting then
           zengjrz('trigger_yuemcmyb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_yuemcmyb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_yuemcmyb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;

create FUNCTION        "GETCAIYBH4ZL" (zhilbId long)  return varchar2 is
       Result varchar2(2000);
-- 根据质量id 得到采样编号
  begin
      declare
      tmp varchar2(500);
      cursor caiybh is
          select distinct zm.bianm
          from zhuanmb zm,zhillsb z
          where zm.zhuanmlb_id = 100661
                and zm.zhillsb_id = z.id
                and z.zhilb_id = zhilbId;
      begin
          open caiybh;
               loop
                     fetch caiybh into tmp;
                     EXIT when caiybh%NOTFOUND;
                     if Result is null then
                        Result:=tmp;
                     Else
                        Result:=Result||';'||tmp;
                     end if;
               end loop;
          close caiybh;
      end;
      if Result is null then
         Result := '';
      end if;
      return(Result);
  end getCaiybh4zl;

 
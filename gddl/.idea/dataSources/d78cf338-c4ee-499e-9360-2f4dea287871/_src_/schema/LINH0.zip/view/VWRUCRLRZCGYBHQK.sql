create view VWRUCRLRZCGYBHQK as
select nianf,yuef,changbb_id,decode(yuef,1,'一月',2,'二月',3,'三月',
	4,'四月',5,'五月',6,'六月',7,'七月',8,'八月',9,'九月',10,'十月',
	11,'十一月',12,'十二月','月份信息错误')as yuef_c,
	nvl(rucmrz*1000,0) rucmrz, nvl(rulmrz*1000,0) rulmrz
	, nvl(rezc*1000,0) rezc,
	nvl((select rucmrz*1000 from yuedfxsj
	where nianf+1 = y.nianf and yuef =y.yuef
	and changbb_id = y.changbb_id),0) trucmrz,
	nvl((select rulmrz*1000 from yuedfxsj
	where nianf+1 = y.nianf and yuef =y.yuef
	and changbb_id = y.changbb_id),0) trulmrz,
	nvl((select rezc*1000 from yuedfxsj
	where nianf+1 = y.nianf and yuef =y.yuef
	and changbb_id = y.changbb_id),0) trezc,
	nvl((select decode(sum(shisl),0,0,sum(rucmrz*shisl*1000)
	/sum(shisl)) from yuedfxsj
	where nianf = y.nianf and yuef <=y.yuef
	and changbb_id = y.changbb_id),0) lrucmrz,
	nvl((select decode(sum(shisl),0,0,sum(rulmrz*shisl*1000)
	/sum(shisl)) from yuedfxsj
	where nianf = y.nianf and yuef <=y.yuef
	and changbb_id = y.changbb_id),0) lrulmrz,
	nvl((select decode(sum(shisl),0,0,sum(rezc*shisl*1000)
	/sum(shisl)) from yuedfxsj
	where nianf = y.nianf and yuef <=y.yuef
	and changbb_id = y.changbb_id),0) lrezc
	from yuedfxsj y


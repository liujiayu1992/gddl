create view VWYUERCCB as
select dy.jihkjb_id,dy.gongysb_id,dy.diancxxb_id, dy.riq, sum(decode(dy.fenx,'本月',dy.jingz)) jbeny,
       sum(decode(dy.fenx,'累计',dy.jingz)) jleij,sum(decode(dy.fenx,'本月',sy.jingz)) jsy,
       sum(decode(dy.fenx,'累计',tq.jingz)) jtq,
       nvl(decode(sum(decode(dy.fenx,'本月',dy.jingz)),0,0,
       sum(decode(dy.fenx,'本月',dy.meij*dy.jingz))/sum(decode(dy.fenx,'本月',dy.jingz))),0) mbeny,
       nvl(decode(sum(decode(dy.fenx,'累计',dy.jingz)),0,0,
       sum(decode(dy.fenx,'累计',dy.meij*dy.jingz))/sum(decode(dy.fenx,'累计',dy.jingz))),0) mleij,
       nvl(decode(sum(decode(dy.fenx,'本月',sy.jingz)),0,0,
       sum(decode(dy.fenx,'本月',sy.meij*sy.jingz))/sum(decode(dy.fenx,'本月',sy.jingz))),0) msy,
       nvl(decode(sum(decode(dy.fenx,'累计',tq.jingz)),0,0,
       sum(decode(dy.fenx,'累计',tq.meij*tq.jingz))/sum(decode(dy.fenx,'累计',tq.jingz))),0) mtq,
       nvl(decode(sum(decode(dy.fenx,'本月',dy.jingz)),0,0,
       sum(decode(dy.fenx,'本月',dy.yunj*dy.jingz))/sum(decode(dy.fenx,'本月',dy.jingz))),0) ybeny,
       nvl(decode(sum(decode(dy.fenx,'累计',dy.jingz)),0,0,
       sum(decode(dy.fenx,'累计',dy.yunj*dy.jingz))/sum(decode(dy.fenx,'累计',dy.jingz))),0) yleij,
       nvl(decode(sum(decode(dy.fenx,'本月',sy.jingz)),0,0,
       sum(decode(dy.fenx,'本月',sy.yunj*sy.jingz))/sum(decode(dy.fenx,'本月',sy.jingz))),0) ysy,
       nvl(decode(sum(decode(dy.fenx,'累计',tq.jingz)),0,0,
       sum(decode(dy.fenx,'累计',tq.yunj*tq.jingz))/sum(decode(dy.fenx,'累计',tq.jingz))),0) ytq,
       nvl(decode(sum(decode(dy.fenx,'本月',dy.jingz)),0,0,
       sum(decode(dy.fenx,'本月',dy.zf*dy.jingz))/sum(decode(dy.fenx,'本月',dy.jingz))),0) zbeny,
       nvl(decode(sum(decode(dy.fenx,'累计',dy.jingz)),0,0,
       sum(decode(dy.fenx,'累计',dy.zf*dy.jingz))/sum(decode(dy.fenx,'累计',dy.jingz))),0) zleij,
       nvl(decode(sum(decode(dy.fenx,'本月',sy.jingz)),0,0,
       sum(decode(dy.fenx,'本月',sy.zf*sy.jingz))/sum(decode(dy.fenx,'本月',sy.jingz))),0) zsy,
       nvl(decode(sum(decode(dy.fenx,'累计',tq.jingz)),0,0,
       sum(decode(dy.fenx,'累计',tq.zf*tq.jingz))/sum(decode(dy.fenx,'累计',tq.jingz))),0) ztq
       from
(select  k.diancxxb_id,k.jihkjb_id,k.gongysb_id,k.riq,y.fenx,s.jingz,y.meij,
y.yunj,(y.zaf + y.qit + y.daozzf + y.jiaohqzf) zf
       from yuercbmdj y, yuetjkjb k, yueslb s
where y.yuetjkjb_id = k.id and y.yuetjkjb_id = s.yuetjkjb_id
) dy,
(select  k.diancxxb_id,k.jihkjb_id,k.gongysb_id,k.riq,y.fenx,s.jingz,y.meij,
y.yunj,(y.zaf + y.qit + y.daozzf + y.jiaohqzf) zf
       from yuercbmdj y, yuetjkjb k, yueslb s
where y.yuetjkjb_id = k.id and y.yuetjkjb_id = s.yuetjkjb_id
) sy,
(select  k.diancxxb_id,k.jihkjb_id,k.gongysb_id,k.riq,y.fenx,s.jingz,y.meij,
y.yunj,(y.zaf + y.qit + y.daozzf + y.jiaohqzf) zf
       from yuercbmdj y, yuetjkjb k, yueslb s
where y.yuetjkjb_id = k.id and y.yuetjkjb_id = s.yuetjkjb_id
) tq
where dy.diancxxb_id = sy.diancxxb_id (+) and dy.diancxxb_id = tq.diancxxb_id(+)
and dy.jihkjb_id = sy.jihkjb_id(+) and dy.jihkjb_id = tq.jihkjb_id(+)
and dy.gongysb_id = sy.gongysb_id (+) and dy.gongysb_id = tq.gongysb_id(+)
and dy.fenx = sy.fenx(+) and dy.fenx = tq.fenx(+)
and dy.riq = add_months(sy.riq(+),-1) and dy.riq = add_months(tq.riq(+),-12)
group by dy.jihkjb_id,dy.gongysb_id,dy.diancxxb_id, dy.riq


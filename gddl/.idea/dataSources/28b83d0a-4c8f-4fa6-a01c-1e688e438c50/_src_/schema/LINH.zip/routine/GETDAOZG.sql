create FUNCTION        "GETDAOZG" (diancxxb in number,riq in date) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_str varchar2(200);
   CURSOR C_open IS select distinct cz.mingc as daozmc
          from niancgjh y, gongysb g,yunsfsb ys,chezxxb cz
         where y.gongysb_id = g.id(+)
           and y.yunsfsb_id = ys.id(+)
           and y.daoz_id=cz.id
           and y.jizzt=1
           and y.diancxxb_id=diancxxb
           and y.riq=riq
         group by y.diancxxb_id,y.riq,g.mingc,ys.mingc,cz.mingc;
   BEGIN
       OPEN C_open;
       loop
           FETCH C_open INTO v_str;
                 if C_open%FOUND then
                    Result:=Result||v_str||',';
                 end if;
                 EXIT WHEN C_open%NOTFOUND;
           end loop;
           CLOSE C_open;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end Getdaozg;

 
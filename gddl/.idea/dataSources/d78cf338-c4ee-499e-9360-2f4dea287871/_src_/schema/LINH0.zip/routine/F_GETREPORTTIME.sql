create function F_GETREPORTTIME return varchar2 is
  Result VARCHAR2(10);
begin
    Select Xitxxb.Zhi INTO Result From Xitxxb Where Xitxxb.Duixm = '日报时间';
      IF Length(Result) = 1 THEN
        Result := '0'||Result;
      END IF;
      Result := ' '||Result||':00:00';
      RETURN(Result);
    Exception
    When No_Data_Found Then
      --Dbms_Output.Put_Line('No_Data_Found');
      Return ' 00:00:00';
    When Others Then
      --Dbms_Output.Put_Line('others error');
      Return ' 00:00:00';

end F_GETREPORTTIME;
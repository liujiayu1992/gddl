create trigger TRIGGER_YUEDJHFB
	before insert or update or delete
	on YUEDJHFB
	for each row
Begin
     if inserting then
         -- AddInterfaceTask ('yuecgjhb',:new.id,0,:new.changbb_id,'xml',:new.id, to_date(:new.niand||:new.yued,'yyyymm'));
         return;
     elsif deleting then
         -- AddInterfaceTask ('yuecgjhb',:old.id,1,:old.changbb_id,'xml',:old.id,to_date(:old.niand||:old.yued,'yyyymm'));
         return;
     elsif updating and :new.zhuangt=1 then
           if :new.niand<>:old.niand or
              :new.yued<>:old.yued or
              :new.fahdwb_id<>:old.fahdwb_id or
              :new.jihkjb_id<>:old.jihkjb_id or
              :new.faz<>:old.faz or
              :new.daoz_id<>:old.daoz_id or
              :new.danydhl<>:old.danydhl or
              :new.jiag<>:old.jiag or
              :new.yunf<>:old.yunf or
              :new.zaf<>:old.zaf or
              :new.rez<>:old.rez or
              :new.rezjkk<>:old.rezjkk or
              :new.huiff<>:old.huiff or
              :new.liuf<>:old.liuf or
              :new.zhuangt <> :old.zhuangt
           then
              AddInterfaceTask ('yuecgjhb',:new.id,2,:new.changbb_id,'xml',:new.id,to_date(:new.niand||:new.yued,'yyyymm'));

           end if ;
     end if;

     exception
     when others then
        if inserting then
           zengjrz('trigger_yuedjhfb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_yuedjhfb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_yuedjhfb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;

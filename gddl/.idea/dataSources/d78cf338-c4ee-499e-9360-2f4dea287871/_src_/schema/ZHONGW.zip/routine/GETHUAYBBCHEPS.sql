create function GetHuaybbCheps(zhilbid number) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_cheph chepb.cheph%TYPE;
   CURSOR C_chepb IS SELECT cheph FROM chepb  where fahb_id in(select id from fahb where zhilb_id=zhilbid);

   BEGIN
       OPEN C_chepb;
       loop
           FETCH C_chepb INTO v_cheph;
                 if C_chepb%FOUND then
                    Result:=Result||v_cheph||',';
                 end if;
                 EXIT WHEN C_chepb%NOTFOUND;
           end loop;
           CLOSE C_chepb;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end GetHuaybbCheps;

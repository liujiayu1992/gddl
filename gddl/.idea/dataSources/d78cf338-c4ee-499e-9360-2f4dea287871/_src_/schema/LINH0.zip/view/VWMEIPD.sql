create view VWMEIPD as
select id,panmyqkbgzb_id,sum(BENYJY)BENYJY,sum(FADH)FADH,sum(GONGRH)GONGRH,0 FEISCYM,sum(QITY)QITY,
sum(DIAOCL)DIAOCL,sum(CUNS)CUNS,sum(YUNS)YUNS,sum(SHUIFC)SHUIFC,
sum(ZHANGMKC)ZHANGMKC
,sum(SHIJKC)SHIJKC,sum(PANYK)PANYK
from (
select  panmyqkbgzb_id id,panmyqkbgzb_id,shulm BENYJY,0 FADH,0 GONGRH,0 QITY,0 DIAOCL,0 CUNS,0 YUNS,0 SHUIFC,0 ZHANGMKC,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='本月进量'
union all
select  panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,shulm FADH,0 GONGRH,0 QITY,0 DIAOCL,0 CUNS,0 YUNS,0 SHUIFC,0 ZHANGMKC,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='  发电耗'
union all
select  panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,shulm GONGRH ,0 QITY,0 DIAOCL,0 CUNS,0 YUNS,0 SHUIFC,0 ZHANGMKC,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='  供热耗'
union all
select panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,0 GONGRH ,shulm QITY,0 DIAOCL,0 CUNS,0 YUNS,0 SHUIFC,0 ZHANGMKC,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='  其他耗'
union all
select panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,0 GONGRH ,0 QITY,shulm DIAOCL,0 CUNS,0 YUNS,0 SHUIFC,0 ZHANGMKC,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='调出量'
union all
select panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,0 GONGRH ,0 QITY,0 DIAOCL,shulm CUNS,0 YUNS,0 SHUIFC,0 ZHANGMKC,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='  储存损耗'
union all
select panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,0 GONGRH ,0 QITY,0 DIAOCL,0 CUNS,shulm YUNS,0 SHUIFC,0 ZHANGMKC,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='运输损耗'
union all
select panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,0 GONGRH ,0 QITY,0 DIAOCL,0 CUNS,0 YUNS,shulm SHUIFC,0 ZHANGMKC,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='水分差调整'
union all
select panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,0 GONGRH ,0 QITY,0 DIAOCL,0 CUNS,0 YUNS,0 SHUIFC,shulm ZHANGMKC ,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='盘点时账面库存'
union all
select  panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,0 GONGRH ,0 QITY,0 DIAOCL,0 CUNS,0 YUNS,0 SHUIFC,0 ZHANGMKC ,shulm  SHIJKC ,0 PANYK
from panmyqkbgb f
where f.xiangm='盘点存合计'
union all
select panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,0 GONGRH ,0 QITY,0 DIAOCL,0 CUNS,0 YUNS,0 SHUIFC,0 ZHANGMKC ,0  SHIJKC ,shulm  PANYK
from panmyqkbgb f
where f.xiangm='盘盈(+)或盘亏(-)')
group by panmyqkbgzb_id,id

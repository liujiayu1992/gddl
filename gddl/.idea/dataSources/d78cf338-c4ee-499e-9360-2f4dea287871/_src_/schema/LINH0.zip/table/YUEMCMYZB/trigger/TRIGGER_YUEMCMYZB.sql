create trigger TRIGGER_YUEMCMYZB
	before insert or update or delete
	on YUEMCMYZB
	for each row
Declare
Begin
     if inserting then
        AddInterfaceTask ('yuemcmyzb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);
     elsif deleting then
        AddInterfaceTask ('yuemcmyzb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);
     elsif updating then
        AddInterfaceTask ('yuemcmyzb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
     end if;
    exception
    when others then
        if inserting then
           zengjrz('trigger_yuemcmyzb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_yuemcmyzb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_yuemcmyzb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
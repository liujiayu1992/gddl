create view VWSHCQ as
select dy.jihkjb_id,dy.gongysb_id,dy.diancxxb_id, dy.riq,
       nvl(sum(decode(dy.fenx,'本月',dy.shouml)),0) sbeny,
       nvl(sum(decode(dy.fenx,'累计',dy.shouml)),0) sleij,
       nvl(sum(decode(dy.fenx,'本月',sy.shouml)),0) ssy,
       nvl(sum(decode(dy.fenx,'累计',tq.shouml)),0) stq,
       nvl(sum(decode(dy.fenx,'本月',dy.haoy)),0) hbeny,
       nvl(sum(decode(dy.fenx,'累计',dy.haoy)),0) hleij,
       nvl(sum(decode(dy.fenx,'本月',sy.haoy)),0) hsy,
       nvl(sum(decode(dy.fenx,'累计',tq.haoy)),0) htq,
       nvl(sum(decode(dy.fenx,'本月',dy.kuc)),0) kbeny,
       nvl(sum(decode(dy.fenx,'累计',dy.kuc)),0) kleij,
       nvl(sum(decode(dy.fenx,'本月',sy.kuc)),0) ksy,
       nvl(sum(decode(dy.fenx,'累计',tq.kuc)),0) ktq,
       nvl(sum(decode(dy.fenx,'本月',dy.qith)),0) qbeny,
       nvl(sum(decode(dy.fenx,'累计',dy.qith)),0) qleij,
       nvl(sum(decode(dy.fenx,'本月',sy.qith)),0) qsy,
       nvl(sum(decode(dy.fenx,'累计',tq.qith)),0) qtq,
       nvl(sum(decode(dy.fenx,'本月',dy.panyk)),0) pbeny,
       nvl(sum(decode(dy.fenx,'累计',dy.panyk)),0) pleij,
       nvl(sum(decode(dy.fenx,'本月',sy.panyk)),0) psy,
       nvl(sum(decode(dy.fenx,'累计',tq.panyk)),0) ptq,
       nvl(sum(decode(dy.fenx,'本月',dy.sunh)),0) cbeny,
       nvl(sum(decode(dy.fenx,'累计',dy.sunh)),0) cleij,
       nvl(sum(decode(dy.fenx,'本月',sy.sunh)),0) csy,
       nvl(sum(decode(dy.fenx,'累计',tq.sunh)),0) ctq
      -- dy.shouml,nvl(sy.shouml,0) sy,nvl(tq.shouml,0) tq
       from
(select  k.diancxxb_id,k.jihkjb_id,k.gongysb_id,k.riq,y.fenx,y.shouml,
(y.fady + y.gongry + y.qith + y.sunh + diaocl) haoy,y.qith, y.kuc, y.panyk, y.sunh
       from yuehcb y, yuetjkjb k
where y.yuetjkjb_id = k.id --and k.riq = to_date('2008-05-01','yyyy-mm-dd')
) dy,
(select  k.diancxxb_id,k.jihkjb_id,k.gongysb_id,k.riq,y.fenx,y.shouml,
(y.fady + y.gongry + y.qith + y.sunh + diaocl) haoy,y.qith, y.kuc, y.panyk, y.sunh
       from yuehcb y, yuetjkjb k
where y.yuetjkjb_id = k.id --and k.riq = add_months(to_date('2008-05-01','yyyy-mm-dd'),-1)
) sy,
(select  k.diancxxb_id,k.jihkjb_id,k.gongysb_id,k.riq,y.fenx,y.shouml,
(y.fady + y.gongry + y.qith + y.sunh + diaocl) haoy,y.qith, y.kuc, y.panyk, y.sunh
       from yuehcb y, yuetjkjb k
where y.yuetjkjb_id = k.id --and k.riq = add_months(to_date('2008-05-01','yyyy-mm-dd'),-12)
) tq
where dy.diancxxb_id = sy.diancxxb_id (+) and dy.diancxxb_id = tq.diancxxb_id(+)
and dy.jihkjb_id = sy.jihkjb_id(+) and dy.jihkjb_id = tq.jihkjb_id(+)
and dy.gongysb_id = sy.gongysb_id (+) and dy.gongysb_id = tq.gongysb_id(+)
and dy.fenx = sy.fenx(+) and dy.fenx = tq.fenx(+)
and dy.riq = add_months(sy.riq(+),-1) and dy.riq = add_months(tq.riq(+),-12)
--and dy.diancxxb_id = 201
group by dy.jihkjb_id,dy.gongysb_id,dy.diancxxb_id, dy.riq

 

create view VWSHIHGYSDY as
select max(id) id,gongysb_id, gongys from shihcptmp
where gongysb_id <>0 group by gongysb_id,gongys


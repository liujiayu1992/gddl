create trigger TRIGGER_PANMYQKBGB
	before insert or update
	on PANMYQKBGB
	for each row
Declare
       v_changbb_id number;
       v_riq date;
Begin

     if inserting then
      select riq,changbb_id
      into v_riq,v_changbb_id
      from panmyqkbgzb
      where id=:new.panmyqkbgzb_id;
          AddInterfaceTask ('pandzmy',:new.panmyqkbgzb_id,0,v_changbb_id,'xml',:new.panmyqkbgzb_id,v_riq);
          AddInterfaceTask ('pandzmm',:new.panmyqkbgzb_id,0,v_changbb_id,'xml',:new.panmyqkbgzb_id,v_riq);

     elsif updating then
        select riq,changbb_id
        into v_riq,v_changbb_id
        from panmyqkbgzb
        where id=:new.panmyqkbgzb_id;
         if :new.shuly<>:old.shuly then
           AddInterfaceTask ('pandzmy',:new.panmyqkbgzb_id,2,v_changbb_id,'xml',:new.panmyqkbgzb_id,v_riq);
         elsif :new.shulm<>:old.shulm then
           AddInterfaceTask ('pandzmm',:new.panmyqkbgzb_id,2,v_changbb_id,'xml',:new.panmyqkbgzb_id,v_riq);
         end if;
     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_panmyqkbgb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_panmyqkbgb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_panmyqkbgb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
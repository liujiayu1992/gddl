create Function Get_JiesBiaoz (jiesbid In Number
                           )
     Return  Number As
     Begin
      Declare
       v_shul Number;
       Begin
           Select round_new(Sum(t.biaoz),0)
           Into v_shul
           From (
             Select round_new(Sum(c.biaoz),0) As biaoz
             From fahb f,chepb c
             Where f.Id = c.fahb_id
             And c.Jiesb_Id = jiesbid
             Group By f.Zhilb_Id
           ) t;
        Return  v_shul;
       Exception When Others Then
        Return 0;
       End;
    End;

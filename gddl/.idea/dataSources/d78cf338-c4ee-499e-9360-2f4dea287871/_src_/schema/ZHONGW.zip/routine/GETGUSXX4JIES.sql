create function getGusxx4jies(Fahb_id in number, colname in varchar2)
	return varchar2 is
	-- 获取guslsb表里的结算信息
	     zhi varchar2(50);
	     Result varchar2(50);

	begin
	     execute immediate  'select zhi from (select '|| colname ||' as zhi from guslsb where fahb_id = '||Fahb_id||'
	                         and leix = 4) where rownum = 1' into zhi;
	                         if not (zhi is null)  then
	                                Result:= zhi;
	                         else
	                                Result:='';
	                         end if;

	     return(Result);
	end getGusxx4jies;

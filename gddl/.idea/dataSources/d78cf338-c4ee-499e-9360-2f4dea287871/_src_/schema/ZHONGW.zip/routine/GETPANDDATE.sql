create function getPandDate(diancxxbid in Number,dateDate in date) return date is
begin
      declare
         pandrq date ;
         begin
               select  case when shuj1=shuj2 then riq2
                       else case when shuj1<shuj2 then riq1
                       else case when shuj1>shuj2 then riq2
                       end end end into pandrq
               from (
                   select t.diancxxb_id,
                   decode(q.riq,null,nvl(h.riq,dateDate),q.riq) as riq1,
                   decode(q.shuj,null,nvl(h.shuj,1),q.shuj) as shuj1,
                   decode(h.riq,null,nvl(q.riq,dateDate),h.riq) as riq2,
                   decode(h.shuj,null,nvl(q.shuj,1),h.shuj) as shuj2
                   from
                   (select diancxxbid as diancxxb_id from dual) t,
                   ( select * from (
                       select diancxxb_id,max(riq) as riq,abs(max(riq)-last_day(dateDate)) as shuj
                       from pandb
                       where  pandb.riq>=getyearfirstdate(dateDate) and pandb.riq<add_months(dateDate,1)
                       and diancxxb_id=diancxxbid
                       group by diancxxb_id)
                   )q,
                   ( select * from (
                       select diancxxb_id,min(riq) as riq,abs(min(riq)-dateDate) as shuj
                       from pandb
                       where  pandb.riq>=add_months(dateDate,1) and pandb.riq<add_months(dateDate,2)
                       and diancxxb_id=diancxxbid
                       group by diancxxb_id)
                   )h
               where t.diancxxb_id=q.diancxxb_id(+) and t.diancxxb_id=h.diancxxb_id(+));

               return pandrq;
               Exception
                  WHEN NO_DATA_FOUND  THEN
                       return  dateDate;
                  When Others Then
                  Return  dateDate;
         end;
end getPandDate;

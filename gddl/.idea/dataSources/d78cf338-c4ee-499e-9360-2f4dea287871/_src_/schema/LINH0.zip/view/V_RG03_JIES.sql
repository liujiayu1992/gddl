create view V_RG03_JIES as
Select q.meikdqmc,c.Guohsj,f.fahdwb_id,f.jihkjb_id,
f.zhilb_id,j.Yansrl,j.Id As jiesb_id,
       c.biaoz,
       c.maoz,
       c.piz,
       c.yingd,
       c.kuid,
       c.yuns,
       j.Shulzjbz As Meij,
       Round_New((j.Tielyf - j.Zhuanxyf + j.Dityf - j.Duantyf) / j.Jiessl,
                 2) As Yunf,
       Round_New(j.Kuangqyf / j.Jiessl, 2) As Kuangyf,
       Round_New(j.Qitkk / j.Jiessl, 2) As Daozzf,
       Round_New(j.Zaf / j.Jiessl, 2) As Zaf
  From Jiesb j, Chepb c,fahb f,meikdqb q
 Where j.Id = c.Jiesb_Id
 And f.Id = c.fahb_id
 And f.fahdwb_id = q.Id
       With Read Only


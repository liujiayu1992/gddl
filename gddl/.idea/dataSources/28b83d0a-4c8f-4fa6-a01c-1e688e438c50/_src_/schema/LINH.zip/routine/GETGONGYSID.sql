create FUNCTION        "GETGONGYSID" (strGongysName In varchar2)
  Return  number as
  begin
    declare
      gongysid number;
    begin
      select max(id) into gongysid from gongysb dc where dc.mingc=strGongysName;
      return gongysid;
    end;
  End;

 
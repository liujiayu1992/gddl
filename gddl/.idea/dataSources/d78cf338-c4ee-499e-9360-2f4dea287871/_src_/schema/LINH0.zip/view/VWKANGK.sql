create view VWKANGK as
select "ID","XUH","CHEZBM","JIANC","QUANC","LUJXXB_ID","LEIB","BEIZ" from chezxxb where leib='港口'


create function jihFunction (nian varchar2,yue1 varchar2,yue2 varchar2,changbbid varchar2)
return jihtab as
l_tab_emp jihtab:= jihtab();
begin
select jihrow(fahdwb_id,shengf,jihl,beiz,gonghdw)
bulk collect into l_tab_emp
from(
  select d.fahdwb_id,s.mingc shengf,sum(d.zhi)jihl,max(d.beiz)beiz,f.quanc gonghdw

            from vwdaohqk_fcb d,fahdwb f,shengfb s
            where d.fahdwb_id=f.id(+) and f.shengfb_id=s.id(+)
               and niand= nian and yued>=yue1 and yued<=yue2 and d.changbb_id=changbbid
          group by fahdwb_id,s.mingc,f.quanc);
   return l_tab_emp;
end;

create trigger TRIGGER_RULMYDTJB
	before update
	on RULMYDTJB
	for each row
Begin
     if updating and :new.shenhzt=1 and :old.shenhzt=0 then
       AddInterfaceTask ('yuezbb',:new.id,0,:new.changbb_id,'xml',:new.id,to_date(:new.niand||:new.yued,'yyyymm'));
     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_rulmydtjb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_rulmydtjb',:old.id,'修改',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_rulmydtjb',:old.id,'删除',SQLCODE,SQLERRM);
        end if;
End;
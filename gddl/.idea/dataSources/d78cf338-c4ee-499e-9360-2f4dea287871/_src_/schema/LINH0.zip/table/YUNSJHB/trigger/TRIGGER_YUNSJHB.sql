create trigger TRIGGER_YUNSJHB
	before insert or update or delete
	on YUNSJHB
	for each row
Begin

     if inserting then
          AddInterfaceTask ('yunsjhtbb',:new.id,0,:new.changbb_id,'xml',:new.id, :new.riq);

     elsif deleting then
          AddInterfaceTask ('yunsjhtbb',:old.id,1,:old.changbb_id,'xml',:old.id, :old.riq);
     elsif updating then
           if :new.FAHDWB_ID<>:old.FAHDWB_ID or
              :new.PINZB_ID<>:old.PINZB_ID or
              :new.FAZ<>:old.FAZ or
              :new.DAOZ_ID<>:old.DAOZ_ID or
              :new.CHES<>:old.CHES or
              :new.DUNS<>:old.DUNS or
              :new.RIQ<>:old.RIQ
           then
              AddInterfaceTask ('yunsjhtbb',:new.id,2,:new.changbb_id,'xml',:new.id, :new.riq);

           end if ;
     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_yunsjhb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_yunsjhb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_yunsjhb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;

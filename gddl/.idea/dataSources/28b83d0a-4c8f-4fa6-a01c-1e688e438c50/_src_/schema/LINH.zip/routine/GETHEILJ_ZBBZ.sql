create FUNCTION        "GETHEILJ_ZBBZ" (m_Diancxxb_id number,Riq varchar2) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_beiz varchar2(2000);

   CURSOR C_Zhoubbz IS SELECT trim(beiz) as beiz FROM hlj_zhoub z,
                    (select TO_CHAR( to_date(''||Riq||'','yyyy-MM-dd') - TO_NUMBER( decode(TO_CHAR(to_date(''||Riq||'','yyyy-MM-dd'),'D'),'1','8',TO_CHAR(to_date(''||Riq||'','yyyy-MM-dd'),'D')) ) + 2,'YYYY-MM-DD' ) yi,
                            TO_CHAR( to_date(''||Riq||'','yyyy-MM-dd') - TO_NUMBER( decode(TO_CHAR(to_date(''||Riq||'','yyyy-MM-dd'),'D'),'1','8',TO_CHAR(to_date(''||Riq||'','yyyy-MM-dd'),'D')) ) + 8,'YYYY-MM-DD' ) ri
                            from dual) w
          where z.riq>=to_date(w.yi,'yyyy-MM-dd')
                and z.riq<=to_date(w.ri,'yyyy-MM-dd')
                and diancxxb_id=m_Diancxxb_id
                and z.beiz is not null
                and z.beiz<>' ';
   BEGIN

       OPEN C_Zhoubbz;
       loop
           FETCH C_Zhoubbz INTO v_beiz;

                 EXIT WHEN C_Zhoubbz%NOTFOUND;
           end loop;
           CLOSE C_Zhoubbz;

           Result:=v_beiz;
          return(Result);
   END;
end GetHeilj_zbbz;

 
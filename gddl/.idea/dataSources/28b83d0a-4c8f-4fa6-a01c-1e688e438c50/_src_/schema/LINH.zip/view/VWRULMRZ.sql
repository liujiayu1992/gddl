create view VWRULMRZ as
select z.rulrq,
round(decode(nvl(sum(fadhy),0),0,0,sum(nvl(qnet_ar,0)*fadhy)/sum(fadhy)),2) farl
from rulmzlb z,
(select rulrq,rulmzlb_id,sum(fadhy) fadhy from meihyb group by rulrq,rulmzlb_id) m
where z.rulrq = m.rulrq and z.id = m.rulmzlb_id
group by z.rulrq

 

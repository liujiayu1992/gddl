create trigger TRIGGER_KUANGFYBB
	before insert or update or delete
	on KUANGFYBB
	for each row
Begin

     if inserting then
          AddInterfaceTask ('zhuangcyb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);

     elsif deleting then
          AddInterfaceTask ('zhuangcyb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);

     elsif updating then

           if :new.MEIKXXB_ID<>:old.MEIKXXB_ID or
              :new.FAZ_ID<>:old.FAZ_ID or
              :new.QUEBL<>:old.QUEBL or
              :new.YUJDDSJ<>:old.YUJDDSJ or
              :new.MINGRYBL<>:old.MINGRYBL or
              :new.CHENGRC<>:old.CHENGRC or
              :new.MEIL<>:old.MEIL or
              :new.RANLPZB_ID<>:old.RANLPZB_ID
            then
              AddInterfaceTask ('zhuangcyb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
           end if ;
     end if;
    exception
    when others then
        if inserting then
           zengjrz('trigger_kuangfybb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_kuangfybb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_kuangfybb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
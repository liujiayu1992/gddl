create FUNCTION        "GETCAIBMFROMZHILID" (lngZhilb_ID number) return varchar2 is
  Result varchar2(2000);
begin
  DECLARE
    v_mingc varchar2(200);
    CURSOR c_bm IS
    select zm.bianm
          from zhuanmb zm, zhuanmlb lb,zhillsb ls
          where lb.mingc='采样编码'
          and zm.zhuanmlb_id=lb.id
          and zm.zhillsb_id=ls.id
          and ls.zhilb_id=lngZhilb_ID;
  BEGIN
    OPEN c_bm;
      loop
        FETCH c_bm INTO v_mingc;
        EXIT WHEN c_bm %NOTFOUND;
        if Result is null then
           Result :=v_mingc;
        else
           Result := Result|| ','|| v_mingc ;
        end if;
      end loop;
    CLOSE c_bm;
    return(Result);
  END;
end GetCaibmFromZhilId;

 
create function GetHuayy4zl(zhilbid number) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_huayy zhillsb.huayy%TYPE;
   CURSOR C_huayy IS SELECT huayy FROM zhillsb  where zhilb_id in(zhilbid);
   BEGIN
       OPEN C_huayy;
       loop
           FETCH C_huayy INTO v_huayy;
                 if C_huayy%FOUND then
                    Result:=Result||v_huayy||',';
                 end if;
                 EXIT WHEN C_huayy%NOTFOUND;
           end loop;
           CLOSE C_huayy;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end GetHuayy4zl;
-----------------------------
create table NIANCGJH_FGS
(
  ID          NUMBER(15) not null,
  RIQ         DATE not null,
  DIANCXXB_ID NUMBER(15) not null,
  GONGYSB_ID  NUMBER(15) not null,
  JIHKJB_ID   NUMBER(15) not null,
  FAZ_ID      NUMBER(10),
  DAOZ_ID     NUMBER(10),
  NIANJHCGL   NUMBER(15,3),
  CHEBJG      NUMBER(15,2),
  YUNF        NUMBER(10,2),
  ZAF         NUMBER(10,2),
  REZ         VARCHAR2(50),
  JIAKK       VARCHAR2(50),
  JIHDDSJYSL  VARCHAR2(50),
  HUIFF       NUMBER(15,3),
  LIUF        NUMBER(15,3),
  DAOCJ       NUMBER(15,3),
  BIAOMDJ     NUMBER(15,3),
  YUNSFSB_ID  NUMBER(15),
  JIZZT       NUMBER(1) default 0,
  PINZB_ID    NUMBER(15),
  MEIKXXB_ID  NUMBER(15),
  ZHUANGT     NUMBER(1)
)
-- Add comments to the columns
comment on column NIANCGJH_FGS.RIQ
  is '年份';
comment on column NIANCGJH_FGS.DIANCXXB_ID
  is '电厂';
comment on column NIANCGJH_FGS.GONGYSB_ID
  is '供应商';
comment on column NIANCGJH_FGS.JIHKJB_ID
  is '计划中径';
comment on column NIANCGJH_FGS.FAZ_ID
  is '发站';
comment on column NIANCGJH_FGS.DAOZ_ID
  is '到站';
comment on column NIANCGJH_FGS.NIANJHCGL
  is '年采购计划量';
comment on column NIANCGJH_FGS.CHEBJG
  is '车板价';
comment on column NIANCGJH_FGS.YUNF
  is '运费';
comment on column NIANCGJH_FGS.ZAF
  is '杂费';
comment on column NIANCGJH_FGS.REZ
  is '热值';
comment on column NIANCGJH_FGS.JIAKK
  is '加扣款';
comment on column NIANCGJH_FGS.JIHDDSJYSL
  is '计划到达时间与数量';
comment on column NIANCGJH_FGS.HUIFF
  is '挥发份';
comment on column NIANCGJH_FGS.LIUF
  is '硫份';
comment on column NIANCGJH_FGS.DAOCJ
  is '到厂价';
comment on column NIANCGJH_FGS.BIAOMDJ
  is '标煤单价';
comment on column NIANCGJH_FGS.YUNSFSB_ID
  is '运输方式';
comment on column NIANCGJH_FGS.JIZZT
  is '机组状态：0现役机组 1新增机组';
comment on column NIANCGJH_FGS.PINZB_ID
  is '品种';
comment on column NIANCGJH_FGS.MEIKXXB_ID
  is '煤矿名称';
comment on column NIANCGJH_FGS.ZHUANGT
  is '状态';

------------------------------------------------------------------------

create table NIANCGJH_HD
(
  ID          NUMBER(15) not null,
  RIQ         DATE not null,
  DIANCXXB_ID NUMBER(15) not null,
  GONGYSB_ID  NUMBER(15) not null,
  JIHKJB_ID   NUMBER(15) not null,
  FAZ_ID      NUMBER(10),
  DAOZ_ID     NUMBER(10),
  NIANJHCGL   NUMBER(15,3),
  CHEBJG      NUMBER(15,2),
  YUNF        NUMBER(10,2),
  ZAF         NUMBER(10,2),
  REZ         VARCHAR2(50),
  JIAKK       VARCHAR2(50),
  JIHDDSJYSL  VARCHAR2(50),
  HUIFF       NUMBER(15,3),
  LIUF        NUMBER(15,3),
  DAOCJ       NUMBER(15,3),
  BIAOMDJ     NUMBER(15,3),
  YUNSFSB_ID  NUMBER(15),
  JIZZT       NUMBER(1) default 0,
  PINZB_ID    NUMBER(15),
  MEIKXXB_ID  NUMBER(15),
  ZHUANGT     NUMBER(1)
)
-- Add comments to the columns
comment on column NIANCGJH_HD.RIQ
  is '年份';
comment on column NIANCGJH_HD.DIANCXXB_ID
  is '电厂';
comment on column NIANCGJH_HD.GONGYSB_ID
  is '供应商';
comment on column NIANCGJH_HD.JIHKJB_ID
  is '计划中径';
comment on column NIANCGJH_HD.FAZ_ID
  is '发站';
comment on column NIANCGJH_HD.DAOZ_ID
  is '到站';
comment on column NIANCGJH_HD.NIANJHCGL
  is '年采购计划量';
comment on column NIANCGJH_HD.CHEBJG
  is '车板价';
comment on column NIANCGJH_HD.YUNF
  is '运费';
comment on column NIANCGJH_HD.ZAF
  is '杂费';
comment on column NIANCGJH_HD.REZ
  is '热值';
comment on column NIANCGJH_HD.JIAKK
  is '加扣款';
comment on column NIANCGJH_HD.JIHDDSJYSL
  is '计划到达时间与数量';
comment on column NIANCGJH_HD.HUIFF
  is '挥发份';
comment on column NIANCGJH_HD.LIUF
  is '硫份';
comment on column NIANCGJH_HD.DAOCJ
  is '到厂价';
comment on column NIANCGJH_HD.BIAOMDJ
  is '标煤单价';
comment on column NIANCGJH_HD.YUNSFSB_ID
  is '运输方式';
comment on column NIANCGJH_HD.JIZZT
  is '机组状态：0现役机组 1新增机组';
comment on column NIANCGJH_HD.PINZB_ID
  is '品种';
comment on column NIANCGJH_HD.MEIKXXB_ID
  is '煤矿名称';
comment on column NIANCGJH_HD.ZHUANGT
  is '状态';

-----------------------------
--日收耗存中缺少函数 DayShouhc.java

create or replace function keyts_rb_new(lngDiancxxb_id in number,datRiq date,lngjb in number) return number is

  Result number(10,2);

begin

    declare

        begin

             if lngjb =1 then

                select decode(rijhm,0,0,round(nvl(kuc,0)/(rijhm),1))  into Result

                from

                 (select sum(kuc) as kuc,sum(keyts_rijhm_new(lngDiancxxb_id,haoyqkdr,datriq,lngjb)) as rijhm

                        from shouhcrbb s,vwdianc d where s.diancxxb_id=d.id

                        and d.rlgsid=lngDiancxxb_id

                        and s.riq=datRiq) rb;

                return Result;

             elsif lngjb=2 then

                select decode(rijhm,0,0,round(nvl(kuc,0)/(rijhm),1))  into Result

                from

                 (select sum(kuc) as kuc,sum(keyts_rijhm_new(lngDiancxxb_id,haoyqkdr,datriq,lngjb)) as rijhm

                        from shouhcrbb s,vwdianc d where s.diancxxb_id=d.id

                        and (d.fgsid=lngDiancxxb_id or d.shangjgsid=lngDiancxxb_id)

                        and s.riq=datRiq) rb;

                return Result;

             elsif lngjb=3 then

                select decode(rijhm,0,0,round(nvl(kuc,0)/(rijhm),1))  into Result

                from

                 (select sum(kuc) as kuc,sum(keyts_rijhm_new(lngDiancxxb_id,haoyqkdr,datriq,lngjb)) as rijhm

                        from shouhcrbb s,vwdianc d where s.diancxxb_id=d.id

                        and s.diancxxb_id=lngDiancxxb_id

                        and s.riq=datRiq) rb;

                return Result;

             end if;

        end;

end keyts_rb_new;

--------------------------
alter table xiasmxqtb rename column pinz to pinz_id;
----------------------------------------------------------------
--新建表：下水煤发运情况表
create table xiasmfyqkb
(
  ID          NUMBER(15) not null,
  RIQ         DATE       not null,
  DIANCXXB_ID NUMBER(15) not null,
  GONGYSB_ID  NUMBER(15) not null,
  CHEZXXB_ID  NUMBER(15) not null,
  JIHN        NUMBER(8,4),
  JIHW        NUMBER(8,4),
  HETL        NUMBER(8,4)
)
-- Add comments to the columns
comment on column xiasmfyqkb.RIQ
  is '日期';
comment on column xiasmfyqkb.DIANCXXB_ID
  is '电厂ID';
comment on column gangkjhfyqk.GONGYSB_ID
  is '供应商ID';
comment on column gangkjhfyqk.CHEZXXB_ID
  is '港口ID';
comment on column gangkjhfyqk.JIHN
  is '计划内(万吨)';
comment on column gangkjhfyqk.JIHW
  is '计划外(万吨)';
comment on column gangkjhfyqk.HETL
  is '合同量(万吨)';

---------------------------------
-- Create table
create table QITYCYB
(
ID NUMBER(15) not null,
ZHILLSB_ID NUMBER(15),
DIANCXXB_ID NUMBER(15),
MEIKMC VARCHAR2(50),
had number(8,2),
CAIYRQ DATE,
CAIYRY VARCHAR2(100),
zhiyry VARCHAR2(100)
) ;
-- Add comments to the table
comment on table QITYCYB
is '其它样采样表';
-- Add comments to the columns
comment on column QITYCYB.ZHILLSB_ID
is '质量临时表_id';
comment on column QITYCYB.DIANCXXB_ID
is '电厂信息表_id';
comment on column QITYCYB.MEIKMC
is '煤矿名称';
comment on column QITYCYB.CAIYRQ
is '采样日期';
comment on column QITYCYB.CAIYRY
is '采样人员';
comment on column QITYCYB.zhiyry
is '制样人员';
-- Create/Recreate primary, unique and foreign key constraints
alter table QITYCYB
add primary key (ID) ;

-----------------------------------

CREATE OR REPLACE Function getDiancId_Fuid(SonDiancID In number)
Return  number as
begin
     declare
     diancid number;
     begin
     select fuid into diancid from diancxxb dc where dc.id=SonDiancID;
     return diancid;
     end;
End;

--------------------------------
-- Add/modify columns
alter table XIASMFYQKB modify JIHN NUMBER(15,4);
alter table XIASMFYQKB modify JIHW NUMBER(15,4);
alter table XIASMFYQKB modify HETL NUMBER(15,4);
create or replace function Getyunsfs(diancxxb in number,riq in date) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_str varchar2(200);
   CURSOR C_open IS select distinct ys.mingc as gmsl
          from niancgjh y, gongysb g,yunsfsb ys
         where y.gongysb_id = g.id(+)
           and y.yunsfsb_id = ys.id(+)
           and y.jizzt=1
           and y.diancxxb_id=diancxxb
           and y.riq=riq
         group by y.diancxxb_id,y.riq,g.mingc,ys.mingc;
   BEGIN
       OPEN C_open;
       loop
           FETCH C_open INTO v_str;
                 if C_open%FOUND then
                    Result:=Result||v_str||',';
                 end if;
                 EXIT WHEN C_open%NOTFOUND;
           end loop;
           CLOSE C_open;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end Getyunsfs;
create or replace function Getdaozg(diancxxb in number,riq in date) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_str varchar2(200);
   CURSOR C_open IS select distinct cz.mingc as daozmc
          from niancgjh y, gongysb g,yunsfsb ys,chezxxb cz
         where y.gongysb_id = g.id(+)
           and y.yunsfsb_id = ys.id(+)
           and y.daoz_id=cz.id
           and y.jizzt=1
           and y.diancxxb_id=diancxxb
           and y.riq=riq
         group by y.diancxxb_id,y.riq,g.mingc,ys.mingc,cz.mingc;
   BEGIN
       OPEN C_open;
       loop
           FETCH C_open INTO v_str;
                 if C_open%FOUND then
                    Result:=Result||v_str||',';
                 end if;
                 EXIT WHEN C_open%NOTFOUND;
           end loop;
           CLOSE C_open;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end Getdaozg;
create or replace function Getgmsl(diancxxb in number,riq in date) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_str varchar2(200);
   CURSOR C_open IS select g.mingc||round_new(sum(y.nianjhcgl)/10000,2)||'万吨' as gmsl
          from niancgjh y, gongysb g,yunsfsb ys
         where y.gongysb_id = g.id(+)
           and y.yunsfsb_id = ys.id(+)
           and y.jizzt=1
           and y.diancxxb_id=diancxxb
           and y.riq=riq
         group by y.diancxxb_id,y.riq,g.mingc,ys.mingc;
   BEGIN
       OPEN C_open;
       loop
           FETCH C_open INTO v_str;
                 if C_open%FOUND then
                    Result:=Result||v_str||',';
                 end if;
                 EXIT WHEN C_open%NOTFOUND;
           end loop;
           CLOSE C_open;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end Getgmsl;
-----------------------------


--同步分公司 diancjsmkb 缺失字段
-----------------------------------------------------------------
-- Add/modify columns
alter table DIANCJSMKB add JIESFRL NUMBER(15,3) default 0;
-- Add comments to the columns
comment on column DIANCJSMKB.JIESFRL
  is '结算发热量';

-- Add/modify columns
alter table DIANCJSMKB add FUID NUMBER(15) default 0;
-- Add comments to the columns
comment on column DIANCJSMKB.FUID
  is '父id';

-- Add/modify columns
alter table DIANCJSMKB add KUIDJFYF NUMBER(15,3);
-- Add comments to the columns
comment on column DIANCJSMKB.KUIDJFYF
  is '亏吨拒付运费';

-- Add/modify columns
alter table DIANCJSMKB add KUIDJFZF NUMBER(15,3);
-- Add comments to the columns
comment on column DIANCJSMKB.KUIDJFZF
  is '亏吨拒付杂费';

-- Add/modify columns
alter table DIANCJSMKB add CHAOKDL NUMBER(15,5) default 0;
-- Add comments to the columns
comment on column DIANCJSMKB.CHAOKDL
  is '超\亏吨量';

-- Add/modify columns
alter table DIANCJSMKB add CHAOKDLX VARCHAR2(20);
-- Add comments to the columns
comment on column DIANCJSMKB.CHAOKDLX
  is '超\亏吨类型';

-- Add/modify columns
alter table DIANCJSMKB add YUFKJE NUMBER(15,3) default 0;
-- Add comments to the columns
comment on column DIANCJSMKB.YUFKJE
  is '预付款金额';

-- Add/modify columns
alter table DIANCJSMKB add JIJLX NUMBER(1) default 0;
-- Add comments to the columns
comment on column DIANCJSMKB.JIJLX
  is '基价类型';



--同步分公司 DIANCJSYFB 缺失字段
-----------------------------------------------------------------
-- Add/modify columns
alter table DIANCJSYFB add FUID NUMBER(15) default 0;
-- Add comments to the columns
comment on column DIANCJSYFB.FUID
  is '父id';


--同步分公司 KUANGFJSMKB 缺失字段
-----------------------------------------------------------------
-- Add/modify columns
alter table KUANGFJSMKB add KUIDJFYF NUMBER(15,3);
-- Add comments to the columns
comment on column KUANGFJSMKB.KUIDJFYF
  is '亏吨拒付运费';

-- Add/modify columns
alter table KUANGFJSMKB add KUIDJFZF NUMBER(15,3);
-- Add comments to the columns
comment on column KUANGFJSMKB.KUIDJFZF
  is '亏吨拒付杂费';

-- Add/modify columns
alter table KUANGFJSMKB add CHAOKDL NUMBER(15,5) default 0;
-- Add comments to the columns
comment on column KUANGFJSMKB.CHAOKDL
  is '超\亏吨量';

-- Add/modify columns
alter table KUANGFJSMKB add CHAOKDLX VARCHAR2(20);
-- Add comments to the columns
comment on column KUANGFJSMKB.CHAOKDLX
  is '超\亏吨类型';

-- Add/modify columns
alter table KUANGFJSMKB add YUFKJE NUMBER(15,3) default 0;
-- Add comments to the columns
comment on column KUANGFJSMKB.YUFKJE
  is '预付款金额';

-- Add/modify columns
alter table KUANGFJSMKB add JIAJQDJ NUMBER(15,8) default 0;
-- Add comments to the columns
comment on column KUANGFJSMKB.JIAJQDJ
  is '加价前单价';

-- Add/modify columns
alter table KUANGFJSMKB add FUID NUMBER(15) default 0;
-- Add comments to the columns
comment on column KUANGFJSMKB.FUID
  is '父id';

-- Add/modify columns
alter table KUANGFJSMKB add JIJLX NUMBER(1) default 0;
-- Add comments to the columns
comment on column KUANGFJSMKB.JIJLX
  is '基价类型';


--同步分公司 KUANGFJSYFB 缺失字段
-----------------------------------------------------------------
-- Add/modify columns
alter table KUANGFJSYFB add FUID NUMBER(15) default 0;
-- Add comments to the columns
comment on column KUANGFJSYFB.FUID
  is '父id';

-- Add/modify columns
alter table KUANGFJSYFB add KUIDJFYF NUMBER(15,3);
-- Add comments to the columns
comment on column KUANGFJSYFB.KUIDJFYF
  is '亏吨拒付运费';

-- Add/modify columns
alter table KUANGFJSYFB add KUIDJFZF NUMBER(15,3);
-- Add comments to the columns
comment on column KUANGFJSYFB.KUIDJFZF
  is '亏吨拒付杂费';

------------------------------

--为了满足合同价格精度的需求，修改结算表中合同价（HETJ）字段的精度。
-----------------------------------------------------------------
-- Add/modify columns
alter table JIESB modify HETJ NUMBER(20,8);

-- Add/modify columns
alter table DIANCJSMKB modify HETJ NUMBER(20,8);

-- Add/modify columns
alter table KUANGFJSMKB modify HETJ NUMBER(20,8);



--修改了分公司结算单导入界面得到销售合同的函数
-----------------------------------------------------------------
create or replace function GetXiaosht(jiesbid number) return varchar2 is
  Result varchar2(100);
begin
   DECLARE
   xiaosht hetb.hetbh%TYPE;
   CURSOR p_xiaosht IS select distinct h.hetbh||' '||g.mingc||' '||min(jg.jij) as xx
                        from jiesb j,hetb h,gongysb g,hetjgb jg
                        where j.gongysb_id = h.gongysb_id
                              and j.jihkjb_id = h.jihkjb_id
                              and h.gongysb_id = g.id
                              and jg.hetb_id = h.id
                              and j.yansksrq>=h.qisrq
                              and j.yansjzrq<=h.guoqrq
                              and h.leib = 1
                              and j.id = jiesbid
                        group by h.id,h.hetbh,g.mingc;
   BEGIN
       OPEN p_xiaosht;
       loop
           FETCH p_xiaosht INTO xiaosht;
                 if p_xiaosht%FOUND then
                    Result:=xiaosht;
                 end if;
                 EXIT WHEN p_xiaosht%NOTFOUND;
           end loop;
       CLOSE p_xiaosht;
       return(Result);
   END;
end GetXiaosht;

--------------------------
----制样人员关联表
create table ZHIYRYGLB
(
YANGPDHB_ID NUMBER(15),
RENYXXB_ID NUMBER(15)
)
tablespace ZGDT
pctfree 10
initrans 1
maxtrans 255
storage
(
initial 64K
minextents 1
maxextents unlimited
);
-- Add comments to the table
comment on table ZHIYRYGLB
is '制样人员关联表';
-- Add comments to the columns
comment on column ZHIYRYGLB.YANGPDHB_ID
is '样品单号表ID';
comment on column ZHIYRYGLB.RENYXXB_ID
is '人员ID';
----制样人员函数。
create or replace function GetZhiyry(mid number) return varchar2 is
Result varchar2(2000);
begin
DECLARE
v_mingc varchar2(2000) ;
CURSOR C_chezxxb IS
select r.quanc
from zhiyryglb c,renyxxb r
where c.renyxxb_id=r.id and c.yangpdhb_id=mid;
BEGIN
OPEN C_chezxxb;
loop
FETCH C_chezxxb
INTO v_mingc;
if C_chezxxb%FOUND then
Result := Result || v_mingc || ',';
end if;
EXIT WHEN C_chezxxb%NOTFOUND;
end loop;
CLOSE C_chezxxb;
if Length(Result) > 0 then
Result := substr(Result, 0, Length(Result) - 1);
end if;
return(Result);
END;
end GetZhiyry;
----------------------------
Create table daozcpb(
    ID number(15) Not Null,
    fahxxb_id number(15) default 0,
    DIANCXXB_ID NUMBER(15) default 0 Not Null,
    PIAOJH VARCHAR2(20),
    GONGYSMC VARCHAR2(40) Not Null,
    MEIKDWMC VARCHAR2(40) Not Null,
    PINZ VARCHAR2(20) Not Null,
    FAZ VARCHAR2(20) Not Null,
    DAOZ VARCHAR2(20) Not Null,
    JIHKJ VARCHAR2(20) Not Null,
    FAHRQ DATE default sysdate Not Null,
    DAOHRQ DATE default sysdate Not Null,
    HETB_ID NUMBER(15) default 0 Not Null,
    ZHILB_ID NUMBER(15) default 0 Not Null,
    CAIYBH VARCHAR2(20) default 0 Not Null,
    JIESB_ID NUMBER(15) default 0 Not Null,
    YUNSFS VARCHAR2(20) default '公路' Not Null,
    CHEC VARCHAR2(20) default '车次' Not Null,
    CHEPH VARCHAR2(20) Not Null,
    MAOZ NUMBER(10,3) default 0 Not Null,
    PIZ NUMBER(10,3) default 0 Not Null,
    BIAOZ NUMBER(10,3) default 0 Not Null,
    YINGD NUMBER(10,3) default 0 Not Null,
    YINGK NUMBER(10,3) default 0 Not Null,
    YUNS NUMBER(10,3) default 0 Not Null,
    YUNSL NUMBER(5,3) default 0 Not Null,
    KOUD NUMBER(8,3) default 0 Not Null,
    KOUS NUMBER(15,3) default 0 Not Null,
    KOUZ NUMBER(10,3) default 0 Not Null,
    SANFSL NUMBER(10,3) default 0 Not Null,
    CHES NUMBER(8,3) default 0 Not Null,
    JIANJFS VARCHAR2(10) default '过衡' Not Null,
    YUNSDWB VARCHAR2(100) Not Null,
    QINGCSJ DATE,
    QINGCHH VARCHAR2(20),
    QINGCJJY VARCHAR2(20),
    ZHONGCSJ DATE,
    ZHONGCHH VARCHAR2(20),
    ZHONGCJJY VARCHAR2(20),
    MEICB_ID NUMBER(15) default 0 Not Null,
    DAOZCH VARCHAR2(20),
    LURY VARCHAR2(20) Not Null,
    BEIZ VARCHAR2(200),
    CAIYRQ DATE,
    LURSJ DATE default sysdate Not Null,
    YUNSDW VARCHAR2(50),
    XIECFS VARCHAR2(20),
    YUANMZ NUMBER(10,3),
    YUANPZ NUMBER(10,3),
   CONSTRAINT MK_daozcpb PRIMARY KEY(ID)) ;
 comment on column daozcpb.DIANCXXB_ID is '电厂信息表Id';
 comment on column daozcpb.PIAOJH is '运单票据号';
 comment on column daozcpb.GONGYSMC is '供应商名称';
 comment on column daozcpb.MEIKDWMC is '煤款单位名称';
 comment on column daozcpb.PINZ is '品种';
 comment on column daozcpb.FAZ is '发站';
 comment on column daozcpb.DAOZ is '到站';
 comment on column daozcpb.JIHKJ is '计划口径';
 comment on column daozcpb.FAHRQ is '发货日期';
 comment on column daozcpb.DAOHRQ is '到货日期';
 comment on column daozcpb.HETB_ID is '合同表_Id';
 comment on column daozcpb.ZHILB_ID is '质量表id';
 comment on column daozcpb.CAIYBH is '采样编号';
 comment on column daozcpb.JIESB_ID is '结算表id';
 comment on column daozcpb.YUNSFS is '运输方式(公路、铁路、船运)';
 comment on column daozcpb.CHEC is '车次';
 comment on column daozcpb.CHEPH is '车皮号';
 comment on column daozcpb.MAOZ is '毛重';
 comment on column daozcpb.PIZ is '皮重';
 comment on column daozcpb.BIAOZ is '票重';
 comment on column daozcpb.YINGD is '盈吨';
 comment on column daozcpb.YINGK is '盈亏';
 comment on column daozcpb.YUNS is '运损';
 comment on column daozcpb.YUNSL is '运损率';
 comment on column daozcpb.KOUD is '扣吨';
 comment on column daozcpb.KOUS is '扣水';
 comment on column daozcpb.KOUZ is '扣杂';
 comment on column daozcpb.SANFSL is '三方数量(汽车煤的煤管站量及海运的港口数量)';
 comment on column daozcpb.CHES is '车速';
 comment on column daozcpb.JIANJFS is '检斤方式(过衡、检尺)';
 comment on column daozcpb.YUNSDWB is '运输单位';
 comment on column daozcpb.QINGCSJ is '轻车时间';
 comment on column daozcpb.QINGCHH is '轻车衡号';
 comment on column daozcpb.QINGCJJY is '轻车检斤员';
 comment on column daozcpb.ZHONGCSJ is '重车时间';
 comment on column daozcpb.ZHONGCHH is '重车衡号';
 comment on column daozcpb.ZHONGCJJY is '重车检斤员';
 comment on column daozcpb.MEICB_ID is '煤场表_id';
 comment on column daozcpb.DAOZCH is '倒装车号';
 comment on column daozcpb.LURY is '录入员';
 comment on column daozcpb.BEIZ is '备注';
 comment on column daozcpb.CAIYRQ is '采样日期';
 comment on column daozcpb.LURSJ is '录入时间';
 comment on column daozcpb.YUNSDW is '运输单位';
 comment on column daozcpb.XIECFS is '卸车方式';
 comment on column daozcpb.YUANMZ is '原毛重';
 comment on column daozcpb.YUANPZ is '原皮重';
comment on table daozcpb is '倒装车皮表';
--------------------------------------
alter table diancjsmkb add hansyf number(14, 2);
comment on column diancjsmkb.hansyf is '含税运费';

alter table kuangfjsmkb add hansyf number(14, 1);
comment on column kuangfjsmkb.hansyf is '含税运费';
----------------------------------
drop trigger trigger_ud_gongysb ;
Create Or Replace Trigger trigger_i_gongysdcglb
  Before Insert On gongysdcglb
  For Each Row
Declare
 v_diancxxb_id number(15);
Begin
     execute immediate 'select nvl(min(id),0) dcid into v_diancxxb_id
     from diancxxb where fuid = '||:new.diancxxb_id||' and jib = 4' into v_diancxxb_id;
     if v_diancxxb_id <> 0 then
        AddInterfaceTask('gongyssqpfb', :new.gongysb_id,0,v_diancxxb_id, 'xml', :new.gongysb_id,sysdate);
     else
        AddInterfaceTask('gongyssqpfb', :new.gongysb_id,0,:new.diancxxb_id, 'xml', :new.gongysb_id,sysdate);
     end if;
  exception
   when others then
   return ;
End;
---------------------
update gongyssqpfb set pifzt = 0 where pifzt is null;
alter table gongyssqpfb modify pifzt default 0;


-----------------------------

alter table JIESB add Yunfhsdj NUMBER(14,7) default 0;
comment on column JIESB.Yunfhsdj
  is '运费含税单价';

alter table JIESB add hansyf NUMBER(15,5) default 0;
comment on column JIESB.hansyf
  is '含税运费';

alter table JIESB add buhsyf NUMBER(15,5) default 0;
comment on column JIESB.buhsyf
  is '不含税运费';

alter table JIESB add yunfjsl NUMBER(15,5) default 0;
comment on column JIESB.yunfjsl
  is '运费结算量';
alter table DIANCJSMKB add Yunfhsdj NUMBER(14,7) default 0;
comment on column DIANCJSMKB.Yunfhsdj
  is '运费含税单价';

alter table DIANCJSMKB add hansyf NUMBER(15,5) default 0;
comment on column DIANCJSMKB.hansyf
  is '含税运费';

alter table DIANCJSMKB add buhsyf NUMBER(15,5) default 0;
comment on column DIANCJSMKB.buhsyf
  is '不含税运费';

alter table DIANCJSMKB add yunfjsl NUMBER(15,5) default 0;
comment on column DIANCJSMKB.yunfjsl
  is '运费结算量';


alter table KUANGFJSMKB add Yunfhsdj NUMBER(14,7) default 0;
comment on column KUANGFJSMKB.Yunfhsdj
  is '运费含税单价';

alter table KUANGFJSMKB add hansyf NUMBER(15,5) default 0;
comment on column KUANGFJSMKB.hansyf
  is '含税运费';

alter table KUANGFJSMKB add buhsyf NUMBER(15,5) default 0;
comment on column KUANGFJSMKB.buhsyf
  is '不含税运费';

alter table KUANGFJSMKB add yunfjsl NUMBER(15,5) default 0;
comment on column KUANGFJSMKB.yunfjsl
  is '运费结算量';

--------------------------------

-- Add/modify columns
alter table DAOZCPB rename column FAHXXB_ID to FAHB_ID;

alter table DAOZCPB add zongkd NUMBER(15,3) default 0;
-- Add comments to the columns
comment on column DAOZCPB.zongkd  is '总扣吨';

alter table daozcpb drop column yunsdwb

alter table DAOZCPB add kuangfzlzb_id NUMBER(15) default 0;
-- Add comments to the columns
comment on column DAOZCPB.kuangfzlzb_id
      is '矿方质量子表id';

alter table DAOZCPB add koum NUMBER(15,3) default 0;
-- Add comments to the columns
comment on column DAOZCPB.koum
      is '扣毛';
----------------------
-- Add/modify columns
alter table GONGYSSQPFB add SHANGJDWMC VARCHAR2(50);
alter table GONGYSSQPFB add SHANGJDWBM VARCHAR2(50);
-- Add comments to the columns
comment on column GONGYSSQPFB.SHANGJDWMC
  is '上级单位名称（下级单位该供应商的父供应商名称）';
comment on column GONGYSSQPFB.SHANGJDWBM
  is '上级单位编码（下级单位该供应商的父供应商的上级公司编码）';
------------------

--1、更新“jiekfspzb”表中对'gongyssqpfb' 的配置语句

insert into jiekfspzb(id,renwmc,renwsql,renwbs,renwtj,mingllx,gengxy)values(34,'gongyssqpfb','select
ID,
FUID,
XUH,
MINGC,
QUANC,
PINY,
BIANM,
DANWDZ,
FADDBR,
WEITDLR,
KAIHYH,
ZHANGH,
DIANH,
SHUIH,
YOUZBM,
CHUANZ,
MEITLY,
MEIZ,
CHUBNL,
KAICNL,
KAICNX,
SHENGCNL,
GONGYNL,
LIUX,
YUNSFS,
SHICCGL,
ZHONGDHT,
YUNSNL,
HEZNX,
RONGQGX,
XINY,
GONGSXZ,
KEGYWFMZ,
KEGYWFMZZB,
SHENGFB_ID,
SHIFSS,
SHANGSDZ,
ZICBFB,
SHOUMBFB,
QITBFB,
BEIZ,
CHENGSB_ID,
(select min(id) from diancxxb where jib=3) DIANCXXB_ID,
(select quanc from gongysb where id=g.fuid) SHANGJDWMC,
(select shangjgsbm from gongysb where id=g.fuid) SHANGJDWBM
from gongysb g %% ',' where gongysb.id=','id','xml','');

-------------------------------------------------------------------------------------------------
--2、更新“jiekjspzb”表中对'gongyssqpfb' 的配置

 528 gongyssqpfb ID number   id
 529 gongyssqpfb FUID number   id y
 530 gongyssqpfb XUH number   id y
 531 gongyssqpfb MINGC number   id y
 532 gongyssqpfb QUANC number   id y
 533 gongyssqpfb PINY number   id y
 534 gongyssqpfb BIANM number   id y
 535 gongyssqpfb DANWDZ number   id y
 536 gongyssqpfb FADDBR number   id y
 537 gongyssqpfb WEITDLR number   id y
 538 gongyssqpfb KAIHYH number   id y
 539 gongyssqpfb ZHANGH number   id y
 540 gongyssqpfb DIANH number   id y
 541 gongyssqpfb SHUIH number   id y
 542 gongyssqpfb YOUZBM number   id y
 543 gongyssqpfb CHUANZ number   id y
 544 gongyssqpfb MEITLY number   id y
 545 gongyssqpfb MEIZ number   id y
 546 gongyssqpfb CHUBNL number   id y
 547 gongyssqpfb KAICNL number   id y
 548 gongyssqpfb KAICNX number   id y
 549 gongyssqpfb SHENGCNL number   id y
 550 gongyssqpfb GONGYNL number   id y
 551 gongyssqpfb LIUX number   id y
 552 gongyssqpfb YUNSFS number   id y
 553 gongyssqpfb SHICCGL number   id y
 554 gongyssqpfb ZHONGDHT number   id y
 555 gongyssqpfb YUNSNL number   id y
 556 gongyssqpfb HEZNX number   id y
 557 gongyssqpfb RONGQGX number   id y
 558 gongyssqpfb XINY number   id y
 559 gongyssqpfb GONGSXZ number   id y
 560 gongyssqpfb KEGYWFMZ number   id y
 561 gongyssqpfb KEGYWFMZZB number   id y
 562 gongyssqpfb SHENGFB_ID number   id y
 563 gongyssqpfb SHIFSS number   id y
 564 gongyssqpfb SHANGSDZ number   id y
 565 gongyssqpfb ZICBFB number   id y
 566 gongyssqpfb SHOUMBFB number   id y
 567 gongyssqpfb QITBFB number   id y
 568 gongyssqpfb BEIZ number   id y
 569 gongyssqpfb CHENGSB_ID number   id y
 571 gongyssqpfb DIANCXXB_ID number   id
 3001 gongyssqpfb SHANGJDWMC number   id y
 3002 gongyssqpfb SHANGJDWBM number

------------------

--倒装车皮表
Create table daozcpb(
    ID number(15) Not Null,
    fahb_id number(15),
    DIANCXXB_ID NUMBER(15) default 0 Not Null,
    PIAOJH VARCHAR2(20),
    GONGYSMC VARCHAR2(40) Not Null,
    MEIKDWMC VARCHAR2(40) Not Null,
    PINZ VARCHAR2(20) Not Null,
    FAZ VARCHAR2(20) Not Null,
    DAOZ VARCHAR2(20) Not Null,
    JIHKJ VARCHAR2(20) Not Null,
    FAHRQ DATE default sysdate Not Null,
    DAOHRQ DATE default sysdate Not Null,
    HETB_ID NUMBER(15) default 0 Not Null,
    ZHILB_ID NUMBER(15) default 0 Not Null,
    CAIYBH VARCHAR2(20) default 0 Not Null,
    JIESB_ID NUMBER(15) default 0 Not Null,
    YUNSFS VARCHAR2(20) default '公路' Not Null,
    CHEC VARCHAR2(20) default '车次' Not Null,
    CHEPH VARCHAR2(20) Not Null,
    MAOZ NUMBER(10,3) default 0 Not Null,
    PIZ NUMBER(10,3) default 0 Not Null,
    BIAOZ NUMBER(10,3) default 0 Not Null,
    YINGD NUMBER(10,3) default 0 Not Null,
    YINGK NUMBER(10,3) default 0 Not Null,
    YUNS NUMBER(10,3) default 0 Not Null,
    YUNSL NUMBER(5,3) default 0 Not Null,
    KOUD NUMBER(8,3) default 0 Not Null,
    KOUS NUMBER(15,3) default 0 Not Null,
    KOUZ NUMBER(10,3) default 0 Not Null,
    Zongkd NUMBER(15) Not Null,
    SANFSL NUMBER(10,3) default 0 Not Null,
    CHES NUMBER(8,3) default 0 Not Null,
    JIANJFS VARCHAR2(10) default '过衡' Not Null,
    QINGCSJ DATE,
    QINGCHH VARCHAR2(20),
    QINGCJJY VARCHAR2(20),
    ZHONGCSJ DATE,
    ZHONGCHH VARCHAR2(20),
    ZHONGCJJY VARCHAR2(20),
    MEICB_ID NUMBER(15) default 0 Not Null,
    DAOZCH VARCHAR2(20),
    LURY VARCHAR2(20) Not Null,
    BEIZ VARCHAR2(200),
    CAIYRQ DATE,
    LURSJ DATE default sysdate Not Null,
    YUNSDW VARCHAR2(50),
    XIECFS VARCHAR2(20),
    YUANMZ NUMBER(10,3),
    YUANPZ NUMBER(10,3),
    Kuangfzlzb_id NUMBER(15) default 0 Not Null,
    koum NUMBER(15,3) default 0 Not Null,
   CONSTRAINT MK_daozcpb PRIMARY KEY(ID))
-------------------
-- Add/modify columns
alter table DANPCJSMXB modify JIESSL NUMBER(20,7);
-----------------------

-- Add/modify columns
alter table DANPCJSMXB modify JIESSL NUMBER(20,7);
--------------------------

-- Create table
create table FAHXXBMB
(
  ID         NUMBER(15) not null,
  BIANM      VARCHAR2(50) not null,
  GONGYSB_ID NUMBER(15) not null,
  MEIKXXB_ID NUMBER(15) not null,
  PINZB_ID   NUMBER(15),
  FAZ_ID     NUMBER(15),
  JIHKJB_ID  NUMBER(15),
  YUNSDWB_ID NUMBER(15),
  MEICB_ID   NUMBER(15),
  YUNSFSB_ID NUMBER(15),
  DAOZ_ID    NUMBER(15),
  ZHUANGT    NUMBER(2),
  BEIZ       VARCHAR2(200)
)
-- Add comments to the table
comment on table FAHXXBMB
  is '发货信息编码表';
-- Add comments to the columns
comment on column FAHXXBMB.ID
  is '主键';
comment on column FAHXXBMB.BIANM
  is '编码唯一';
comment on column FAHXXBMB.GONGYSB_ID
  is '供应商表_id';
comment on column FAHXXBMB.MEIKXXB_ID
  is '煤矿信息表_id';
comment on column FAHXXBMB.PINZB_ID
  is '品种表_id';
comment on column FAHXXBMB.FAZ_ID
  is '车站信息表_id';
comment on column FAHXXBMB.JIHKJB_ID
  is '计划口径表_id';
comment on column FAHXXBMB.YUNSDWB_ID
  is '运输单位表_id';
comment on column FAHXXBMB.MEICB_ID
  is '煤场表_id';
comment on column FAHXXBMB.YUNSFSB_ID
  is '运输方式表_id';
comment on column FAHXXBMB.DAOZ_ID
  is '车站信息表_id';
comment on column FAHXXBMB.ZHUANGT
  is '0,1(未使用,使用)';
comment on column FAHXXBMB.BEIZ
  is '备注';
-- Create/Recreate primary, unique and foreign key constraints
alter table FAHXXBMB
  add primary key (ID);
alter table FAHXXBMB
  add unique (BIANM);
------------------------

--新增字段
alter table meikxxb add meikdq_id number(15) default 0;
comment on column meikxxb.meikdq_id is '煤矿地区_id';
--新增字段
alter table gongysb add leix number(1) default 1;
comment on column gongysb.leix is '类型';


--------------------------------

--描述：修改供应商树
----------------------------------------------------------------------------
create or replace view vwgongysmkczkj as
select rownum wid,id,mingc,fuid,jib,diancxxb_id from
(select 2 jib,0 fuid,g.id,g.mingc,gl.diancxxb_id
        from gongysb g, gongysdcglb gl
        where g.id = gl.gongysb_id and g.leix = 1
union
select 3 jib,ml.gongysb_id,m.id,m.mingc,gl.diancxxb_id
       from meikxxb m, gongysmkglb ml,gongysdcglb gl,gongysb g
       where ml.meikxxb_id = m.id
       and ml.gongysb_id = gl.gongysb_id
       and g.id = gl.gongysb_id and g.leix = 1
union
select distinct
           4 jib,kl.meikxxb_id,c.id,c.mingc,gl.diancxxb_id
  from chezxxb c, gongysmkglb ml, gongysdcglb gl, kuangzglb kl, gongysb g
 where c.id = kl.chezxxb_id
   and kl.meikxxb_id = ml.meikxxb_id
   and ml.gongysb_id = gl.gongysb_id
   and g.id = gl.gongysb_id
   and g.leix = 1
union
select distinct 5 jib,f.chezxxb_id,j.id,j.mingc,f.diancxxb_id
  from fenkcyfsb f, jihkjb j, chezxxb c, gongysmkglb ml,
  gongysdcglb gl,kuangzglb kl, gongysb g
 where f.jihkjb_id = j.id and j.id!=4 and f.chezxxb_id = c.id
       and c.id = kl.chezxxb_id
       and kl.meikxxb_id = ml.meikxxb_id
       and ml.gongysb_id = gl.gongysb_id
       and g.id = gl.gongysb_id
       and g.leix =1
);
----------------------------------------------------------------------
create or replace view vwgongysmkcz as
(select g.id,g.mingc,0 fuid,gl.diancxxb_id,2 jib
        from gongysb g, gongysdcglb gl
        where g.id = gl.gongysb_id
        and g.leix = 1
union
select m.id+ml.gongysb_id,m.mingc,ml.gongysb_id,gl.diancxxb_id,3 jib
       from meikxxb m, gongysmkglb ml,gongysdcglb gl, gongysb g
       where ml.meikxxb_id = m.id
       and ml.gongysb_id = gl.gongysb_id
       and g.id = gl.gongysb_id
       and g.leix = 1
union
select distinct c.id+kl.meikxxb_id+ml.gongysb_id,c.mingc,kl.meikxxb_id+ml.gongysb_id,gl.diancxxb_id,4 jib
       from chezxxb c, gongysmkglb ml, gongysdcglb gl, kuangzglb kl, gongysb g
       where c.id = kl.chezxxb_id
       and kl.meikxxb_id = ml.meikxxb_id
       and ml.gongysb_id = gl.gongysb_id
       and g.id = gl.gongysb_id
       and g.leix = 1 );
------------------------------------------------------------------------
create or replace view vwgongysmkkj as
select rownum wid,id,mingc,fuid,jib,diancxxb_id from
(select 2 jib,0 fuid,g.id,g.mingc,gl.diancxxb_id
        from gongysb g, gongysdcglb gl
        where g.id = gl.gongysb_id and g.leix = 1
union
select 3 jib,ml.gongysb_id,m.id,m.mingc,gl.diancxxb_id
       from meikxxb m, gongysmkglb ml,gongysdcglb gl, gongysb g
       where ml.meikxxb_id = m.id
       and ml.gongysb_id = gl.gongysb_id
       and gl.gongysb_id = g.id
       and g.leix = 1
union
select distinct 4 jib,f.meikxxb_id,j.id,j.mingc,f.diancxxb_id
  from fenkcyfsb f, jihkjb j, gongysmkglb ml,
  gongysdcglb gl, gongysb g
 where f.jihkjb_id = j.id and j.id!=4
       and f.meikxxb_id = ml.meikxxb_id
       and ml.gongysb_id = gl.gongysb_id
       and g.id = gl.gongysb_id
       and g.leix =1
       and f.chezxxb_id = 1
);
------------------------------------------------------------------
create or replace view vwgongysmk as
select l.diancxxb_id,g.id,g.mingc,1 lx from gongysb g, gongysdcglb l
where g.id = l.gongysb_id and g.leix = 1
union select l.diancxxb_id,m.id,m.mingc,0 lx
from meikxxb m, gongysb g, gongysdcglb l, gongysmkglb ml
where g.id = l.gongysb_id  and g.id = ml.gongysb_id
and m.id = ml.meikxxb_id and g.leix = 1;

---------------------------------------

alter table niandhtqkb add xiaf number(1) default 0;
    alter table hetb_mb add XIAFMB number(1) default 0;

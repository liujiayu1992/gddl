create function GetLury(zhilbid number) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_lury zhillsb.lury%TYPE;
   CURSOR C_lury IS SELECT lury FROM zhillsb  where zhilb_id in(zhilbid);

   BEGIN
       OPEN C_lury;
       loop
           FETCH C_lury INTO v_lury;
                 if C_lury%FOUND then
                    Result:=Result||v_lury||',';
                 end if;
                 EXIT WHEN C_lury%NOTFOUND;
           end loop;
           CLOSE C_lury;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end GetLury;

create view VWZHUYZBWCQK as
select a.nianf, a.yuef, a.changbb_id, 1 as xuh,'火电厂发电量(万千瓦时)'as xiangm,n.nianjh,y.yuedwc,
	(select nvl(sum(fadl),0) as benqlj from yuedfxsj
	where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj ) a,
  (select nvl(sum(fadl),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select fadl as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select fadl as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 2 as xuh,'购煤量(万吨)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(shisl/10000),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(shisl/10000),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select shisl/10000 as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select shisl/10000 as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 3 as xuh,'耗煤量(万吨)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(haoy/10000),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(haoy/10000),0) as nianjh,changbb_id ,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select haoy/10000 as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select haoy/10000 as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 4 as xuh,'帐面库存(万吨)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(zhangmkc/10000),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(zhangmkc/10000),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select zhangmkc/10000 as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select zhangmkc/10000 as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 5 as xuh,'实际库存(万吨)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(shijkc/10000),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(shijkc/10000),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select shijkc/10000 as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select shijkc/10000 as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 6 as xuh,'入厂煤热值(千焦/千克)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(rucmrz*1000),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(rucmrz*1000),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select rucmrz*1000 as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select rucmrz*1000 as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 7 as xuh,'入炉煤热值(千焦/千克)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(rulmrz*1000),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(rulmrz*1000),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select rulmrz*1000 as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select rulmrz*1000 as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 8 as xuh,'热值差(千焦/千克)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(rezc*1000),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(rezc*1000),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select rezc*1000 as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select rezc*1000 as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 9 as xuh,'入厂原煤单价(元/吨)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(rucymdj),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(rucymdj),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select rucymdj as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select rucymdj as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 10 as xuh,'入厂标煤单价(元/吨)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(rucbmdj),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(rucbmdj),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select rucbmdj as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select rucbmdj as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 11 as xuh,'发电煤折标煤单价(元/吨)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(fadmzbmdj),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(fadmzbmdj),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select fadmzbmdj as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select fadmzbmdj as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 12 as xuh,'发电综合标煤单价(元/吨)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(fadzhbmdj),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(fadzhbmdj),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select fadzhbmdj as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select fadzhbmdj as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 13 as xuh,'发电煤炭成本(万元)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(fadmtcb),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(fadmtcb),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select fadmtcb as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select fadmtcb as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 14 as xuh,'发电油成本(万元)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(fadycb),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(fadycb),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select fadycb as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select fadycb as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 15 as xuh,'燃料总成本(万元)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(ranlzcb),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(ranlzcb),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select ranlzcb as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select ranlzcb as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)
  union
  select a.nianf, a.yuef, a.changbb_id, 16 as xuh,'发电单位燃料成本(元/千千瓦时)'as xiangm,n.nianjh,y.yuedwc,
  (select nvl(sum(faddwrlcb),0) as benqlj from yuedfxsj
  where nianf = a.nianf and yuef<= a.yuef and changbb_id = a.changbb_id) benqlj
  ,t.tq,(y.yuedwc-t.tq) as zengzl,
  decode(t.tq,0,0,round_new((y.yuedwc-t.tq)*100/t.tq,2)) as zengzlv
  ,decode(n.nianjh,0,0,round_new(y.yuedwc*100/n.nianjh,2)) as yus from
  (select distinct changbb_id,nianf,yuef from yuedfxsj) a,
  (select nvl(sum(faddwrlcb),0) as nianjh,changbb_id,nianf from yuedfxsj group by changbb_id,nianf) n,
  (select faddwrlcb as yuedwc,changbb_id,nianf,yuef from yuedfxsj ) y,
  (select faddwrlcb as tq,changbb_id,nianf,yuef from yuedfxsj ) t
  where a.changbb_id = n.changbb_id(+) and a.changbb_id = y.changbb_id(+)
  and a.changbb_id = t.changbb_id(+) and a.nianf-1 = n.nianf(+) and a.nianf = y.nianf(+)
  and a.nianf-1 = t.nianf(+) and a.yuef = y.yuef(+) and a.yuef = t.yuef(+)


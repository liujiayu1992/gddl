create view VWBIAOMDJPX as
select c.nianf, c.yuef, c.changbb_id, c.fahdwb_id,f.jianc,'本月' xiangm,
	(select daohl from hetlwcqkfkb where nianf = c.nianf and yuef= c.yuef
	and changbb_id = c.changbb_id and fahdwb_id = c.fahdwb_id) daohl,
	c.hetbmdj,c.jiesbmdj,(c.hetbmdj-c.jiesbmdj) bmdjc
	from chebjfxb c, fahdwb f where c.fahdwb_id = f.id union
	select c.nianf, c.yuef, c.changbb_id, c.fahdwb_id,f.jianc,'累计' xiangm,
	(select sum(daohl) from hetlwcqkfkb where nianf = c.nianf and yuef <=c.yuef
	and changbb_id = c.changbb_id and fahdwb_id = c.fahdwb_id) daohl,
	(select round_new(decode(sum(h.daohl),0,0,sum(b.hetbmdj*h.daohl)/sum(h.daohl)),2)
	from chebjfxb b,hetlwcqkfkb h where b.nianf = c.nianf and b.yuef <= c.yuef
	and b.changbb_id = c.changbb_id and b.fahdwb_id = c.fahdwb_id
	and b.nianf = h.nianf and b.yuef = h.yuef and b.changbb_id = h.changbb_id
	and b.fahdwb_id = h.fahdwb_id) hetbmdj,
	(select round_new(decode(sum(h.daohl),0,0,sum(b.jiesbmdj*h.daohl)/sum(h.daohl)),2)
	from chebjfxb b,hetlwcqkfkb h where b.nianf = c.nianf and b.yuef <= c.yuef
	and b.changbb_id = c.changbb_id and b.fahdwb_id = c.fahdwb_id
	and b.nianf = h.nianf and b.yuef = h.yuef and b.changbb_id = h.changbb_id
	and b.fahdwb_id = h.fahdwb_id) jiesbmdj,
	(select round_new(decode(sum(h.daohl),0,0,sum((b.hetbmdj-b.jiesbmdj)*h.daohl)/sum(h.daohl)),2)
	from chebjfxb b,hetlwcqkfkb h where b.nianf = c.nianf and b.yuef <= c.yuef
	and b.changbb_id = c.changbb_id and b.fahdwb_id = c.fahdwb_id
	and b.nianf = h.nianf and b.yuef = h.yuef and b.changbb_id = h.changbb_id
	and b.fahdwb_id = h.fahdwb_id) bmdjc
	from chebjfxb c, fahdwb f where c.fahdwb_id = f.id


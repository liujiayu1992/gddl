create FUNCTION        "GETBEIZ" (zhilbid number) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_beiz zhillsb.beiz%TYPE;
   CURSOR C_beiz IS SELECT beiz FROM zhillsb  where zhilb_id in(zhilbid);

   BEGIN
       OPEN C_beiz;
       loop
           FETCH C_beiz INTO v_beiz;
                 if C_beiz%FOUND then
                    Result:=Result||v_beiz||',';
                 end if;
                 EXIT WHEN C_beiz%NOTFOUND;
           end loop;
           CLOSE C_beiz;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end GetBeiz;

 
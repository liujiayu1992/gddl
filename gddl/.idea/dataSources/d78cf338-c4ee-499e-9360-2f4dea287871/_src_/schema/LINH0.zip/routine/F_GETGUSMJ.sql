create Function f_Getgusmj(In_Hetxxb_Id In Number,
                                      In_Farl      In Number,
                                      In_Liuf      In Number,
                                      In_Shuif     In Number,
                                      In_Huif      In Number,
                                      In_Huiff     In Number) Return Number Is

  --计算此合同的基价
  Type Hetdata Is Record(
    Shangx Number,
    Xiax   Number,
    jiagdw NUMBER,
    Jiag   Number,
    Jis    Number,
    Koufj  Number,
    Zengfj Number,
    beiz VARCHAR2(100));
  farl_ht Hetdata;
  huif_ht Hetdata;
  shuif_ht Hetdata;
  liuf_ht Hetdata;
  huiff_ht Hetdata;
  zengkk_ht Hetdata;
  Type c_Hetjsxyb Is Ref Cursor;
  v_Cur c_Hetjsxyb;
  v_Jijfs    Number(1, 0) := 0;
  v_Gusmj    Number(5, 2) := 0;
  v_Reljg    Number(5, 2) := 0;
  --My_Rec  Hetjsxyb%Rowtype;
  v_Found Boolean := True;
  v_exitloop BOOLEAN := FALSE;

  Type Arraytyp Is Table Of Varchar2(10) Index By Binary_Integer;
  Rangename Arraytyp;
BEGIN
Rangename(1) := 'lower';
Rangename(2) := 'higher';
Rangename(3) := 'between';
  --Declare
  Begin
    Select DISTINCT h.Jijfs
      Into v_Jijfs
      From Hetjsxyb y, Hetxxb h
     Where y.Hetxxb_Id = h.Id
       And h.Id = In_Hetxxb_Id
       And Biaoz = 0;
    --EXCEPTION WHEN OTHERS THEN
  Exception
    When No_Data_Found Then
      Dbms_Output.Put_Line('No_Data_Found');
      Return 0;
    When Others Then
      Dbms_Output.Put_Line('others error');
      Return - 1;
  End;
  Begin
    If v_Jijfs = 1 Then
      --目录价
      Dbms_Output.Put_Line('目录价');
      v_Gusmj := 0;
    Elsif v_Jijfs = 2 Then
      -- 热值区间（卡）
      --寻找匹配的合同，同时计算该合同的基价
      Begin
        Select Decode(Jiagdw, 2, Jiag, In_Farl * Jiag)
          Into v_Reljg
          From Hetjsxyb
         Where Biaoz = 0
           And Rownum < 2
           And Xiangm = 9
           And Hetxxb_Id = In_Hetxxb_Id
           And Decode(Tiaoj,
                      '区间',
                      Round(Decode(Danw, 3, 1000 / 4.1816, 1) * Xiax, 0),
                      '大于等于',
                      Round(Decode(Danw, 3, 1000 / 4.1816, 1) * Xiax, 0),
                      0) <= In_Farl
           And Decode(Tiaoj,
                      '区间',
                      Round(Decode(Danw, 3, 1000 / 4.1816, 1) * Shangx, 0),
                      '大于等于',
                      100000,
                      Round(Decode(Danw, 3, 1000 / 4.1816, 1) * Shangx, 0)) >=
               In_Farl;
      End;
      Dbms_Output.Put_Line('目录价');
      v_Gusmj := v_Reljg;
    Elsif v_Jijfs = 3 Then
      -- 热值区间（吨）
      --寻找匹配的合同，同时计算该合同的基价
      Begin
        Select Jiag As Jiag
          Into v_Reljg
          From Hetjsxyb
         Where Biaoz = 0
           And Rownum < 2
           And Xiangm = 9
           And Hetxxb_Id = In_Hetxxb_Id
           And Decode(Tiaoj, '区间', Xiax, '大于等于', Xiax, 0) <= In_Farl
           And Decode(Tiaoj, '区间', Shangx, '大于等于', 100000, Shangx) >=
               In_Farl;
      End;
      v_Gusmj := v_Reljg;
    Elsif v_Jijfs = 4 Then
      -- 热值按卡扣付
        --取发热量的信息--------------------------------------------------------
        v_Found := False;
        BEGIN---farl-start1
          Pkg_Gusmj.p_Gethetxy(1,
                               v_Cur,
                               9,
                               Rangename(1),
                               0,
                               In_Farl,
                               In_Hetxxb_Id);
          Loop
            Fetch v_Cur
              Into farl_ht;
            Exit When v_Cur%Notfound;
            v_Found := True;
          End Loop;
          Close v_Cur;
        END;--farl-end1
        IF v_Found THEN
            farl_ht.Xiax := farl_ht.Shangx;
            If farl_ht.jiagdw = 1 Then
               farl_ht.jiag := farl_ht.jiag * farl_ht.shangx;
            End If;
        ELSE
          Dbms_Output.Put_Line('热值按卡扣付（发热量）≤No_Data_Found');
        END IF;
        If NOT v_Found THEN
          v_Found := False;
          BEGIN--farl-start2
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                9,
                                Rangename(2),
                                0,
                                In_Farl,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into farl_ht;
                Exit When v_Cur%Notfound;
                v_Found := True;
            End Loop;
            Close v_Cur;
          END;--farl-end2
        End IF;
        IF v_Found THEN
            farl_ht.Shangx := farl_ht.Xiax;
            If farl_ht.jiagdw = 1 Then
               farl_ht.jiag := farl_ht.jiag * farl_ht.shangx;
            End If;
            --Dbms_Output.Put_Line('热值按卡扣付（发热量）≥'||farl_ht.jiag);
        ELSE
          Dbms_Output.Put_Line('热值按卡扣付（发热量）≥No_Data_Found');
        END IF;
        If NOT v_Found Then
          v_Found := False;
          BEGIN--farl-start3
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                9,
                                Rangename(3),
                                0,
                                In_Farl,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into farl_ht;
              Exit When v_Cur%Notfound;
              v_Found := True;
            End Loop;
            Close v_Cur;
          END;--farl-end3
        End IF;
        IF v_Found Then
           farl_ht.jiag := farl_ht.jiag;
        Else
          farl_ht.jiag :=0;
          Dbms_Output.Put_Line('热值按卡扣付（发热量）≤≥No_Data_Found');
        END IF;
        v_Gusmj :=farl_ht.jiag;
        --Dbms_Output.Put_Line('热值按卡扣付（发热量）≥'||v_Gusmj);
        for i in 1..3
        loop
          BEGIN
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                9,
                                Rangename(i),
                                1,
                                In_Farl,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into zengkk_ht;
              Exit When v_Cur%Notfound;
              v_exitloop := TRUE;
            End Loop;
            Close v_Cur;
          END;
          EXIT WHEN i >3 OR v_exitloop;
        end loop;
        IF v_exitloop THEN
            farl_ht.Jis := zengkk_ht.Jis;
            farl_ht.Koufj := zengkk_ht.Koufj;
            farl_ht.Zengfj := zengkk_ht.Zengfj;
        END IF;
        v_exitloop := FALSE;
        v_Found := False;

        --取灰分信息------------------------------------------------------------
        BEGIN--huif-start1
          Pkg_Gusmj.p_Gethetxy(1,
                               v_Cur,
                               3,
                               Rangename(1),
                               0,
                               In_Huif,
                               In_Hetxxb_Id);
          Loop
            Fetch v_Cur
              Into huif_ht;
            Exit When v_Cur%Notfound;
            v_Found := True;
          End Loop;
          Close v_Cur;
        END;--huif-end1
        IF v_Found THEN
            huif_ht.Xiax := huif_ht.Shangx;
        END IF;
        If NOT v_Found THEN
          v_Found := False;
          BEGIN--huif-start2
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                3,
                                Rangename(2),
                                0,
                                In_Huif,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into huif_ht;
              Exit When v_Cur%Notfound;
              v_Found := True;
            End Loop;
            Close v_Cur;
          END;--huif-end2
        End IF;
        IF v_Found THEN
            huif_ht.Shangx := huif_ht.Xiax;
        END IF;
        If NOT v_Found Then
           v_Found := False;
          BEGIN--huif-start3
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                3,
                                Rangename(3),
                                0,
                                In_Huif,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into huif_ht;
              Exit When v_Cur%Notfound;
              v_Found := True;
            End Loop;
            Close v_Cur;
          END;--huif-end3
        End IF;
        v_exitloop := FALSE;
        for i in 1..3
        loop
          BEGIN
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                3,
                                Rangename(i),
                                1,
                                In_Huif,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into zengkk_ht;
              Exit When v_Cur%Notfound;
              v_exitloop := TRUE;
            End Loop;
            Close v_Cur;
          END;
          EXIT WHEN i >3 OR v_exitloop;
        end loop;
        IF v_exitloop THEN
            huif_ht.Jis := zengkk_ht.Jis;
            huif_ht.Koufj := zengkk_ht.Koufj;
            huif_ht.Zengfj := zengkk_ht.Zengfj;
        END IF;
        v_Found := False;
        --取挥发分信息----------------------------------------------------------
        BEGIN--huiff-start1
          Pkg_Gusmj.p_Gethetxy(1,
                               v_Cur,
                               6,
                               Rangename(1),
                               0,
                               In_Huiff,
                               In_Hetxxb_Id);
          Loop
            Fetch v_Cur
              Into huiff_ht;
            Exit When v_Cur%Notfound;
            v_found := True;
          End Loop;
          Close v_Cur;
        END;--huiff-end1
        IF v_Found THEN
            huiff_ht.Xiax := huiff_ht.Shangx;
        END IF;
        If NOT v_Found THEN
          v_Found := False;
          BEGIN--huiff-start2
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                6,
                                Rangename(2),
                                0,
                                In_Huiff,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into huiff_ht;
              Exit When v_Cur%Notfound;
              v_found := True;
            End Loop;
            Close v_Cur;
          END;--huiff-end2
        End IF;
        IF v_Found THEN
            huiff_ht.Shangx := huiff_ht.Xiax;
        END IF;
        If NOT v_Found Then
           v_Found := False;
          BEGIN--huiff-start3
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                6,
                                Rangename(3),
                                0,
                                In_Huiff,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into huiff_ht;
              Exit When v_Cur%Notfound;
              v_found := True;
            End Loop;
            Close v_Cur;
          END;--huiff-end3
        End IF;
        v_exitloop := FALSE;
        for i in 1..3
        loop
          BEGIN
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                6,
                                Rangename(i),
                                1,
                                In_Huiff,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into zengkk_ht;
              Exit When v_Cur%Notfound;
              v_exitloop := TRUE;
            End Loop;
            Close v_Cur;
          END;
          EXIT WHEN i >3 OR v_exitloop;
        end loop;
        IF v_exitloop THEN
            huiff_ht.Jis := zengkk_ht.Jis;
            huiff_ht.Koufj := zengkk_ht.Koufj;
            huiff_ht.Zengfj := zengkk_ht.Zengfj;
        END IF;
        v_Found := False;
        --取硫分信息------------------------------------------------------------
        BEGIN--liuf-start1
          Pkg_Gusmj.p_Gethetxy(1,
                               v_Cur,
                               7,
                               Rangename(1),
                               0,
                               In_Liuf,
                               In_Hetxxb_Id);
          Loop
            Fetch v_Cur
              Into liuf_ht;
            Exit When v_Cur%Notfound;
            v_found := True;
          End Loop;
          Close v_Cur;
        END;--liuf-end1
        IF v_Found THEN
            liuf_ht.Xiax := liuf_ht.Shangx;
        END IF;
        If NOT v_Found THEN
          v_Found := False;
          BEGIN--liuf-start2
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                7,
                                Rangename(2),
                                0,
                                In_Liuf,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into liuf_ht;
              Exit When v_Cur%Notfound;
              v_found := True;
            End Loop;
            Close v_Cur;
          END;--liuf-end2
        End IF;
        IF v_Found THEN
            liuf_ht.Shangx := liuf_ht.Xiax;
        END IF;
        If NOT v_Found Then
           v_Found := False;
          BEGIN--liuf-start3
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                7,
                                Rangename(3),
                                0,
                                In_Liuf,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into liuf_ht;
              Exit When v_Cur%Notfound;
              v_found := True;
            End Loop;
            Close v_Cur;
          END;--liuf-end3
        End IF;
        v_exitloop := FALSE;
        for i in 1..3
        loop
          BEGIN
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                7,
                                Rangename(i),
                                1,
                                In_Liuf,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into zengkk_ht;
              Exit When v_Cur%Notfound;
              v_exitloop := TRUE;
            End Loop;
            Close v_Cur;
          END;
          EXIT WHEN i >3 OR v_exitloop;
        end loop;
        IF v_exitloop THEN
            liuf_ht.Jis := zengkk_ht.Jis;
            liuf_ht.Koufj := zengkk_ht.Koufj;
            liuf_ht.Zengfj := zengkk_ht.Zengfj;
        END IF;
        v_Found := False;
        --取水分信息------------------------------------------------------------
        BEGIN--shuif-start1
          Pkg_Gusmj.p_Gethetxy(1,
                               v_Cur,
                               1,
                               Rangename(1),
                               0,
                               In_Shuif,
                               In_Hetxxb_Id);
          Loop
            Fetch v_Cur
              Into shuif_ht;
            Exit When v_Cur%Notfound;
            v_found := True;
          End Loop;
          Close v_Cur;
        END;--shuif-end1
        IF v_Found THEN
            shuif_ht.Xiax := shuif_ht.Shangx;
        END IF;
        If NOT v_Found THEN
          v_Found := False;
          BEGIN--shuif-start2
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                1,
                                Rangename(2),
                                0,
                                In_Shuif,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into shuif_ht;
              Exit When v_Cur%Notfound;
              v_found := True;
            End Loop;
            Close v_Cur;
          END;--shuif-end2
        End IF;
        IF v_Found THEN
            shuif_ht.Shangx := shuif_ht.Xiax;
        END IF;
        If NOT v_Found THEN
          v_Found := False;
          BEGIN--shuif-start3
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                1,
                                Rangename(3),
                                0,
                                In_Shuif,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into shuif_ht;
              Exit When v_Cur%Notfound;
              v_found := True;
            End Loop;
            Close v_Cur;
          END;--shuif-end3
        End IF;
        v_exitloop := FALSE;
        for i in 1..3
        loop
          BEGIN
            Pkg_Gusmj.p_Gethetxy(1,
                                v_Cur,
                                1,
                                Rangename(i),
                                1,
                                In_Shuif,
                                In_Hetxxb_Id);
            Loop
              Fetch v_Cur
                Into zengkk_ht;
              Exit When v_Cur%Notfound;
              v_exitloop := TRUE;
            End Loop;
            Close v_Cur;
          END;
          EXIT WHEN i >3 OR v_exitloop;
        end loop;
        IF v_exitloop THEN
            shuif_ht.Jis := zengkk_ht.Jis;
            shuif_ht.Koufj := zengkk_ht.Koufj;
            shuif_ht.Zengfj := zengkk_ht.Zengfj;
        END IF;
      End If;--计价方式＝4 end

      IF v_gusmj IS NULL THEN
        v_gusmj :=0;
      END IF;
      Dbms_Output.Put_Line('合同基价：');
      Dbms_Output.Put_Line(v_Gusmj);
      --计算折价----------------------------------------------------------------
      DECLARE
      v_zhej_farl NUMBER(10,5) :=0;
      v_zhej_liuf NUMBER(10,5) :=0;
      v_zhej_huif NUMBER(10,5) :=0;
      v_zhej_huiff NUMBER(10,5) :=0;
      v_zhej_shuif NUMBER(10,5) :=0;
      BEGIN
        --发热量折价
        IF farl_ht.jis = 0 THEN
          farl_ht.jis := 1;
        END IF ;
        IF farl_ht.Shangx = farl_ht.Xiax THEN---≥、≤
          v_zhej_farl := F_GETNEARLYDATA((In_Farl - farl_ht.Shangx)/farl_ht.jis,farl_ht.beiz,0);
          IF farl_ht.Shangx >= in_farl THEN
            v_zhej_farl := v_zhej_farl * farl_ht.koufj;
          END IF;
          IF farl_ht.Shangx <= in_farl THEN
            v_zhej_farl := v_zhej_farl * farl_ht.zengfj;
          END IF;
        ELSE---区间
        Dbms_Output.Put_Line('结算热量：'||in_farl);
        Dbms_Output.Put_Line('合同热量：'||farl_ht.shangx);
        Dbms_Output.Put_Line('价格基数：'||farl_ht.jis);
          IF in_farl >= farl_ht.shangx THEN
            v_zhej_farl := F_GETNEARLYDATA((In_Farl - farl_ht.Shangx)/farl_ht.jis,farl_ht.beiz,0);
            v_zhej_farl := v_zhej_farl * farl_ht.zengfj;
          ELSIF in_farl <= farl_ht.xiax THEN
            v_zhej_farl := F_GETNEARLYDATA((In_Farl - farl_ht.xiax)/farl_ht.jis,farl_ht.beiz,0);
            v_zhej_farl := v_zhej_farl * farl_ht.koufj;
          END IF;
        END IF;
        Dbms_Output.Put_Line('发热量折价：');
        Dbms_Output.Put_Line(v_zhej_farl);
        --硫分折价
        IF liuf_ht.jis = 0 THEN
          liuf_ht.jis := 1;
        END IF;
        IF liuf_ht.Shangx = liuf_ht.Xiax THEN---≥、≤
          v_zhej_liuf := F_GETNEARLYDATA((In_liuf - liuf_ht.Shangx)/liuf_ht.jis,liuf_ht.beiz,2);
          IF farl_ht.Shangx >= in_farl THEN
            v_zhej_liuf := v_zhej_liuf * liuf_ht.koufj;
          END IF;
          IF farl_ht.Shangx <= In_liuf THEN
            v_zhej_liuf := v_zhej_liuf * liuf_ht.zengfj;
          END IF;
        ELSE---区间
          IF in_farl >= liuf_ht.shangx THEN
            v_zhej_liuf := F_GETNEARLYDATA((In_liuf - liuf_ht.Shangx)/liuf_ht.jis,liuf_ht.beiz,2);
            v_zhej_liuf := v_zhej_liuf * (In_liuf - liuf_ht.Shangx)*liuf_ht.zengfj;
          ELSIF in_farl <= liuf_ht.xiax THEN
            v_zhej_liuf := F_GETNEARLYDATA((In_liuf - liuf_ht.xiax)/liuf_ht.jis,liuf_ht.beiz,2);
            v_zhej_liuf := v_zhej_liuf * (In_liuf - liuf_ht.xiax)*liuf_ht.koufj;
          END IF;
        END IF;
        Dbms_Output.Put_Line('硫折价：');
        Dbms_Output.Put_Line(v_zhej_liuf);
        --灰分折价
        IF huif_ht.jis = 0 THEN
          huif_ht.jis := 1;
        END IF;
        IF huif_ht.Shangx = huif_ht.Xiax THEN---≥、≤
          v_zhej_huif := F_GETNEARLYDATA((In_liuf - huif_ht.Shangx)/huif_ht.jis,huif_ht.beiz,2);
          IF farl_ht.Shangx >= in_farl THEN
            v_zhej_huif := v_zhej_huif * huif_ht.koufj;
          END IF;
          IF farl_ht.Shangx <= In_liuf THEN
            v_zhej_huif := v_zhej_huif * huif_ht.zengfj;
          END IF;
        ELSE---区间
          IF in_farl >= huif_ht.shangx THEN
            v_zhej_huif := F_GETNEARLYDATA((In_liuf - huif_ht.Shangx)/huif_ht.jis,huif_ht.beiz,2);
            v_zhej_huif := v_zhej_huif * (In_liuf - huif_ht.Shangx)*huif_ht.zengfj;
          ELSIF in_farl <= huif_ht.xiax THEN
            v_zhej_huif := F_GETNEARLYDATA((In_liuf - huif_ht.xiax)/huif_ht.jis,huif_ht.beiz,2);
            v_zhej_huif := v_zhej_huif * (In_liuf - huif_ht.xiax)*huif_ht.koufj;
          END IF;
        END IF;
        Dbms_Output.Put_Line('灰分折价：');
        Dbms_Output.Put_Line(v_zhej_huif);
        --挥发分折价
        IF huiff_ht.jis = 0 THEN
          huiff_ht.jis := 1;
        END IF;
        IF huiff_ht.Shangx = huiff_ht.Xiax THEN---≥、≤
          v_zhej_huiff := F_GETNEARLYDATA((In_liuf - huiff_ht.Shangx)/huiff_ht.jis,huiff_ht.beiz,2);
          IF farl_ht.Shangx >= in_farl THEN
            v_zhej_huiff := v_zhej_huiff * huiff_ht.koufj;
          END IF;
          IF farl_ht.Shangx <= In_liuf THEN
            v_zhej_huiff := v_zhej_huiff * huiff_ht.zengfj;
          END IF;
        ELSE---区间
          IF in_farl >= huiff_ht.shangx THEN
            v_zhej_huiff := F_GETNEARLYDATA((In_liuf - huiff_ht.Shangx)/huiff_ht.jis,huiff_ht.beiz,2);
            v_zhej_huiff := v_zhej_huiff * (In_liuf - huiff_ht.Shangx)*huiff_ht.zengfj;
          ELSIF in_farl <= huiff_ht.xiax THEN
            v_zhej_huiff := F_GETNEARLYDATA((In_liuf - huiff_ht.xiax)/huiff_ht.jis,huiff_ht.beiz,2);
            v_zhej_huiff := v_zhej_huiff * (In_liuf - huiff_ht.xiax)*huiff_ht.koufj;
          END IF;
        END IF;
        Dbms_Output.Put_Line('挥发分折价：');
        Dbms_Output.Put_Line(v_zhej_huiff);
        --水分折价
        IF shuif_ht.jis = 0 THEN
          shuif_ht.jis := 1;
        END IF;
        IF shuif_ht.Shangx = shuif_ht.Xiax THEN---≥、≤
          v_zhej_shuif := F_GETNEARLYDATA((In_liuf - shuif_ht.Shangx)/shuif_ht.jis,shuif_ht.beiz,2);
          IF farl_ht.Shangx >= in_farl THEN
            v_zhej_shuif := v_zhej_shuif * shuif_ht.koufj;
          END IF;
          IF farl_ht.Shangx <= In_liuf THEN
            v_zhej_shuif := v_zhej_shuif * shuif_ht.zengfj;
          END IF;
        ELSE---区间
          IF in_farl >= shuif_ht.shangx THEN
            v_zhej_shuif := F_GETNEARLYDATA((In_liuf - shuif_ht.Shangx)/shuif_ht.jis,shuif_ht.beiz,2);
            v_zhej_shuif := v_zhej_shuif * (In_liuf - shuif_ht.Shangx)*shuif_ht.zengfj;
          ELSIF in_farl <= shuif_ht.xiax THEN
            v_zhej_shuif := F_GETNEARLYDATA((In_liuf - shuif_ht.xiax)/shuif_ht.jis,shuif_ht.beiz,2);
            v_zhej_shuif := v_zhej_shuif * (In_liuf - shuif_ht.xiax)*shuif_ht.koufj;
          END IF;
        END IF;
        Dbms_Output.Put_Line('水分折价：');
        Dbms_Output.Put_Line(v_zhej_shuif);
        v_Gusmj := v_Gusmj + v_zhej_farl + v_zhej_liuf + v_zhej_huif + v_zhej_huiff + v_zhej_shuif;
      END;
      Dbms_Output.Put_Line('估算煤价：');
      Dbms_Output.Put_Line(v_Gusmj);
      Return v_Gusmj;
    End;
  End;

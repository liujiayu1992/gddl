create view FADQYMTKCQKB as
select t.rihm as rihm,nvl(d.jingjcml,0) as jingjcml,t.riq as riq from
        (select round_new(sum(fadh + gongrh + qitym) /
                            to_number(to_char(riq, 'dd')),
                            0) as rihm,
               riq
          from pandtjb_jt
           where to_char(riq,'hh24:mi:ss') = '09:00:00'
         group by riq) t,diancxxb d


create view VWGONGYSMKQC as
select l.diancxxb_id,g.id,g.quanc mingc,1 lx from gongysb g, gongysdcglb l
where g.id = l.gongysb_id
union select l.diancxxb_id,m.id,m.quanc mingc,0 lx
from meikxxb m, gongysb g, gongysdcglb l, gongysmkglb ml
where g.id = l.gongysb_id  and g.id = ml.gongysb_id
and m.id = ml.meikxxb_id
union select s.diancxxb_id,s.shihgysb_id id,s.gongysmc as mingc,1 lx from shihjsb s


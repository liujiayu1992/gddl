create FUNCTION        "GETLINKMINGXKC" (strIDdianc in varchar2,strIDgongys in varchar2, strLable in  varchar2) return varchar2 is

begin
       if strIDdianc='-1'  or strIDgongys='-1' then
          return strLable;
       else
         return '<a href="#" onclick="openMingxKc('||chr(39)||strIDdianc||','||strIDgongys||chr(39)||')">'||strLable||'</a>';
       end if;
end getLinkMingxKc;



 
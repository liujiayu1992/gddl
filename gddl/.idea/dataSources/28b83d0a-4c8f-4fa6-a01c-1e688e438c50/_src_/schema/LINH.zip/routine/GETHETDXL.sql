create FUNCTION        "GETHETDXL" (LNGDIANCXXB_ID IN NUMBER,
                                     DATRIQ         DATE,
                                     LEIX           STRING) RETURN NUMBER IS
  --RESULT VARCHAR2(1000); --重点合同兑现率
  BEGIN
    DECLARE

      MIAOS    NUMBER;
      YUEJHCGL NUMBER;

      YUEF  NUMBER;
      NIANF NUMBER;

      LTH VARCHAR2(1000);

      JIB NUMBER;

    BEGIN

      MIAOS := 0;
      SELECT JIB INTO JIB FROM DIANCXXB WHERE ID = LNGDIANCXXB_ID;

      SELECT TO_CHAR(DATRIQ, 'mm') INTO YUEF FROM DUAL;
      SELECT TO_CHAR(DATRIQ, 'yyyy') INTO NIANF FROM DUAL;

      SELECT TO_CHAR(DATRIQ, 'yyyy-mm') INTO LTH FROM DUAL;
      --------------上海电厂--------------------------

      IF (LNGDIANCXXB_ID = 174 OR LNGDIANCXXB_ID = 138 OR
          LNGDIANCXXB_ID = 173 OR LNGDIANCXXB_ID = 136 OR
          LNGDIANCXXB_ID = 137 OR LNGDIANCXXB_ID = 139 OR
          LNGDIANCXXB_ID = 135 OR LNGDIANCXXB_ID = 191 OR
          LNGDIANCXXB_ID = 134 OR LNGDIANCXXB_ID = 181 OR
          LNGDIANCXXB_ID = 180 OR LNGDIANCXXB_ID = 133 OR
          LNGDIANCXXB_ID = 151 OR LNGDIANCXXB_ID = 157) THEN
        IF (LEIX = '本月') THEN
          SELECT MAX(DUIXL) ---------------本月
          INTO MIAOS
          FROM DUIXLB
          WHERE RIQ = DATRIQ
                AND DIANCXXB_ID = LNGDIANCXXB_ID
                AND FENX = '本月';
        ELSE
          ----------累计
          SELECT MAX(DUIXL) ---------------本月
          INTO MIAOS
          FROM DUIXLB
          WHERE RIQ = DATRIQ
                AND DIANCXXB_ID = LNGDIANCXXB_ID
                AND FENX = '累计';

        END IF;

        -------------一般电厂---------------------
      ELSE

        IF (LEIX = '本月') THEN
          IF (JIB = 3) THEN
            ---------------本月
            SELECT NVL(SUM(HTQK.YUEJHCGL), 0)
            INTO YUEJHCGL
            FROM YUECGJHB HTQK
            WHERE HTQK.RIQ = DATRIQ
                  AND (HTQK.JIHKJB_ID = 1 OR HTQK.JIHKJB_ID = 3)
                  AND HTQK.DIANCXXB_ID = LNGDIANCXXB_ID;

            SELECT NVL(SUM(LAIMSL), 0)
            INTO MIAOS
            FROM YUESLB SL, YUETJKJB KJ
            WHERE KJ.ID = SL.YUETJKJB_ID
                  AND KJ.RIQ = DATRIQ
                  AND KJ.DIANCXXB_ID = LNGDIANCXXB_ID
                  AND (KJ.JIHKJB_ID = 1 OR KJ.JIHKJB_ID = 3)
                  AND SL.FENX = '本月';
            IF (YUEJHCGL != 0) THEN
              MIAOS := ROUND_NEW(MIAOS / YUEJHCGL * 100, 2);
            ELSE
              MIAOS := 0;
            END IF;
          ELSE
            IF (JIB = 2) THEN
              ---------------本月
              SELECT NVL(SUM(HTQK.YUEJHCGL), 0)
              INTO YUEJHCGL
              FROM YUECGJHB HTQK, DIANCXXB DC
              WHERE HTQK.RIQ = DATRIQ
                    AND DC.ID = HTQK.DIANCXXB_ID
                    AND (HTQK.JIHKJB_ID = 1 OR HTQK.JIHKJB_ID = 3)
                    AND DC.FUID = LNGDIANCXXB_ID
                    AND dc.id IN (SELECT diancxxb_id FROM dianckjmx WHERE dianckjb_id=1006951090);

              SELECT NVL(SUM(LAIMSL), 0)
              INTO MIAOS
              FROM YUESLB SL, YUETJKJB KJ, DIANCXXB DC
              WHERE KJ.ID = SL.YUETJKJB_ID
                    AND KJ.RIQ = DATRIQ
                    AND KJ.DIANCXXB_ID = DC.ID
                    AND DC.FUID = LNGDIANCXXB_ID
                    AND (KJ.JIHKJB_ID = 1 OR KJ.JIHKJB_ID = 3)
                    AND SL.FENX = '本月'
                    AND dc.id IN (SELECT diancxxb_id FROM dianckjmx WHERE dianckjb_id=1006951090);
              IF (YUEJHCGL != 0) THEN
                MIAOS := ROUND_NEW(MIAOS / YUEJHCGL * 100, 2);
              ELSE
                MIAOS := 0;
              END IF;
            ELSE
              IF (JIB = 1) THEN
                ---------------本月
                SELECT NVL(SUM(HTQK.YUEJHCGL), 0)
                INTO YUEJHCGL
                FROM YUECGJHB HTQK
                WHERE HTQK.RIQ = DATRIQ
                      AND HTQK.DIANCXXB_ID  IN (SELECT diancxxb_id FROM dianckjmx WHERE dianckjb_id=1006951090)
                      AND (HTQK.JIHKJB_ID = 1 OR HTQK.JIHKJB_ID = 3);
                -- AND HTQK.DIANCXXB_ID = LNGDIANCXXB_ID;

                SELECT NVL(SUM(LAIMSL), 0)
                INTO MIAOS
                FROM YUESLB SL, YUETJKJB KJ
                WHERE KJ.ID = SL.YUETJKJB_ID
                      AND KJ.RIQ = DATRIQ
                      AND KJ.DIANCXXB_ID  IN (SELECT diancxxb_id FROM dianckjmx WHERE dianckjb_id=1006951090)
                      --  AND KJ.DIANCXXB_ID = LNGDIANCXXB_ID
                      AND (KJ.JIHKJB_ID = 1 OR KJ.JIHKJB_ID = 3)
                      AND SL.FENX = '本月';
                IF (YUEJHCGL != 0) THEN
                  MIAOS := ROUND_NEW(MIAOS / YUEJHCGL * 100, 2);
                ELSE
                  MIAOS := 0;
                END IF;
              END IF;
            END IF;
          END IF;

        ELSE
          ----------累计

          IF (JIB =3) THEN
            SELECT NVL(SUM(HTQK.YUEJHCGL), 0)
            INTO YUEJHCGL
            FROM YUECGJHB HTQK
            WHERE HTQK.RIQ > = GETYEARFIRSTDATE(DATRIQ)
                  AND HTQK.RIQ < = DATRIQ
                  AND (HTQK.JIHKJB_ID = 1 OR HTQK.JIHKJB_ID = 3)

                  AND HTQK.DIANCXXB_ID = LNGDIANCXXB_ID;

            SELECT NVL(SUM(LAIMSL), 0)
            INTO MIAOS
            FROM YUESLB SL, YUETJKJB KJ
            WHERE KJ.ID = SL.YUETJKJB_ID
                  AND KJ.RIQ >= GETYEARFIRSTDATE(DATRIQ)
                  AND KJ.RIQ <= DATRIQ
                  AND KJ.DIANCXXB_ID = LNGDIANCXXB_ID
                  AND (KJ.JIHKJB_ID = 1 OR KJ.JIHKJB_ID = 3)
                  AND SL.FENX = '本月';

            IF (YUEJHCGL != 0) THEN
              MIAOS := ROUND_NEW(MIAOS / YUEJHCGL * 100, 2);
            ELSE
              MIAOS := 0;
            END IF;
          ELSE IF (JIB =2) THEN
            ----------累计----------
            SELECT NVL(SUM(HTQK.YUEJHCGL), 0)
            INTO YUEJHCGL
            FROM YUECGJHB HTQK,diancxxb dc
            WHERE HTQK.RIQ > = GETYEARFIRSTDATE(DATRIQ)
                  AND HTQK.RIQ < = DATRIQ
                  AND (HTQK.JIHKJB_ID = 1 OR HTQK.JIHKJB_ID = 3)
                  AND DC.ID = HTQK.DIANCXXB_ID
                  --  AND htqk.zhuangt>=1
                  AND dc.fuid = LNGDIANCXXB_ID
                  AND dc.id IN (SELECT diancxxb_id FROM dianckjmx WHERE dianckjb_id=1006951090);

            SELECT NVL(SUM(LAIMSL), 0)
            INTO MIAOS
            FROM YUESLB SL, YUETJKJB KJ,diancxxb dc
            WHERE KJ.ID = SL.YUETJKJB_ID
                  AND KJ.RIQ >= GETYEARFIRSTDATE(DATRIQ)
                  AND KJ.RIQ <= DATRIQ
                  AND DC.ID = KJ.DIANCXXB_ID
                  AND dc.fuid = LNGDIANCXXB_ID
                  AND dc.id IN (SELECT diancxxb_id FROM dianckjmx WHERE dianckjb_id=1006951090)
                  --  AND sl.zhuangt>=1
                  AND (KJ.JIHKJB_ID = 1 OR KJ.JIHKJB_ID = 3)
                  AND SL.FENX = '本月';

            IF (YUEJHCGL != 0) THEN
              MIAOS := ROUND_NEW(MIAOS / YUEJHCGL * 100, 2);
            ELSE
              MIAOS := 0;
            END IF;
          ELSE IF (JIB = 1) THEN
            ----------累计----------
            SELECT NVL(SUM(HTQK.YUEJHCGL), 0)
            INTO YUEJHCGL
            FROM YUECGJHB HTQK
            WHERE HTQK.RIQ > = GETYEARFIRSTDATE(DATRIQ)
                  AND HTQK.RIQ < = DATRIQ
                  -- AND HTQK.zhuangt=2
                  AND (HTQK.JIHKJB_ID = 1 OR HTQK.JIHKJB_ID = 3)

                  AND HTQK.DIANCXXB_ID IN (SELECT diancxxb_id FROM dianckjmx WHERE dianckjb_id=1006951090);
            --  AND HTQK.DIANCXXB_ID = LNGDIANCXXB_ID;

            SELECT NVL(SUM(LAIMSL), 0)
            INTO MIAOS
            FROM YUESLB SL, YUETJKJB KJ
            WHERE KJ.ID = SL.YUETJKJB_ID
                  AND KJ.RIQ >= GETYEARFIRSTDATE(DATRIQ)
                  AND KJ.RIQ <= DATRIQ
                  -- AND KJ.DIANCXXB_ID = LNGDIANCXXB_ID
                  AND (KJ.JIHKJB_ID = 1 OR KJ.JIHKJB_ID = 3)
                  --  AND sl.zhuangt=2
                  AND KJ.DIANCXXB_ID  IN (SELECT diancxxb_id FROM dianckjmx WHERE dianckjb_id=1006951090)
                  AND SL.FENX = '本月';

            IF (YUEJHCGL != 0) THEN
              MIAOS := ROUND_NEW(MIAOS / YUEJHCGL * 100, 2);
            ELSE
              MIAOS := 0;
            END IF;
          END IF ;
          END IF;
          END IF;

        END IF;

      END IF;
      RETURN MIAOS;
      EXCEPTION
      WHEN OTHERS THEN

      RETURN MIAOS;
    END;

  END GETHETDXL;

 
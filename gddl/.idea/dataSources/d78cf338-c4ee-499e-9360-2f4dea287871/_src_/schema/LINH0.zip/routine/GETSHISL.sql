create FUNCTION GETSHISL(FID        NUMBER,
                                    JID        NUMBER,
                                    ZHONGLJSYJ VARCHAR2) RETURN NUMBER IS
BEGIN
  DECLARE
    RESULTSET NUMBER;
  BEGIN
    SELECT CASE
             WHEN ZHONGLJSYJ = '票重+盈吨-亏吨' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0) + ROUND_NEW(SUM(YINGD), 0) -
                      ROUND_NEW(SUM(KUID), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '票重' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '毛重-皮重' THEN
              (SELECT ROUND_NEW(SUM(MAOZ), 0) - ROUND_NEW(SUM(PIZ), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '毛重-皮重+运损' THEN
              (SELECT ROUND_NEW(SUM(MAOZ), 0) - ROUND_NEW(SUM(PIZ), 0) +
                      ROUND_NEW(SUM(YUNS), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '毛重-皮重+运损-亏吨' THEN
              (SELECT ROUND_NEW(SUM(MAOZ), 0) - ROUND_NEW(SUM(PIZ), 0) +
                      ROUND_NEW(SUM(YUNS), 0) - ROUND_NEW(SUM(KUID), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '毛重-皮重+运损-亏吨-扣吨' THEN
              (SELECT ROUND_NEW(SUM(MAOZ), 0) - ROUND_NEW(SUM(PIZ), 0) +
                      ROUND_NEW(SUM(YUNS), 0) - ROUND_NEW(SUM(KUID), 0) -
                      ROUND_NEW(SUM(KOUD), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '毛重-皮重+运损-亏吨-扣吨-扣杂' THEN
              (SELECT ROUND_NEW(SUM(MAOZ), 0) - ROUND_NEW(SUM(PIZ), 0) +
                      ROUND_NEW(SUM(YUNS), 0) - ROUND_NEW(SUM(KUID), 0) -
                      ROUND_NEW(SUM(KOUD), 0) - ROUND_NEW(SUM(KOUZ), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '毛重-皮重+运损-亏吨-扣吨-扣杂-扣水' THEN
              (SELECT ROUND_NEW(SUM(MAOZ), 0) - ROUND_NEW(SUM(PIZ), 0) +
                      ROUND_NEW(SUM(YUNS), 0) - ROUND_NEW(SUM(KUID), 0) -
                      ROUND_NEW(SUM(KOUD), 0) - ROUND_NEW(SUM(KOUZ), 0) -
                      ROUND_NEW(SUM(KOUSSL), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '票重-亏吨' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0) - ROUND_NEW(SUM(KUID), 0)
                 FROM CHEPB
                WHERE FAHB_ID = ID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '票重+盈吨-亏吨-扣吨' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0) + ROUND_NEW(SUM(YINGD), 0) -
                      ROUND_NEW(SUM(KUID), 0) - ROUND_NEW(SUM(KOUD), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '票重+盈吨-亏吨-扣吨-扣杂' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0) + ROUND_NEW(SUM(YINGD), 0) -
                      ROUND_NEW(SUM(KUID), 0) - ROUND_NEW(SUM(KOUD), 0) -
                      ROUND_NEW(SUM(KOUZ), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '毛重-皮重-扣吨' THEN
              (SELECT ROUND_NEW(SUM(MAOZ), 0) - ROUND_NEW(SUM(PIZ), 0) -
                      ROUND_NEW(SUM(KOUD), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '毛重-皮重-扣吨-扣杂' THEN
              (SELECT ROUND_NEW(SUM(MAOZ), 0) - ROUND_NEW(SUM(PIZ), 0) -
                      ROUND_NEW(SUM(KOUZ), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '票重-扣吨' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0) - ROUND_NEW(SUM(KOUD), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '票重-扣吨-扣杂' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0) - ROUND_NEW(SUM(KOUD), 0) -
                      ROUND_NEW(SUM(KOUZ), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '票重+盈吨-亏吨-扣水' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0) + ROUND_NEW(SUM(YINGD), 0) -
                      ROUND_NEW(SUM(KUID), 0) - ROUND_NEW(SUM(KOUSSL), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '毛重-皮重-扣水' THEN
              (SELECT ROUND_NEW(SUM(MAOZ), 0) - ROUND_NEW(SUM(PIZ), 0) +
                      ROUND_NEW(SUM(KOUSSL), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '票重+盈吨-亏吨-扣吨-扣水' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0) + ROUND_NEW(SUM(YINGD), 0) -
                      ROUND_NEW(SUM(KUID), 0) - ROUND_NEW(SUM(KOUD), 0) -
                      ROUND_NEW(SUM(KOUSSL), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '票重+盈吨-亏吨-扣吨-扣杂-扣水' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0) + ROUND_NEW(SUM(YINGD), 0) -
                      ROUND_NEW(SUM(KUID), 0) - ROUND_NEW(SUM(KOUD), 0) -
                      ROUND_NEW(SUM(KOUZ), 0) - ROUND_NEW(SUM(KOUSSL), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '毛重-皮重-扣吨-扣水' THEN
              (SELECT ROUND_NEW(SUM(MAOZ), 0) - ROUND_NEW(SUM(PIZ), 0) -
                      ROUND_NEW(SUM(KOUD), 0) - ROUND_NEW(SUM(KOUSSL), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '毛重-皮重-扣吨-扣杂-扣水' THEN
              (SELECT ROUND_NEW(SUM(MAOZ), 0) - ROUND_NEW(SUM(PIZ), 0) -
                      ROUND_NEW(SUM(KOUD), 0) - ROUND_NEW(SUM(KOUZ), 0) -
                      ROUND_NEW(SUM(KOUSSL), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '票重-扣水' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0) - ROUND_NEW(SUM(KOUSSL), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '票重-扣吨-扣水' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0) - ROUND_NEW(SUM(KOUD), 0) -
                      ROUND_NEW(SUM(KOUSSL), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '票重-扣吨-扣杂-扣水' THEN
              (SELECT ROUND_NEW(SUM(BIAOZ), 0) - ROUND_NEW(SUM(KOUD), 0) -
                      ROUND_NEW(SUM(KOUZ), 0) - ROUND_NEW(SUM(KOUSSL), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
             WHEN ZHONGLJSYJ = '煤管量' THEN
              (SELECT ROUND_NEW(SUM(MEIGZZL), 0)
                 FROM CHEPB
                WHERE FAHB_ID = FID
                  AND JIESB_ID = JID)
           END
      INTO RESULTSET
      FROM DUAL;
    RETURN RESULTSET;
  END;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('不知道为什么!');
    RETURN - 1;
END GETSHISL;

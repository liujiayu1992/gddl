create Function getDiancId(strDiancName In varchar2)
Return  number as
begin
     declare
     diancid number;
     begin
     select id into diancid from diancxxb dc where dc.mingc=strDiancName;
     return diancid;
     end;
End;

create trigger TRIGGER_ZHILBTMP
	before insert or update or delete
	on ZHILBTMP
	for each row
Declare
      v_changb_id number(10);
Begin
     if inserting then
           select distinct fh.changbb_id into v_changb_id from fahb fh
           where  fh.zhilb_id=:new.zhilb_id;
          AddInterfaceTask ('zhillsb',:new.id,0,v_changb_id,'xml',:new.id,sysdate);
     elsif deleting then
           select distinct fh.changbb_id into v_changb_id from fahb fh
           where   fh.zhilb_id=:old.zhilb_id;
          AddInterfaceTask ('zhillsb',:old.id,1,v_changb_id,'xml',:old.id,sysdate);
     elsif updating then
           select distinct fh.changbb_id into v_changb_id from fahb fh
           where   fh.zhilb_id=:new.zhilb_id;
          AddInterfaceTask ('zhillsb',:new.id,2,v_changb_id,'xml',:new.id,sysdate);
     end if;
  exception
  when others then
        if inserting then
           zengjrz('trigger_zhilbtmp',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_zhilbtmp',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_zhilbtmp',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;

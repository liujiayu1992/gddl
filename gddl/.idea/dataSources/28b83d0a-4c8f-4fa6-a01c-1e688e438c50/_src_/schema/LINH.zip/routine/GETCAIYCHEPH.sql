create FUNCTION        "GETCAIYCHEPH" (zhilbid number) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_cheph chepb.cheph%TYPE;
   v_count number(1);
   CURSOR C_chepb IS SELECT cheph FROM chepb  where fahb_id in(select id from fahb where zhilb_id=zhilbid);

   BEGIN
       v_count:=0;
       OPEN C_chepb;
       loop
           FETCH C_chepb INTO v_cheph;
                 v_count:=v_count+1;
                 if C_chepb%FOUND then
                    Result:=Result||v_cheph||',';
                 end if;
                 --每3个车号加一个换行符
                 if v_count=3 then
                    Result:=Result||'<br>';
                    v_count:=0;
                 end if;
                 EXIT WHEN C_chepb%NOTFOUND;
           end loop;

           if Length(Result)>3 then
              --如果正好是3的倍数，去掉最后一个<br>
              if substr(Result,-4)='<br>' then
                 Result:=substr(Result,0,Length(Result)-4);
              end if;
           end if;

           CLOSE C_chepb;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end GetCaiyCheph;

 
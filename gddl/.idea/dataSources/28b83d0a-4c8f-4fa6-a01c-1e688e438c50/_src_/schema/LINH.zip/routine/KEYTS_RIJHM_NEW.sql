create FUNCTION        "KEYTS_RIJHM_NEW" (lngDiancxxb_id in number,dangrhm in number,datRiq date,jib in number) return number is
  Result number(10,2);
begin
--增加函数 得到日均耗煤量
--中电投日均耗煤量，其它集团或电厂实施时，根据实际情况调整
    if nvl(dangrhm,0)>0 then
       return dangrhm;
    end if;
    --如果当日的耗煤为0，取最近10天有耗煤的平均值
    if jib=1 then
       select avg(haoyqkdr) into Result from
          (select s.riq, sum(s.haoyqkdr) as haoyqkdr from shouhcrbb s,vwdianc d where s.diancxxb_id=d.id and s.haoyqkdr>0
                 and d.rlgsid=lngDiancxxb_id
                 and s.riq>datRiq-60 --加入60天内的时间提高效率
                 group by s.riq
                 order by riq desc)
          where rownum<11;
        return Result;
    elsif jib=2 then
       select avg(haoyqkdr) into Result from
          (select s.riq, sum(s.haoyqkdr) as haoyqkdr from shouhcrbb s,vwdianc d where s.diancxxb_id=d.id and s.haoyqkdr>0
                 and (d.fgsid=lngDiancxxb_id or d.shangjgsid=lngDiancxxb_id)
                 and s.riq>datRiq-60 --加入60天内的时间提高效率
                 group by s.riq
                 order by riq desc)
          where rownum<11;
      return Result;
    elsif jib=3 then
      select avg(haoyqkdr) into Result from
          (select s.riq, sum(s.haoyqkdr) as haoyqkdr from shouhcrbb s,vwdianc d where s.diancxxb_id=d.id and s.haoyqkdr>0
                 and diancxxb_id=lngDiancxxb_id
                 and s.riq>datRiq-60 --加入60天内的时间提高效率
                 group by s.riq
                 order by riq desc)
          where rownum<11;
      return Result;
    end if;
end keyts_rijhm_new;

 
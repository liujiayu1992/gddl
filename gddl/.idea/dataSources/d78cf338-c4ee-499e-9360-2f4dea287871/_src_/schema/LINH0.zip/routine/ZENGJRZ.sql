create procedure zengjrz(v_mingc in varchar2,v_yicid in number,v_caozlx in varchar2,v_cuowdm  in varchar2,v_cuowxx  in varchar2) is
begin
      declare
      begin
          insert into chufqrz(mingc,yicid,shengcsj,caozlx,cuowdm,cuowxx)values(
           v_mingc,v_yicid,sysdate,v_caozlx,v_cuowdm,v_cuowxx
          );
      end;
end zengjrz;
create FUNCTION getJieszbsjb(v_jiesbh in varchar2,v_kuangfjs in number,cans in number)
	Return  number as
	begin
	     declare--cans
       v_farl  number;--0
	     v_liuf  number;--1
       v_shul  number;--2
       v_shuif  number;--3
       v_huif  number;--4ad
       v_huiff  number;--5vdaf
       numresult number;
	     begin
        if cans=0 then
              Select round_new(Sum(round_new(z.Farl,2)*(c.b +c.y-c.K))/Sum(c.b +c.y-c.K)*1000/4.1816 ,0) into v_farl
              From(Select fahb_id,jiesb_id,
              round_new(sum(c.Biaoz),0) As b,
              round_new(sum(c.yingd),0) As y,
              round_new(sum(c.kuid),0) As k
              From chepb c
              Group By c.Fahb_Id,c.jiesb_id) c,fahb f,zhilb z,jiesb js
              Where c.Fahb_Id = f.Id
              And f.Zhilb_Id = z.Id
              and js.id=c.jiesb_id
              and  js.jiesbh=v_jiesbh and js.kuangfjs=decode(v_kuangfjs,2,1,0);
              numresult:=v_farl;
        elsif  cans=1 then
              Select  round_new(Sum(round_new(z.ganzjl,2)*(c.b +c.y-c.K))/Sum(c.b +c.y-c.K),2) into v_liuf
              From
                (Select fahb_id,jiesb_id,
                round_new(sum(c.Biaoz),0) As b,
                round_new(sum(c.yingd),0) As y,
                round_new(sum(c.kuid),0) As k
                From chepb c
                Group By c.Fahb_Id,c.jiesb_id) c,fahb f,zhilb z,jiesb js
                Where c.Fahb_Id = f.Id
                And f.Zhilb_Id = z.Id
                and js.id=c.jiesb_id
                and   js.jiesbh=v_jiesbh and js.kuangfjs=decode(v_kuangfjs,2,1,0);
                 numresult:=v_liuf;
        elsif  cans=2 then
                select sum(shisl.biaoz)+sum(shisl.yingd)-sum(shisl.kuid)shisl into v_shul
                from(
                select chepb.jiesb_id, fahb.id,round_new(sum(chepb.biaoz),0)biaoz,round_new(sum(chepb.yingd),0)yingd,round_new(sum(chepb.kuid),0)kuid
                from chepb,fahb
                where chepb.fahb_id=fahb.id
                group by fahb.id,chepb.jiesb_id)shisl,jiesb j
                where shisl.jiesb_id=j.id and j.jiesbh=v_jiesbh and j.kuangfjs=decode(v_kuangfjs,2,1,0)
                group by jiesb_id;
                  numresult:=v_shul;
        elsif  cans=3 then
                Select  round_new(Sum(round_new(z.quansf,2)*(c.b +c.y-c.K))/Sum(c.b +c.y-c.K),1) into v_shuif
                From
                (Select fahb_id,jiesb_id,
                round_new(sum(c.Biaoz),0) As b,
                round_new(sum(c.yingd),0) As y,
                round_new(sum(c.kuid),0) As k
                From chepb c
                Group By c.Fahb_Id,c.jiesb_id) c,fahb f,zhilb z,jiesb js
                Where c.Fahb_Id = f.Id
                And f.Zhilb_Id = z.Id
                and js.id=c.jiesb_id
                and   js.jiesbh=v_jiesbh and js.kuangfjs=decode(v_kuangfjs,2,1,0);
                 numresult:=v_shuif;
        elsif  cans=4 then
                Select  round_new(Sum(round_new(z.ganzjhf,2)*(c.b +c.y-c.K))/Sum(c.b +c.y-c.K),2) into v_huif
                From
                (Select fahb_id,jiesb_id,
                round_new(sum(c.Biaoz),0) As b,
                round_new(sum(c.yingd),0) As y,
                round_new(sum(c.kuid),0) As k
                From chepb c
                Group By c.Fahb_Id,c.jiesb_id) c,fahb f,zhilb z,jiesb js
                Where c.Fahb_Id = f.Id
                And f.Zhilb_Id = z.Id
                and js.id=c.jiesb_id
                and   js.jiesbh=v_jiesbh and js.kuangfjs=decode(v_kuangfjs,2,1,0);
                 numresult:=v_huif;
        else
                Select  round_new(Sum(round_new(z.huiff,2)*(c.b +c.y-c.K))/Sum(c.b +c.y-c.K),2) into v_huiff
                From
                (Select fahb_id,jiesb_id,
                round_new(sum(c.Biaoz),0) As b,
                round_new(sum(c.yingd),0) As y,
                round_new(sum(c.kuid),0) As k
                From chepb c
                Group By c.Fahb_Id,c.jiesb_id) c,fahb f,zhilb z,jiesb js
                Where c.Fahb_Id = f.Id
                And f.Zhilb_Id = z.Id
                and js.id=c.jiesb_id
                and   js.jiesbh=v_jiesbh and js.kuangfjs=decode(v_kuangfjs,2,1,0);
                 numresult:=v_huiff;
        end if;
	         return numresult;
	     end;
	end;
create trigger TRIGGER_UD_FAHB
	before update or delete
	on FAHB
	for each row
Declare
  L_action      rizb.caozlx%Type;
  C_user        rizb.caozy%Type;
  C_zid         rizb.zid%Type;
  C_yuanzall    rizb.yuanz%Type;
  C_yuanz rizb.yuanz%Type;
  C_xinz        rizb.xinz%Type;
  b_trigger Boolean := True;
  --I_loopcounter integer := 1;
Begin
  C_zid      := '';
  C_yuanzall := '';
  C_yuanz    := '';
  C_xinz     := '';

  If :new_value.lury Is Not Null Then
    C_User := :new_value.lury;
  Else
    C_User := '未知';
  End If;
  If updating Then
    l_action := '更新';
  Elsif deleting Then
    l_action := '删除';
  Else
    raise_application_error(-99999, '这里也能出错，那我也不知道是什么错了');
  End If;
  If :new_value.YUANID != :old_value.YUANID Then
    C_zid   := C_zid || 'YUANID' || ',';
    C_yuanz := C_yuanz || :old_value.YUANID || ',';
    C_xinz  := C_xinz || :new_value.YUANID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUANID || ',';
  End If;
  If :new_value.DIANCXXB_ID != :old_value.DIANCXXB_ID Then
    C_zid   := C_zid || 'DIANCXXB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.DIANCXXB_ID || ',';
    C_xinz  := C_xinz || :new_value.DIANCXXB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.DIANCXXB_ID || ',';
  End If;
  If :new_value.FAHDWB_ID != :old_value.FAHDWB_ID Then
    C_zid   := C_zid || 'FAHDWB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.FAHDWB_ID || ',';
    C_xinz  := C_xinz || :new_value.FAHDWB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.FAHDWB_ID || ',';
  End If;
  If :new_value.MEIKXXB_ID != :old_value.MEIKXXB_ID Then
    C_zid   := C_zid || 'MEIKXXB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.MEIKXXB_ID || ',';
    C_xinz  := C_xinz || :new_value.MEIKXXB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.MEIKXXB_ID || ',';
  End If;
  If :new_value.MEIJB_ID != :old_value.MEIJB_ID Then
    C_zid   := C_zid || 'MEIJB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.MEIJB_ID || ',';
    C_xinz  := C_xinz || :new_value.MEIJB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.MEIJB_ID || ',';
  End If;
  If :new_value.FAHRQ != :old_value.FAHRQ Then
    C_zid   := C_zid || 'FAHRQ' || ',';
    C_yuanz := C_yuanz || :old_value.FAHRQ || ',';
    C_xinz  := C_xinz || :new_value.FAHRQ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.FAHRQ || ',';
  End If;
  If :new_value.DAOHRQ != :old_value.DAOHRQ Then
    C_zid   := C_zid || 'DAOHRQ' || ',';
    C_yuanz := C_yuanz || :old_value.DAOHRQ || ',';
    C_xinz  := C_xinz || :new_value.DAOHRQ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.DAOHRQ || ',';
  End If;
  If :new_value.CHEC != :old_value.CHEC Then
    C_zid   := C_zid || 'CHEC' || ',';
    C_yuanz := C_yuanz || :old_value.CHEC || ',';
    C_xinz  := C_xinz || :new_value.CHEC || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.CHEC || ',';
  End If;
  If :new_value.FAZ_ID != :old_value.FAZ_ID Then
    C_zid   := C_zid || 'FAZ_ID' || ',';
    C_yuanz := C_yuanz || :old_value.FAZ_ID || ',';
    C_xinz  := C_xinz || :new_value.FAZ_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.FAZ_ID || ',';
  End If;
  If :new_value.DAOZ_ID != :old_value.DAOZ_ID Then
    C_zid   := C_zid || 'DAOZ_ID' || ',';
    C_yuanz := C_yuanz || :old_value.DAOZ_ID || ',';
    C_xinz  := C_xinz || :new_value.DAOZ_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.DAOZ_ID || ',';
  End If;
  If :new_value.YUANSHDW != :old_value.YUANSHDW Then
    C_zid   := C_zid || 'YUANSHDW' || ',';
    C_yuanz := C_yuanz || :old_value.YUANSHDW || ',';
    C_xinz  := C_xinz || :new_value.YUANSHDW || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUANSHDW || ',';
  End If;
  If :new_value.JIHKJB_ID != :old_value.JIHKJB_ID Then
    C_zid   := C_zid || 'JIHKJB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.JIHKJB_ID || ',';
    C_xinz  := C_xinz || :new_value.JIHKJB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.JIHKJB_ID || ',';
  End If;
  If :new_value.BIAOZ != :old_value.BIAOZ Then
    C_zid   := C_zid || 'BIAOZ' || ',';
    C_yuanz := C_yuanz || :old_value.BIAOZ || ',';
    C_xinz  := C_xinz || :new_value.BIAOZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.BIAOZ || ',';
  End If;
  If :new_value.MAOZ != :old_value.MAOZ Then
    C_zid   := C_zid || 'MAOZ' || ',';
    C_yuanz := C_yuanz || :old_value.MAOZ || ',';
    C_xinz  := C_xinz || :new_value.MAOZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.MAOZ || ',';
  End If;
  If :new_value.PIZ != :old_value.PIZ Then
    C_zid   := C_zid || 'PIZ' || ',';
    C_yuanz := C_yuanz || :old_value.PIZ || ',';
    C_xinz  := C_xinz || :new_value.PIZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.PIZ || ',';
  End If;
  If :new_value.YINGD != :old_value.YINGD Then
    C_zid   := C_zid || 'YINGD' || ',';
    C_yuanz := C_yuanz || :old_value.YINGD || ',';
    C_xinz  := C_xinz || :new_value.YINGD || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YINGD || ',';
  End If;
  If :new_value.YUNS != :old_value.YUNS Then
    C_zid   := C_zid || 'YUNS' || ',';
    C_yuanz := C_yuanz || :old_value.YUNS || ',';
    C_xinz  := C_xinz || :new_value.YUNS || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUNS || ',';
  End If;
  If :new_value.KOUD != :old_value.KOUD Then
    C_zid   := C_zid || 'KOUD' || ',';
    C_yuanz := C_yuanz || :old_value.KOUD || ',';
    C_xinz  := C_xinz || :new_value.KOUD || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.KOUD || ',';
  End If;
  If :new_value.CHES != :old_value.CHES Then
    C_zid   := C_zid || 'CHES' || ',';
    C_yuanz := C_yuanz || :old_value.CHES || ',';
    C_xinz  := C_xinz || :new_value.CHES || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.CHES || ',';
  End If;
  If :new_value.LURY != :old_value.LURY Then
    C_zid   := C_zid || 'LURY' || ',';
    C_yuanz := C_yuanz || :old_value.LURY || ',';
    C_xinz  := C_xinz || :new_value.LURY || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.LURY || ',';
  End If;
  If :new_value.TIAOZBZ != :old_value.TIAOZBZ Then
    C_zid   := C_zid || 'TIAOZBZ' || ',';
    C_yuanz := C_yuanz || :old_value.TIAOZBZ || ',';
    C_xinz  := C_xinz || :new_value.TIAOZBZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.TIAOZBZ || ',';
  End If;
  If :new_value.CHANGBB_ID != :old_value.CHANGBB_ID Then
    C_zid   := C_zid || 'CHANGBB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.CHANGBB_ID || ',';
    C_xinz  := C_xinz || :new_value.CHANGBB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.CHANGBB_ID || ',';
  End If;
  If :new_value.RUZRQ != :old_value.RUZRQ Then
    C_zid   := C_zid || 'RUZRQ' || ',';
    C_yuanz := C_yuanz || :old_value.RUZRQ || ',';
    C_xinz  := C_xinz || :new_value.RUZRQ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.RUZRQ || ',';
  End If;
  If :new_value.YANSBH != :old_value.YANSBH Then
    C_zid   := C_zid || 'YANSBH' || ',';
    C_yuanz := C_yuanz || :old_value.YANSBH || ',';
    C_xinz  := C_xinz || :new_value.YANSBH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YANSBH || ',';
  End If;
  If :new_value.ZHILB_ID != :old_value.ZHILB_ID Then
    C_zid   := C_zid || 'ZHILB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.ZHILB_ID || ',';
    C_xinz  := C_xinz || :new_value.ZHILB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.ZHILB_ID || ',';
  End If;
  If :new_value.JIESB_ID != :old_value.JIESB_ID Then
    C_zid   := C_zid || 'JIESB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.JIESB_ID || ',';
    C_xinz  := C_xinz || :new_value.JIESB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.JIESB_ID || ',';
  End If;
  If :new_value.YUNFL_ID != :old_value.YUNFL_ID Then
    C_zid   := C_zid || 'YUNFL_ID' || ',';
    C_yuanz := C_yuanz || :old_value.YUNFL_ID || ',';
    C_xinz  := C_xinz || :new_value.YUNFL_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUNFL_ID || ',';
  End If;
  If :new_value.HUIKL_ID != :old_value.HUIKL_ID Then
    C_zid   := C_zid || 'HUIKL_ID' || ',';
    C_yuanz := C_yuanz || :old_value.HUIKL_ID || ',';
    C_xinz  := C_xinz || :new_value.HUIKL_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.HUIKL_ID || ',';
  End If;
  If :new_value.HUIKF != :old_value.HUIKF Then
    C_zid   := C_zid || 'HUIKF' || ',';
    C_yuanz := C_yuanz || :old_value.HUIKF || ',';
    C_xinz  := C_xinz || :new_value.HUIKF || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.HUIKF || ',';
  End If;
  If :new_value.QUSCF != :old_value.QUSCF Then
    C_zid   := C_zid || 'QUSCF' || ',';
    C_yuanz := C_yuanz || :old_value.QUSCF || ',';
    C_xinz  := C_xinz || :new_value.QUSCF || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.QUSCF || ',';
  End If;
  If :new_value.QITFY != :old_value.QITFY Then
    C_zid   := C_zid || 'QITFY' || ',';
    C_yuanz := C_yuanz || :old_value.QITFY || ',';
    C_xinz  := C_xinz || :new_value.QITFY || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.QITFY || ',';
  End If;
  If :new_value.BEIZ != :old_value.BEIZ Then
    C_zid   := C_zid || 'BEIZ' || ',';
    C_yuanz := C_yuanz || :old_value.BEIZ || ',';
    C_xinz  := C_xinz || :new_value.BEIZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.BEIZ || ',';
  End If;
  If :new_value.YUNSFS != :old_value.YUNSFS Then
    C_zid   := C_zid || 'YUNSFS' || ',';
    C_yuanz := C_yuanz || :old_value.YUNSFS || ',';
    C_xinz  := C_xinz || :new_value.YUNSFS || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUNSFS || ',';
  End If;
  If :new_value.RANLPZB_ID != :old_value.RANLPZB_ID Then
    C_zid   := C_zid || 'RANLPZB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.RANLPZB_ID || ',';
    C_xinz  := C_xinz || :new_value.RANLPZB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.RANLPZB_ID || ',';
  End If;
  If :new_value.KUANGFZLB_ID != :old_value.KUANGFZLB_ID Then
    C_zid   := C_zid || 'KUANGFZLB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.KUANGFZLB_ID || ',';
    C_xinz  := C_xinz || :new_value.KUANGFZLB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.KUANGFZLB_ID || ',';
  End If;
  If :new_value.YUANDZ_ID != :old_value.YUANDZ_ID Then
    C_zid   := C_zid || 'YUANDZ_ID' || ',';
    C_yuanz := C_yuanz || :old_value.YUANDZ_ID || ',';
    C_xinz  := C_xinz || :new_value.YUANDZ_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUANDZ_ID || ',';
  End If;
  If :new_value.YUANSHDWB_ID != :old_value.YUANSHDWB_ID Then
    C_zid   := C_zid || 'YUANSHDWB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.YUANSHDWB_ID || ',';
    C_xinz  := C_xinz || :new_value.YUANSHDWB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUANSHDWB_ID || ',';
  End If;
  If :new_value.KUID != :old_value.KUID Then
    C_zid   := C_zid || 'KUID' || ',';
    C_yuanz := C_yuanz || :old_value.KUID || ',';
    C_xinz  := C_xinz || :new_value.KUID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.KUID || ',';
  End If;
  If :new_value.JIESSLBZ != :old_value.JIESSLBZ Then
    C_zid   := C_zid || 'JIESSLBZ' || ',';
    C_yuanz := C_yuanz || :old_value.JIESSLBZ || ',';
    C_xinz  := C_xinz || :new_value.JIESSLBZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.JIESSLBZ || ',';
  End If;
  If :new_value.JIESZLBZ != :old_value.JIESZLBZ Then
    C_zid   := C_zid || 'JIESZLBZ' || ',';
    C_yuanz := C_yuanz || :old_value.JIESZLBZ || ',';
    C_xinz  := C_xinz || :new_value.JIESZLBZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.JIESZLBZ || ',';
  End If;
  If :new_value.HEDBZ != :old_value.HEDBZ Then
    C_zid   := C_zid || 'HEDBZ' || ',';
    C_yuanz := C_yuanz || :old_value.HEDBZ || ',';
    C_xinz  := C_xinz || :new_value.HEDBZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.HEDBZ || ',';
  End If;
  If C_zid Is Not Null Then
    C_zid := substr(C_zid, 0, length(C_zid) - 1);
  Else
    C_zid := getcolname('fahb');
  End If;
  If C_yuanz Is Not Null Then
    C_yuanz := substr(C_yuanz, 0, length(C_yuanz) - 1);
  Else
    C_yuanz := C_yuanzall;
  End If;
  If C_xinz Is Not Null Then
    C_xinz := substr(C_xinz, 0, length(C_xinz) - 1);
  End If;

  If C_zid Is Null Then
    C_zid := 'Unknown,';
  End If;

  if C_xinz is null  and l_action = '更新' then
     b_trigger := false;
  end if ;
  if C_zid = 'HEDBZ' then
     b_trigger := false;
  end if ;

  if  b_trigger then
  Insert Into rizb
    (Id,
     mokmc,
     biaomc,
     biaoid,
     zid,
     yuanz,
     xinz,
     caozy,
     caozsj,
     caozlx,
     diz)
  Values
    (xl_rizb_id.Nextval,
     '数量信息',
     'fahb',
     :old_value.Id,
     C_zid,
     C_yuanz,
     C_xinz,
     C_User,
     Sysdate,
     l_action,
     '暂无');
     end if;
  exception
 when others then
        if inserting then
           zengjrz('trigger_ud_fahb',:new_value.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_ud_fahb',:old_value.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_ud_fahb',:old_value.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
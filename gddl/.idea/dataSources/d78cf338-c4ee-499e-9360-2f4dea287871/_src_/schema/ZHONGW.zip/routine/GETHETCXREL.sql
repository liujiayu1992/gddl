create FUNCTION gethetcxRel(v_hetb_id number)--caolin合同查询用
Return  number as
begin
     declare
     rel number;
     begin
          select max(decode(danwb.bianm,'MJ/Kg',round(xiax/0.0041816,0),xiax))shangx
            into rel
            from hetjgb,zhibb,danwb
            where hetb_id=v_hetb_id and hetjgb.zhibb_id=zhibb.id  and hetjgb.danwb_id=danwb.id;
            return rel;
     end;
end;


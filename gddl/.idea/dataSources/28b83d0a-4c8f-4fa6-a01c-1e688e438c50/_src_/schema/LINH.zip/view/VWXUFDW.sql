create view VWXUFDW as
select id,
               mingc,
               quanc,
               diz,
               youzbm,
               shuih,
               faddbr,
               weitdlr,
               kaihyh,
               zhangh,
               dianh
          from diancxxb
        union
        select id,
               mingc,
               quanc,
               diz,
               youzbm,
               shuih,
               faddbr,
               weitdlr,
               kaihyh,
               zhangh,
               lianxdh as dianh
          from xufdwb

 

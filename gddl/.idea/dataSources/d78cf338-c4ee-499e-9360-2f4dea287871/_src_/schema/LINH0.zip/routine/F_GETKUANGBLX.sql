create Function F_GETKUANGBLX(meikdqid In Number,JIHKJ In Varchar2)
--计算成本估价汇总表使用
       Return Number Is kuangblx Number(1,0);
Begin
    If JIHKJ<>'市场采购' Then
       kuangblx := 2;
       Return(kuangblx);
    Else
        Begin
	        Select Id Into kuangblx From meikdqb Where Id = meikdqid;
	           kuangblx := 2;--此id为煤矿地区id时，强制要求类型＝2
	           Return(kuangblx);
	      exception
	        when no_data_found then
	          kuangblx := 0;
	          Return(kuangblx);
	        when others then
	          kuangblx := -1;
	          Return(kuangblx);
          End;
    End If;
End F_GETKUANGBLX;

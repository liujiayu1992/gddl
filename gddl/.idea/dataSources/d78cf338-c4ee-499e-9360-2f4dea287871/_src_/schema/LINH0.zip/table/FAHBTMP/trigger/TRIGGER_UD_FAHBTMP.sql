create trigger TRIGGER_UD_FAHBTMP
	before update or delete
	on FAHBTMP
	for each row
Declare
  L_action      rizb.caozlx%Type;
  C_user        rizb.caozy%Type;
  C_zid         rizb.zid%Type;
  C_yuanzall    rizb.yuanz%Type;
  C_yuanz rizb.yuanz%Type;
  C_xinz        rizb.xinz%Type;
   b_trigger Boolean := True;
  --I_loopcounter integer := 1;
Begin
  C_zid      := '';
  C_yuanzall := '';
  C_yuanz    := '';
  C_xinz     := '';

  If :new_value.lury Is Not Null Then
    C_User := :new_value.lury;
  Else
    C_User := '未知';
  End If;
  If updating Then
    l_action := '更新';
  Elsif deleting Then
    l_action := '删除';
  Else
    raise_application_error(-99999, '这里也能出错，那我也不知道是什么错了');
  End If;
  If :new_value.PIZ != :old_value.PIZ Then
    C_zid   := C_zid || 'PIZ' || ',';
    C_yuanz := C_yuanz || :old_value.PIZ || ',';
    C_xinz  := C_xinz || :new_value.PIZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.PIZ || ',';
  End If;
  If :new_value.BIAOZ != :old_value.BIAOZ Then
    C_zid   := C_zid || 'BIAOZ' || ',';
    C_yuanz := C_yuanz || :old_value.BIAOZ || ',';
    C_xinz  := C_xinz || :new_value.BIAOZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.BIAOZ || ',';
  End If;
  If :new_value.CHEC != :old_value.CHEC Then
    C_zid   := C_zid || 'CHEC' || ',';
    C_yuanz := C_yuanz || :old_value.CHEC || ',';
    C_xinz  := C_xinz || :new_value.CHEC || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.CHEC || ',';
  End If;
  If :new_value.BEIZ != :old_value.BEIZ Then
    C_zid   := C_zid || 'BEIZ' || ',';
    C_yuanz := C_yuanz || :old_value.BEIZ || ',';
    C_xinz  := C_xinz || :new_value.BEIZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.BEIZ || ',';
  End If;
  If :new_value.DIANCXXB_ID != :old_value.DIANCXXB_ID Then
    C_zid   := C_zid || 'id' || ',';
    C_yuanz := C_yuanz || :old_value.DIANCXXB_ID || ',';
    C_xinz  := C_xinz || :new_value.DIANCXXB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.DIANCXXB_ID || ',';
  End If;
  If :new_value.FAHDWB_ID != :old_value.FAHDWB_ID Then
    C_zid   := C_zid || 'FAHDWB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.FAHDWB_ID || ',';
    C_xinz  := C_xinz || :new_value.FAHDWB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.FAHDWB_ID || ',';
  End If;
  If :new_value.MEIKXXB_ID != :old_value.MEIKXXB_ID Then
    C_zid   := C_zid || 'MEIKXXB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.MEIKXXB_ID || ',';
    C_xinz  := C_xinz || :new_value.MEIKXXB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.MEIKXXB_ID || ',';
  End If;
  If :new_value.RANLPZB_ID != :old_value.RANLPZB_ID Then
    C_zid   := C_zid || 'RANLPZB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.RANLPZB_ID || ',';
    C_xinz  := C_xinz || :new_value.RANLPZB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.RANLPZB_ID || ',';
  End If;
  If :new_value.FAZ_ID != :old_value.FAZ_ID Then
    C_zid   := C_zid || 'FAZ_ID' || ',';
    C_yuanz := C_yuanz || :old_value.FAZ_ID || ',';
    C_xinz  := C_xinz || :new_value.FAZ_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.FAZ_ID || ',';
  End If;
  If :new_value.DAOZ_ID != :old_value.DAOZ_ID Then
    C_zid   := C_zid || 'DAOZ_ID' || ',';
    C_yuanz := C_yuanz || :old_value.DAOZ_ID || ',';
    C_xinz  := C_xinz || :new_value.DAOZ_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.DAOZ_ID || ',';
  End If;
  If :new_value.YUANDZ_ID != :old_value.YUANDZ_ID Then
    C_zid   := C_zid || 'YUANDZ_ID' || ',';
    C_yuanz := C_yuanz || :old_value.YUANDZ_ID || ',';
    C_xinz  := C_xinz || :new_value.YUANDZ_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUANDZ_ID || ',';
  End If;
  If :new_value.YUANSHDWB_ID != :old_value.YUANSHDWB_ID Then
    C_zid   := C_zid || 'YUANSHDWB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.YUANSHDWB_ID || ',';
    C_xinz  := C_xinz || :new_value.YUANSHDWB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUANSHDWB_ID || ',';
  End If;
  If :new_value.JIHKJB_ID != :old_value.JIHKJB_ID Then
    C_zid   := C_zid || 'JIHKJB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.JIHKJB_ID || ',';
    C_xinz  := C_xinz || :new_value.JIHKJB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.JIHKJB_ID || ',';
  End If;
  If :new_value.CHANGBB_ID != :old_value.CHANGBB_ID Then
    C_zid   := C_zid || 'CHANGBB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.CHANGBB_ID || ',';
    C_xinz  := C_xinz || :new_value.CHANGBB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.CHANGBB_ID || ',';
  End If;
  If :new_value.MEICB_ID != :old_value.MEICB_ID Then
    C_zid   := C_zid || 'MEICB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.MEICB_ID || ',';
    C_xinz  := C_xinz || :new_value.MEICB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.MEICB_ID || ',';
  End If;
  If :new_value.ZHILB_ID != :old_value.ZHILB_ID Then
    C_zid   := C_zid || 'ZHILB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.ZHILB_ID || ',';
    C_xinz  := C_xinz || :new_value.ZHILB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.ZHILB_ID || ',';
  End If;
  If :new_value.FAHRQ != :old_value.FAHRQ Then
    C_zid   := C_zid || 'FAHRQ' || ',';
    C_yuanz := C_yuanz || :old_value.FAHRQ || ',';
    C_xinz  := C_xinz || :new_value.FAHRQ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.FAHRQ || ',';
  End If;
  If :new_value.DAOHRQ != :old_value.DAOHRQ Then
    C_zid   := C_zid || 'DAOHRQ' || ',';
    C_yuanz := C_yuanz || :old_value.DAOHRQ || ',';
    C_xinz  := C_xinz || :new_value.DAOHRQ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.DAOHRQ || ',';
  End If;
  If :new_value.CHEPH != :old_value.CHEPH Then
    C_zid   := C_zid || 'CHEPH' || ',';
    C_yuanz := C_yuanz || :old_value.CHEPH || ',';
    C_xinz  := C_xinz || :new_value.CHEPH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.CHEPH || ',';
  End If;
  If :new_value.DAOZCH != :old_value.DAOZCH Then
    C_zid   := C_zid || 'DAOZCH' || ',';
    C_yuanz := C_yuanz || :old_value.DAOZCH || ',';
    C_xinz  := C_xinz || :new_value.DAOZCH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.DAOZCH || ',';
  End If;
  If :new_value.PIAOJH != :old_value.PIAOJH Then
    C_zid   := C_zid || 'PIAOJH' || ',';
    C_yuanz := C_yuanz || :old_value.PIAOJH || ',';
    C_xinz  := C_xinz || :new_value.PIAOJH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.PIAOJH || ',';
  End If;
  If :new_value.CHEB != :old_value.CHEB Then
    C_zid   := C_zid || 'CHEB' || ',';
    C_yuanz := C_yuanz || :old_value.CHEB || ',';
    C_xinz  := C_xinz || :new_value.CHEB || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.CHEB || ',';
  End If;
  If :new_value.HEDBZ != :old_value.HEDBZ Then
    C_zid   := C_zid || 'HEDBZ' || ',';
    C_yuanz := C_yuanz || :old_value.HEDBZ || ',';
    C_xinz  := C_xinz || :new_value.HEDBZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.HEDBZ || ',';
  End If;
  If :new_value.YUANMKDW != :old_value.YUANMKDW Then
    C_zid   := C_zid || 'YUANMKDW' || ',';
    C_yuanz := C_yuanz || :old_value.YUANMKDW || ',';
    C_xinz  := C_xinz || :new_value.YUANMKDW || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUANMKDW || ',';
  End If;
  If :new_value.YUNSDW != :old_value.YUNSDW Then
    C_zid   := C_zid || 'YUNSDW' || ',';
    C_yuanz := C_yuanz || :old_value.YUNSDW || ',';
    C_xinz  := C_xinz || :new_value.YUNSDW || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUNSDW || ',';
  End If;
  If :new_value.LURY != :old_value.LURY Then
    C_zid   := C_zid || 'LURY' || ',';
    C_yuanz := C_yuanz || :old_value.LURY || ',';
    C_xinz  := C_xinz || :new_value.LURY || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.LURY || ',';
  End If;
  If :new_value.YUANFHID != :old_value.YUANFHID Then
    C_zid   := C_zid || 'YUANFHID' || ',';
    C_yuanz := C_yuanz || :old_value.YUANFHID || ',';
    C_xinz  := C_xinz || :new_value.YUANFHID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUANFHID || ',';
  End If;
  If :new_value.MAOZ != :old_value.MAOZ Then
    C_zid   := C_zid || 'MAOZ' || ',';
    C_yuanz := C_yuanz || :old_value.MAOZ || ',';
    C_xinz  := C_xinz || :new_value.MAOZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.MAOZ || ',';
  End If;
  If :new_value.YINGD != :old_value.YINGD Then
    C_zid   := C_zid || 'YINGD' || ',';
    C_yuanz := C_yuanz || :old_value.YINGD || ',';
    C_xinz  := C_xinz || :new_value.YINGD || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YINGD || ',';
  End If;
  If :new_value.KUID != :old_value.KUID Then
    C_zid   := C_zid || 'KUID' || ',';
    C_yuanz := C_yuanz || :old_value.KUID || ',';
    C_xinz  := C_xinz || :new_value.KUID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.KUID || ',';
  End If;
  If :new_value.YUNS != :old_value.YUNS Then
    C_zid   := C_zid || 'YUNS' || ',';
    C_yuanz := C_yuanz || :old_value.YUNS || ',';
    C_xinz  := C_xinz || :new_value.YUNS || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUNS || ',';
  End If;
  If :new_value.YUNSL != :old_value.YUNSL Then
    C_zid   := C_zid || 'YUNSL' || ',';
    C_yuanz := C_yuanz || :old_value.YUNSL || ',';
    C_xinz  := C_xinz || :new_value.YUNSL || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUNSL || ',';
  End If;
  If :new_value.SUD != :old_value.SUD Then
    C_zid   := C_zid || 'SUD' || ',';
    C_yuanz := C_yuanz || :old_value.SUD || ',';
    C_xinz  := C_xinz || :new_value.SUD || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.SUD || ',';
  End If;
  If :new_value.GUOHSJ != :old_value.GUOHSJ Then
    C_zid   := C_zid || 'GUOHSJ' || ',';
    C_yuanz := C_yuanz || :old_value.GUOHSJ || ',';
    C_xinz  := C_xinz || :new_value.GUOHSJ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.GUOHSJ || ',';
  End If;
  If :new_value.JIEXDH != :old_value.JIEXDH Then
    C_zid   := C_zid || 'JIEXDH' || ',';
    C_yuanz := C_yuanz || :old_value.JIEXDH || ',';
    C_xinz  := C_xinz || :new_value.JIEXDH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.JIEXDH || ',';
  End If;
  If :new_value.JILHH != :old_value.JILHH Then
    C_zid   := C_zid || 'JILHH' || ',';
    C_yuanz := C_yuanz || :old_value.JILHH || ',';
    C_xinz  := C_xinz || :new_value.JILHH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.JILHH || ',';
  End If;
  If :new_value.CHES != :old_value.CHES Then
    C_zid   := C_zid || 'CHES' || ',';
    C_yuanz := C_yuanz || :old_value.CHES || ',';
    C_xinz  := C_xinz || :new_value.CHES || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.CHES || ',';
  End If;
  If C_zid Is Not Null Then
    C_zid := substr(C_zid, 0, length(C_zid) - 1);
  Else
    C_zid := getcolname('fahbtmp');
  End If;
  If C_yuanz Is Not Null Then
    C_yuanz := substr(C_yuanz, 0, length(C_yuanz) - 1);
  Else
    C_yuanz := C_yuanzall;
  End If;
  If C_xinz Is Not Null Then
    C_xinz := substr(C_xinz, 0, length(C_xinz) - 1);
  End If;

  if C_xinz is null  and l_action = '更新' then
     b_trigger := false;
  end if ;
  if C_zid = 'HEDBZ' then
     b_trigger := false;
  end if ;

  if C_zid = 'ZHILB_ID,HEDBZ' and l_action = '更新' then
     b_trigger := false;
  end if ;
  if C_zid = 'PIZ,HEDBZ' and l_action = '更新' then
     b_trigger := false;
  end if ;

  if b_trigger then
  Insert Into rizb
    (Id,
     mokmc,
     biaomc,
     biaoid,
     zid,
     yuanz,
     xinz,
     caozy,
     caozsj,
     caozlx,
     diz)
  Values
    (xl_rizb_id.Nextval,
     '数量信息',
     'fahbtmp',
     :old_value.Id,
     C_zid,
     C_yuanz,
     C_xinz,
     C_User,
     Sysdate,
     l_action,
     '暂无');
     end if ;
End;

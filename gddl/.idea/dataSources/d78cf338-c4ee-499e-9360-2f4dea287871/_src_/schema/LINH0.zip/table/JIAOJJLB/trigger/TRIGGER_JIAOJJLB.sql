create trigger TRIGGER_JIAOJJLB
	before insert or update or delete
	on JIAOJJLB
	for each row
Declare
  v_id          fahb.changbb_id%Type;
Begin
     if inserting then
          select id  into v_id
          from quzpkqkb
          where quzpkqkb.riq=:new.riq and quzpkqkb.changbb_id=:new.changbb_id;
          AddInterfaceTask ('quzpkb',v_id,2,:new.changbb_id,'xml',:new.id,:new.riq);
     elsif deleting then
          select id  into v_id
          from quzpkqkb
          where quzpkqkb.riq=:old.riq  and quzpkqkb.changbb_id=:old.changbb_id;
          AddInterfaceTask ('quzpkb',v_id,2,:old.changbb_id,'xml',:old.id,:old.riq);
     elsif updating then
           if :new.changczc<>:old.changczc or
             :new.CHANGCKC<>:old.CHANGCKC or
             :new.DANGRPK<>:old.DANGRPK or
             :new.JIAOJZC<>:old.JIAOJZC or
             :new.DAOZC <>:old.DAOZC
           then
               select id  into v_id
               from quzpkqkb
               where quzpkqkb.riq=:old.riq  and quzpkqkb.changbb_id=:old.changbb_id;
               AddInterfaceTask ('quzpkb',v_id,2,:new.changbb_id,'xml',:new.id,:new.riq);

           end if ;
     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_jiaojjlb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_jiaojjlb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_jiaojjlb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
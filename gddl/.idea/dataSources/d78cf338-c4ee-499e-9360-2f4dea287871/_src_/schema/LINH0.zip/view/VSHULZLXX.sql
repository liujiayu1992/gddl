create view VSHULZLXX as
select fahb.ID as fahb_Id,diancxxb.quanc as diancxxb_quanc,diancxxb.SUOSS as diancxxb_Suoss,diancxxb.SUOSGS as diancxxb_Suosgs,meikdqb.meikdqmc as meikdqb_meikdqmc,meikxxb.MEIKDWMC as meikxxb_Meikdwmc,meikxxb.SUOSS as meikSuoss,ranlpzb.PINZ as ranlpzb_Pinz,jihkjb.MINGC as jihkjb_Mingc,
Diancxxb.XUH as Diancxxb_Xuh ,meikdqb.XUH as meikdqb_Xuh , meikxxb.XUH as meikxxb_Xuh ,ranlpzb.XUH as ranlpzb_Xuh ,jihkjb.XUH as jihkjb_Xuh ,
fahb.DIANCXXB_ID as Diancxxb_id,meikdqb.id as meikdqb_id,fahb.MEIKXXB_ID as Meikxxb_id,ranlpzb.id as ranlpzb_id,jihkjb.id as jihkjb_id,zhilb.id as zhilb_id,
fahb.FAHDWB_ID as Fahdwb_id,fahb.MEIJB_ID as Meijb_id,jiesb.id as jiesb_id,
fahb.FAHRQ as fahb_Fahrq,fahb.DAOHRQ as fahb_Daohrq,
zhilb.CAIYSJ as zhilb_Caiysj,zhilb.HUAYSJ as zhilb_Huaysj,
fahb.LURY as fahb_Lury,
zhilb.BIANH as zhilb_Bianh,zhilb.LURY1 as zhilb_caiylrry,zhilb.CAIYRY as zhilb_Caiyry,zhilb.CAIYFS as zhilb_Caiyfs,
zhilb.LURY2 as zhilb_huaylrry,zhilb.HUAYY as zhilb_Huayy,zhilb.SHENHZT as zhilb_Shenhzt,
zhilb.SHENHRY as zhilb_Shenhry,
jiesb.JIESRQ as jiesb_Jiesrq,
fahb.CHEC as fahb_Chec,fahb.FAZ_ID as Faz_id,
fahb.DAOZ_ID as Daoz_id,

fahb.YUANSHDW as fahb_Yuanshdw,fahb.BIAOZ as fahb_Biaoz,fahb.MAOZ as fahb_Maoz,fahb.PIZ as fahb_Piz,
fahb.YINGd as fahb_Yingk,fahb.YUNS as fahb_Yuns,fahb.KOUD as fahb_Koud,fahb.CHES as fahb_Ches,
fahb.TIAOZBZ as fahb_Tiaozbz,fahb.CHANGBb_id as fahb_Changb,fahb.RUZRQ as fahb_Ruzrq,
fahb.YANSBH as fahb_Yansbh,fahb.QUSCF as fahb_Quscf,fahb.QITFY as fahb_Qitfy,
fahb.YUNSFS as fahb_Yunsfs,
zhilb.BEIZ1 as zhilb_caiybz,zhilb.FARL as zhilb_Farl,
zhilb.SHOUDJHF as zhilb_Shoudjhf,zhilb.GANZJHF as zhilb_Ganzjhf,zhilb.HUIFF as zhilb_Huiff,
zhilb.QUANSF as zhilb_Quansf,zhilb.LIUF as zhilb_Liuf,zhilb.KONGQGZJHF as zhilb_Kongqgzjhf,
zhilb.KONGQGZJSF as zhilb_Kongqgzjsf,zhilb.DANTRL as zhilb_Dantrl,zhilb.KONGQGZJQ as zhilb_Kongqgzjq,
zhilb.KONGQGZJHFF as zhilb_Kongqgzjhff,zhilb.KONGGJT as zhilb_Konggjt,zhilb.GANZJL as zhilb_Ganzjl,
zhilb.HUIRD as zhilb_Huird,zhilb.GANZJGWRZ as zhilb_Ganzjgwrz,
zhilb.BEIZ2 as zhilb_huaybz,zhilb.ZIBZT as zhilb_Zibzt,zhilb.ZHONGZGZT as zhilb_Zhongzgzt,
jiesb.BUHSDJ as jiesb_Buhsdj,meijb.JIAG as meijb_Jiag,meijb.YUNJ as meijb_Yunj,meijb.YINGDJ as meijb_Yingdj,meijb.KUIDJ as meijb_Kuidj,meijb.REZSX as meijb_Rezsx,meijb.REZXX as meijb_Rezxx,meijb.ZENGFRJ as meijb_Zengfrj,meijb.KOUFRJ as meijb_Koufrj,meijb.LIUSX as meijb_Liusx,meijb.LIUXX as meijb_Liuxx,meijb.ZENGFLJ as meijb_Zengflj,meijb.KOUFLJ as meijb_Kouflj,meijb.HUIRDSX as meijb_Huirdsx,meijb.HUIRDXX as meijb_Huirdxx,meijb.ZENGFHJ as meijb_Zengfhj,meijb.KOUFHJ as meijb_Koufhj,meijb.RIQ as meijb_Riq,meijb.HETH as meijb_Heth,meijb.QITJ as meijb_Qitj
from fahb,diancxxb,meikxxb,meikdqb,meijb,jihkjb,zhilb,ranlpzb,jiesb
where fahb.diancxxb_id=diancxxb.id(+) and fahb.meikxxb_id=meikxxb.id(+) and fahb.jiesb_id= jiesb.id(+)
and meikxxb.meikdqb_id=meikdqb.id(+) and fahb.meijb_id=meijb.id(+) and fahb.jihkjb_id=jihkjb.id(+)
and fahb.zhilb_id=zhilb.id(+) and fahb.ranlpzb_id=ranlpzb.id WITH READ ONLY


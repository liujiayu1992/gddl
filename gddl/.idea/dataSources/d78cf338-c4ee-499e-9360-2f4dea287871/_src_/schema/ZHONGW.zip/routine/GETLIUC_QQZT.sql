create function GetLiuc_Qqzt(Liucdz_Hjid in number) return varchar2 is
       Result varchar2(2000);
       --得到某一个流程动作的前驱id
begin
       DECLARE
        v_mingc leibztb.mingc%TYPE;
        begin
          select mingc into v_mingc from leibztb where id in
                  (select leibztb_id from liucztb where id in
                     (select liucztqqid from liucdzb
                             where liucdzb.liuczthjid=Liucdz_Hjid and mingc='提交'))
                             and rownum=1;

                  if not (v_mingc is null) then

                     Result:=v_mingc;

                  else
                     Result:='';

                  end if;
                  
                  return Result;
         end;
        
end;
                


create view SCYB1 as
select z.riq,y.laiyl,p.zhangmcm,p.shijcm,p.yuns from
(select to_date(to_char(riq, 'yyyy-mm'), 'yyyy-mm') as riq
  from laiyqkb
 group by to_char(riq, 'yyyy-mm')
union
select to_date(to_char(riq, 'yyyy-mm'), 'yyyy-mm') as riq from pandtjb_jt) z,
(select sum(shourl) laiyl,
                  to_date(to_char(riq, 'yyyy-mm'), 'yyyy-mm') as riq
             from laiyqkb
            group by to_char(riq, 'yyyy-mm')) y,
(select p.pandcm as shijcm,
        p.zhangmcm,
       p.yuns,
       to_date(to_char(p.riq, 'yyyy-mm'), 'yyyy-mm') as riq
  from pandtjb_jt p) p
  where z.riq = p.riq(+)
  and z.riq = y.riq(+)


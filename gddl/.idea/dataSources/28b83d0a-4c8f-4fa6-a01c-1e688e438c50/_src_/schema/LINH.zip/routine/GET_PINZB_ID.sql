create FUNCTION        "GET_PINZB_ID" (strPinzName In varchar2)
Return  number as
begin
     declare
     pizbid number;
     begin
     select max(id) into pizbid from pinzb p where p.mingc=strPinzName;
     return pizbid;
     end;
End;

 
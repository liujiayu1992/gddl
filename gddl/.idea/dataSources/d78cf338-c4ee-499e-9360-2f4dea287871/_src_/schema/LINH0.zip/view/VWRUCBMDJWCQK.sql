create view VWRUCBMDJWCQK as
select nianf,yuef,changbb_id,'本月' as xiangm,rucbmdj, nvl(trucbmdj,0) as yus, rucbmdj-nvl(trucbmdj,0) as chaz
	,round_new(decode(trucmrz,0,0,(rucymdj-nvl(trucymdj,0))*29.271/trucmrz),2) as chebjyx
	,round_new(decode(trucmrz,0,0,(hej-nvl(thej,0))*29.271/trucmrz),2) as yunzfyx
	,case when rucmrz=0 or trucmrz=0 then 0 else
	round_new((rucymdj+hej)*(29.271/rucmrz - 29.271/trucmrz),2) end as farlyx
	from (select y.nianf,y.yuef,y.changbb_id,shisl,rucmrz,rucymdj,rucbmdj,
	nvl((select hej from yunzfwcqk where nianf = y.nianf and yuef = y.yuef
	and changbb_id = y.changbb_id),0) hej,
	nvl((select rucmrz from yuedfxsj where nianf+1=y.nianf and yuef =y.yuef
	and changbb_id = y.changbb_id),0) trucmrz,
	nvl((select rucymdj from yuedfxsj where nianf+1=y.nianf and yuef =y.yuef
	and changbb_id = y.changbb_id),0) trucymdj,
	nvl((select rucbmdj from yuedfxsj where nianf+1=y.nianf and yuef =y.yuef
	and changbb_id = y.changbb_id),0) trucbmdj,
	nvl((select hej from yunzfwcqk where nianf+1 = y.nianf and yuef = y.yuef
  and changbb_id = y.changbb_id),0) thej from yuedfxsj y) union
  select nianf,yuef,changbb_id,'累计' as xiangm,rucbmdj, nvl(trucbmdj,0) as yus,
  rucbmdj-nvl(trucbmdj,0) as chaz
  ,round_new(decode(trucmrz,0,0,(rucymdj-nvl(trucymdj,0))*29.271/trucmrz),2) as chebjyx
  ,round_new(decode(trucmrz,0,0,(hej-nvl(thej,0))*29.271/trucmrz),2) as yunzfyx
  ,case when rucmrz=0 or trucmrz=0 then 0 else
  round_new((rucymdj+hej)*(29.271/rucmrz - 29.271/trucmrz),2) end as farlyx
  from (select y.nianf,y.yuef,y.changbb_id,
  nvl((select sum(shisl) from yunzfwcqk where nianf = y.nianf and yuef <= y.yuef
  and changbb_id = y.changbb_id),0) shisl,
  nvl((select decode(sum(shisl),0,0,sum(rucmrz*shisl)/sum(shisl))
    from yunzfwcqk where nianf = y.nianf and yuef <= y.yuef
  and changbb_id = y.changbb_id),0) rucmrz,
  nvl((select decode(sum(shisl),0,0,sum(rucymdj*shisl)/sum(shisl))
    from yunzfwcqk where nianf = y.nianf and yuef <= y.yuef
  and changbb_id = y.changbb_id),0) rucymdj,
  nvl((select decode(sum(shisl),0,0,sum(rucbmdj*shisl)/sum(shisl))
    from yunzfwcqk where nianf = y.nianf and yuef <= y.yuef
  and changbb_id = y.changbb_id),0) rucbmdj,
  nvl((select decode(sum(shisl),0,0,sum(hej*shisl)/sum(shisl))
    from yunzfwcqk where nianf = y.nianf and yuef <= y.yuef
  and changbb_id = y.changbb_id),0) hej,
  nvl((select decode(sum(shisl),0,0,sum(rucmrz*shisl)/sum(shisl))
    from yuedfxsj where nianf+1=y.nianf and yuef <=y.yuef
  and changbb_id = y.changbb_id),0) trucmrz,
  nvl((select decode(sum(shisl),0,0,sum(rucymdj*shisl)/sum(shisl))
    from yuedfxsj where nianf+1=y.nianf and yuef <=y.yuef
  and changbb_id = y.changbb_id),0) trucymdj,
  nvl((select decode(sum(shisl),0,0,sum(rucbmdj*shisl)/sum(shisl))
    from yuedfxsj where nianf+1=y.nianf and yuef <= y.yuef
  and changbb_id = y.changbb_id),0) trucbmdj,
  nvl((select decode(sum(shisl),0,0,sum(hej*shisl)/sum(shisl))
    from yunzfwcqk where nianf+1 = y.nianf and yuef <= y.yuef
  and changbb_id = y.changbb_id),0) thej from yuedfxsj y)


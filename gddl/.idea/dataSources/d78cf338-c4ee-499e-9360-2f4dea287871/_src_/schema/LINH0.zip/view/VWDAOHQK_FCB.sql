create view VWDAOHQK_FCB as
select fahdwb_id,jihkjb_id,niand,1 as yued,y1 as zhi,beiz,niandjhfb.changbb_id,yunsfsb_id
from niandjhfb
union all
select fahdwb_id,jihkjb_id,niand,2 as yued,y2 as zhi,beiz,niandjhfb.changbb_id,yunsfsb_id
from niandjhfb
union all
 select fahdwb_id,jihkjb_id,niand,3 as yued,y3 as zhi,beiz,niandjhfb.changbb_id,yunsfsb_id
from niandjhfb
union all
 select fahdwb_id,jihkjb_id,niand,4 as yued,y4 as zhi,beiz,niandjhfb.changbb_id,yunsfsb_id
from niandjhfb
union all
 select fahdwb_id,jihkjb_id,niand,5 as yued,y5 as zhi,beiz,niandjhfb.changbb_id,yunsfsb_id
from niandjhfb
union all
 select fahdwb_id,jihkjb_id,niand,6 as yued,y6 as zhi,beiz,niandjhfb.changbb_id,yunsfsb_id
from niandjhfb
union all
 select fahdwb_id,jihkjb_id,niand,7 as yued,y7 as zhi,beiz,niandjhfb.changbb_id,yunsfsb_id
from niandjhfb
union all
 select fahdwb_id,jihkjb_id,niand,8 as yued,y8 as zhi,beiz,niandjhfb.changbb_id,yunsfsb_id
from niandjhfb
union all
 select fahdwb_id,jihkjb_id,niand,9 as yued,y9 as zhi,beiz,niandjhfb.changbb_id,yunsfsb_id
from niandjhfb
union all
 select fahdwb_id,jihkjb_id,niand,10 as yued,y10 as zhi,beiz,niandjhfb.changbb_id,yunsfsb_id
from niandjhfb
union all
 select fahdwb_id,jihkjb_id,niand,11 as yued,y11 as zhi,beiz,niandjhfb.changbb_id,yunsfsb_id
from niandjhfb
union all
 select fahdwb_id,jihkjb_id,niand,12 as yued,y12 as zhi,beiz,niandjhfb.changbb_id,yunsfsb_id
from niandjhfb


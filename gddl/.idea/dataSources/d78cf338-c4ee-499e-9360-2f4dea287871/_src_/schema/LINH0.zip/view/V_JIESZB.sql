create view V_JIESZB as
Select 'C' As Flag,
       f.Yundh As Tuosbh,
       round_new(round_new(z.Farl,2)/0.0041816,0) As Qnet,
       z.Shoudjhf As Aar,
       z.Ganzjhf As Ad,
       z.Kongqgzjhf As Aad,
       round_new((100-z.Kongqgzjsf)/(100-Quansf)*Kongqgzjhff,2) As Var,
       z.Kongqgzjhff As Vad,
       z.Huiff As Vdaf,
       z.Quansf As Mt,
       z.Kongqgzjsf As Mad,
       z.Liuf As Stad,
       z.Ganzjl As Std,
       round_new(z.Liuf*(100-Quansf)/(100-Kongqgzjsf),2) As Star
  From Fahb f, Zhilb z
 Where f.Zhilb_Id = z.Id
 with read Only


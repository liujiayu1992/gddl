create view VWJIZXX as
select jz.diancxxb_id,sum(1) as tais,sum(jz.jizurl) as zongrl from jizb jz group by jz.diancxxb_id

 

create Function f_Jies_Zaf(Fahid Number, Leix Number)
  Return Number Is

Begin

  Declare
    Danj Number(10, 2) := 0.0;
  Begin
    If Leix = 0 Then
      Select Round_New(Sum(g.Shisl * g.Daozzf) / Sum(g.Shisl), 2)
        Into Danj
        From Fahgjb g
       Where g.Fahb_Id = Fahid;
    Elsif Leix = 1 Then
      Select Round_New(Sum(g.Shisl * g.Yingdyf) / Sum(g.Shisl), 2)
        Into Danj
        From Fahgjb g
       Where g.Fahb_Id = Fahid;
    Else
      Select Round_New(Sum(g.Shisl * g.Qitzf) / Sum(g.Shisl), 2)
        Into Danj
        From Fahgjb g
       Where g.Fahb_Id = Fahid;
    End If;
    Return Danj;
  Exception
    When Others Then
      Return 0;
  End;
End;
create view V_FEIY as
Select c.tuosbh,x.feiymc As feiymc,Sum(f.zhi) As zhi
From chepb c,danjcpb d,feiyb f,feiyxmb x
Where c.Id = d.chepb_id
And d.yunfdjb_id = f.yunfdjb_id
And f.feiyxmb_id = x.Id
And f.shuib = 1
Group By c.tuosbh,x.feiymc
with read only


create function getYoushcZrDate(lngDiancxxb_id in number, datDate in date) return date is
  Result date;
begin
         select max(riq) into Result from shouhcrbyb where riq<=datDate and diancxxb_id=lngDiancxxb_id;

         if (Result) is null then
            Result:=datDate;
         end if;
  return(Result);
end getYoushcZrDate;

create FUNCTION getHaommx (riq1 varchar2,riq2 varchar2) return VARCHAR2 is
--耗煤明细
begin
    declare
     mingx  VARCHAR2(4000) :='';
      v_loopcounter integer :=1;
      v_haom varchar2(200) :='';
      CURSOR my_cursor IS
        select
        to_char(c.guohsj,'yyyy-mm-dd')as guohsj,m.meikdwmc as meikdqmc,count(c.cheph)as ches
        from chepb c,fahb f,meikxxb m,meikdqb dq
        where c.fahb_id=f.id
        and f.meikxxb_id=m.id
        and  dq.id=m.meikdqb_id
        and to_char(c.guohsj,'yyyy-mm-dd')>=riq1
        and to_char(c.guohsj,'yyyy-mm-dd')<=riq2
        And c.Meicb_Id =0
        group by  to_char(c.guohsj,'yyyy-mm-dd'),m.meikdwmc;
      my_rec my_cursor%ROWTYPE;
    begin
      OPEN my_cursor;
        LOOP
          FETCH my_cursor INTO my_rec;
            EXIT WHEN my_cursor%NOTFOUND;
            IF v_loopcounter = 1 THEN
              v_haom := my_rec.meikdqmc;
              mingx := v_haom||' '||my_rec.ches||'车';
            ELSE
                mingx := mingx||','||my_rec.meikdqmc||' '||my_rec.ches||'车';
            END IF;
          v_loopcounter := v_loopcounter + 1;
        END LOOP;
      CLOSE my_cursor;
      RETURN mingx;
    END;
END;

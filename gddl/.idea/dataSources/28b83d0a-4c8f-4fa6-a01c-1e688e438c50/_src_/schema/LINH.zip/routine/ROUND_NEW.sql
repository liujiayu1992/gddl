create FUNCTION        "ROUND_NEW" (Value0 Number, Bit0 Number)
  Return Number Is
Begin
  Declare
    Value1 Number;
    Value2 Number;
  Begin

    If Value0 = 0 Then
      Return 0;
    End If;

    Value1 := Floor(Value0 * Power(10, Bit0)) -
              Floor(Value0 * Power(10, Bit0 - 1)) * 10;
    Value2 := Value0 * Power(10, Bit0);

    If (Value2 - Floor(Value0 * Power(10, Bit0))) >= 0.5 And
       (Value2 - Floor(Value0 * Power(10, Bit0))) < 0.6 Then
      If (Value2 - Floor(Value0 * Power(10, Bit0))) = 0.5 Then
        If Value1 = 0 Or Value1 = 2 Or Value1 = 4 Or Value1 = 6 Or
           Value1 = 8 Then
          Return Floor(Value0 * Power(10, Bit0)) / Power(10, Bit0);
        Else
          Return(Floor(Value0 * Power(10, Bit0)) + 1) / Power(10, Bit0);
        End If;
      Else
        Return Round(Value0 * Power(10, Bit0)) / Power(10, Bit0);
      End If;
    Else
      Return Round(Value0 * Power(10, Bit0)) / Power(10, Bit0);
    End If;

  End;
End Round_New;

 
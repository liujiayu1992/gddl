create function GetCaiyCheps(zhilbid number) return number is
  result number(10);
begin
   DECLARE
   cheps number(10);
   CURSOR C_cheps IS SELECT count(cheph) as ches FROM fahbtmp where zhilb_id=zhilbid;
   begin
   open C_cheps;
   FETCH C_cheps INTO cheps;
   if C_cheps%FOUND then
                    Result:= cheps;
                 end if;
     CLOSE C_cheps;
   return (result) ;
   end;

end GetCaiyCheps;

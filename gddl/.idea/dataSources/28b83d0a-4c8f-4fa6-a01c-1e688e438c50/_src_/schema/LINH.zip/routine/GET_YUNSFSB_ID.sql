create FUNCTION        "GET_YUNSFSB_ID" (strYunsfsName In varchar2)
Return  number as
begin
     declare
     yunsfsbid number;
     begin
     select max(id) into yunsfsbid from yunsfsb p where p.mingc=strYunsfsName;
     return yunsfsbid;
     end;
End;

 
create Function F_RULMYDTJB_SHENHZT(Changb_Id In Number,
                                              Nianf In Number,Yuef In Number)
  Return Number Is Result Number;
Begin
  Select r.shenhzt
    Into Result
    From RULMYDTJB r
   Where r.Changbb_Id = Changb_Id
     And r.niand = Nianf
     And r.yued = Yuef
     And r.shenhzt = 1;
  Return Result;
Exception
  When No_Data_Found Then
    Return 0;
  When Others Then
    Return 1;
End F_RULMYDTJB_SHENHZT;

create trigger TRGDELCHEPBUPDATETMP
	before delete
	on CHEPB
	for each row
declare
  -- local variables here
begin
  update chepbtmp set fahb_id=0 where id=:old.id;
end trgDelChepbUpdateTmp;

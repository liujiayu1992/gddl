create Function get_Pinzb_Id(strPinzName In varchar2)
Return  number as
begin
     declare
     pizbid number;
     begin
     select max(id) into pizbid from pinzb p where p.mingc=strPinzName;
     return pizbid;
     end;
End;

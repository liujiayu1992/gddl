create Function Get_CaiyCheph(zhilbid Number,jiesbid Number) Return Varchar2 Is
  Result Varchar2(2000);
Begin
   Declare
   v_cheph chepb.cheph%Type;
   Cursor C_chepb Is Select c.Cheph
       From chepb c,fahb f
       Where f.Id = c.Fahb_Id
       And f.Zhilb_Id=zhilbid
       And c.Jiesb_Id=jiesbid;

   Begin
       Open C_chepb;
       Loop
           Fetch C_chepb Into v_cheph;
                 If C_chepb%Found Then
                    Result:=Result||v_cheph||',';
                 End If;
                 Exit When C_chepb%Notfound;
           End Loop;
           Close C_chepb;
           If Length(Result)>0 Then
            Result:=substr(Result,0,Length(Result)-1);
           End If;
          Return(Result);
   End;
End Get_CaiyCheph;
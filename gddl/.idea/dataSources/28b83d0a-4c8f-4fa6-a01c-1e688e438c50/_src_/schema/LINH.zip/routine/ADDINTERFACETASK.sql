create PROCEDURE        "ADDINTERFACETASK" (strRenwmc in varchar2, strRenwbs in varchar2,intRenwlx in number,
                                             intChangbb_id in number,strMingllx in varchar2,strMinglcs in varchar2,
                                             datriq in date) is
begin
      --检查数据是否存在
      declare
        v_id number(15);
        cursor c_a is select id  from jiekrwb jk where jk.RENWMC=strRenwmc
                     AND jk.RENWBS=strRenwbs
                     and jk.ZHIXZT < 1
                     and jk.RENLLX=0;
        cursor c_s is select id  from jiekrwb jk
             where jk.RENWMC=strRenwmc
             and jk.RENWBS=strRenwbs
             and jk.RENLLX=intRenwlx
             and jk.CHANGBB_ID=intChangbb_id
             and jk.MINGLLX=strMingllx
             and jk.MINGLCS=strMinglcs
             and jk.ZHIXZT < 1;
      begin
           v_id:=-1;
          open c_s;
               fetch c_s into v_id;
          close c_s;
          if (v_id<>-1) then--如果有同样的任务存在，不记录任务
             return ;
          end if;
          if intRenwlx=3 or intRenwlx=2 then
             open c_a;
                  fetch c_a into v_id;
             close c_a;
             if (v_id<>-1) then--之前有增加的任务没有执行，修改命令无需记录
                return ;
             end if;
          end if;
          if intRenwlx=1 then--如果是删除命令，之前有增加命令没有执行的删除所有未执行任务，不记录此命令，如果没有新增未执行的，删除以前的所有未执行的任务
             delete from jiekrwb jk where jk.RENWMC=strRenwmc and jk.RENWBS=strRenwbs and jk.ZHIXZT < 1;
          end if;
          insert into jiekrwb (ID,RENWMC,RENWBS,RENLLX,CHANGBB_ID,MINGLLX,MINGLCS,RENWSJ)
                  values(xl_jiekrwb_id.nextval,strRenwmc,strRenwbs,intRenwlx,intChangbb_id,strMingllx,strMinglcs,datriq);
          end ;
end AddInterfaceTask;

 
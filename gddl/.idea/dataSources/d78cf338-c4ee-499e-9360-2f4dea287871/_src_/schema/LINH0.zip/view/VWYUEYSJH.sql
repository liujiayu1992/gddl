create view VWYUEYSJH as
Select Substr(Riq, 1, 4) as Niand,
       Substr(Riq, 6, Length(Riq) - 5) as Yued,
       Fahdwb.Gongysbm as Gonghdwbm,
       d.Diancbm as Shouhdwbm,
       y.Faz as Fazbm,
       min(Pinzb.Pinzbm) as Meizbm,
       min(r.Pinzbm) as Pinzbm,
       sum(y.Ches) as ches,
       sum(y.Duns) as duns,
       min( '否') as Bucjh,
       min(Nvl(Yuns.Beiz, 'HY')) As Yunsfs
  From Yunsjhb y, changbb d, Fahdwb, Pinzb, Ranlpzb r, Yunsfsb Yuns
 Where y.Fahdwb_Id = Fahdwb.Id(+)
   And y.Pinzb_Id = Pinzb.Id(+)
   And y.Ranlpzb_Id = r.Id(+)
   And y.Yunsfsb_Id = Yuns.Id(+)
   and y.changbb_id = d.id
 group by d.Diancbm,Substr(Riq, 1, 4),Substr(Riq, 6, Length(Riq) - 5),Fahdwb.Gongysbm,y.faz


create FUNCTION "DENGJI" (HeatCol number) return number is
begin
    declare

    lngDepartint number;
    begin

    If HeatCol=0 Then
      return 0;
    End If;

    lngDepartInt:= TRUNC(HeatCol);

    If (HeatCol - lngDepartInt)<= 0.5 Then
       return lngDepartInt + 0.5;
    Else
       return lngDepartInt + 1;
    End If;
    end;
end dengji;

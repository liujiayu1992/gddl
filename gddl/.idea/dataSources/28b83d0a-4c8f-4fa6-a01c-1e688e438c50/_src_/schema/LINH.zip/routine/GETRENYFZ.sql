create FUNCTION        "GETRENYFZ" (renyid in long)
return varchar2 is Result varchar2(2000);
begin
     declare
     groupName varchar2(50);
   cursor zindex is select z.mingc into groupName from renyxxb r,renyzqxb q,zuxxb z where r.id=renyid
                           and r.id = q.renyxxb_id and q.zuxxb_id = z.id;
   begin

        open zindex;
             loop
                  fetch zindex into groupName;
                  exit when zindex%notfound;
                  if Result is null then
                       Result:=groupName;
                  else
                     Result := Result ||','||groupName;
                  end if;
             end loop ;
        close zindex ;
   end;
   return Result;
end;

 
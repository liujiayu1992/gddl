create trigger TRIGGER_IUD_QICHJJBTMP
	before insert or update
	on QICHJJBTMP
	for each row
DECLARE
  CURSOR CUR_MKDW IS
    SELECT ID FROM MEIKXXB WHERE MEIKDWMC LIKE '%厂内转煤%';
  --指定行指针,这句话应该是指定和CUR_MKDW行类型相同的变量
  ROW_MKDW CUR_MKDW%ROWTYPE;
BEGIN
  --for循环
  FOR ROW_MKDW IN CUR_MKDW LOOP
    --当煤矿单位为厂内转煤时，质量表ID=1且状态=1
    IF :NEW_VALUE.MEIKXXB_ID = ROW_MKDW.ID THEN
      :NEW_VALUE.ZHILB_ID := 1;
      :NEW_VALUE.ZHUANGT  := 1;
    END IF;
  END LOOP;
END;

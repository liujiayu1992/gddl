create view VWHETLWCQKHZ as
select b.nianf, b.yuef, b.changbb_id, '本月' as xiangm,nvl(b.hejdhl,0) as hejdhl,
	nvl(t.hejdhl,0) as thejdhl
	,round_new(decode(t.hejdhl,0,100,null,100,(b.hejdhl-t.hejdhl)*100/t.hejdhl),2) as hejzzv
	,nvl(b.zddhl,0) as zddhl, nvl(t.zddhl,0) as tzddhl
	,round_new(decode(t.zddhl,0,100,null,100,(b.zddhl-t.zddhl)*100/t.zddhl),2) zdzzl
	,round_new(decode(b.zdhtl,0,100,b.zddhl*100/b.zdhtl),2) zddhv,b.qydhl
	,round_new(decode(t.qydhl,0,100,null,100,(b.qydhl-t.qydhl)*100/t.qydhl),2) qyzzl
	,round_new(decode(b.qyhtl,0,100,b.qydhl*100/b.qyhtl),2) qydhv,b.scdhl
	,round_new(decode(t.scdhl,0,100,null,100,(b.scdhl-t.scdhl)*100/t.scdhl),2) sczzl
	,round_new(decode(b.schtl,0,100,b.scdhl*100/b.schtl),2) scdhv from
	(select td.nianf,td.yuef,td.changbb_id,(td.zddhl+td.qydhl+td.scdhl) as hejdhl,td.zddhl,td.qydhl,td.scdhl
	from hetlwcqkhzb td ) t,
	(select bd.nianf,bd.yuef,bd.changbb_id,(bd.zddhl+bd.qydhl+bd.scdhl) as hejdhl,bd.zddhl,bd.zdhtl,bd.qydhl
	,bd.qyhtl,bd.scdhl,bd.schtl from hetlwcqkhzb bd) b
	where b.changbb_id = t.changbb_id(+) and b.nianf-1 = t.nianf(+) and b.yuef = t.yuef(+)
	union
	select bsum.nianf, bsum.yuef, bsum.changbb_id,'累计' as xiangm, nvl(bsum.hejdhl,0) as hejdhl
	,nvl(tsum.hejdhl,0) as thejdhl
	,round_new(decode(tsum.hejdhl,0,100,null,100,(bsum.hejdhl-tsum.hejdhl)*100/tsum.hejdhl),2) as hejzzv
	,nvl(bsum.zddhl,0) as zddhl,nvl(tsum.zddhl,0) as tzddhl
	,round_new(decode(tsum.zddhl,0,100,null,100,(bsum.zddhl-tsum.zddhl)*100/tsum.zddhl),2) zdzzl
	,round_new(decode(bsum.zdhtl,0,100,bsum.zddhl*100/bsum.zdhtl),2) zddhv,bsum.qydhl
	,round_new(decode(tsum.qydhl,0,100,null,100,(bsum.qydhl-tsum.qydhl)*100/tsum.qydhl),2) qyzzl
	,round_new(decode(bsum.qyhtl,0,100,bsum.qydhl*100/bsum.qyhtl),2) qydhv,bsum.scdhl
	,round_new(decode(tsum.scdhl,0,100,null,100,(bsum.scdhl-tsum.scdhl)*100/tsum.scdhl),2) sczzl
	,round_new(decode(bsum.schtl,0,100,bsum.scdhl*100/bsum.schtl),2) scdhv from
	(select nianf,yuef,changbb_id,(select sum(st.zddhl+st.qydhl+st.scdhl) from hetlwcqkhzb st
	where st.nianf+1 =nianf and st.yuef<=yuef and st.changbb_id = changbb_id ) hejdhl,
	(select sum(st.zddhl) from hetlwcqkhzb st
	where st.nianf+1 =nianf and st.yuef<=yuef and st.changbb_id = changbb_id ) zddhl,
	(select sum(st.qydhl) from hetlwcqkhzb st
	where st.nianf+1 =nianf and st.yuef<=yuef and st.changbb_id = changbb_id ) qydhl,
	(select sum(st.scdhl) from hetlwcqkhzb st
	where st.nianf+1 =nianf and st.yuef<=yuef and st.changbb_id = changbb_id ) scdhl
	 from hetlwcqkhzb ) tsum,
	 (select nianf,yuef,changbb_id,(select sum(st.zddhl+st.qydhl+st.scdhl) from hetlwcqkhzb st
	where st.nianf =nianf and st.yuef<=yuef and st.changbb_id = changbb_id ) hejdhl,
	(select sum(st.zddhl) from hetlwcqkhzb st
	where st.nianf =nianf and st.yuef<=yuef and st.changbb_id = changbb_id ) zddhl,
	(select sum(st.zdhtl) from hetlwcqkhzb st
	where st.nianf =nianf and st.yuef<=yuef and st.changbb_id = changbb_id ) zdhtl,
	(select sum(st.qydhl) from hetlwcqkhzb st
	where st.nianf =nianf and st.yuef<=yuef and st.changbb_id = changbb_id ) qydhl,
	(select sum(st.qyhtl) from hetlwcqkhzb st
	where st.nianf =nianf and st.yuef<=yuef and st.changbb_id = changbb_id ) qyhtl,
	(select sum(st.scdhl) from hetlwcqkhzb st
	where st.nianf =nianf and st.yuef<=yuef and st.changbb_id = changbb_id ) scdhl,
	(select sum(st.schtl) from hetlwcqkhzb st
	where st.nianf =nianf and st.yuef<=yuef and st.changbb_id = changbb_id ) schtl
	 from hetlwcqkhzb ) bsum


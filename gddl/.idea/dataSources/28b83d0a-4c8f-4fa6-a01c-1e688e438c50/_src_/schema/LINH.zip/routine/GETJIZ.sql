create FUNCTION        "GETJIZ" (chuanr IN NUMBER,chuan IN varchar2)
  return varchar2 is Result varchar2(2000);

BEGIN

   DECLARE
    v_beiz KAOHBZB.beiz%TYPE;
   CURSOR C_beiz IS select k.beiz beiz from KAOHBZB k,item it where k.shangx > chuanr and k.xiax<=chuanr and k.kaohxm_id=it.id and it.bianm=chuan;
   begin


OPEN C_beiz;
    loop
           FETCH C_beiz INTO v_beiz;
                 if C_beiz%FOUND  then
                    Result:=Result||v_beiz||',';
                 end if;
                 EXIT WHEN C_beiz%NOTFOUND;
           end loop;
           CLOSE C_beiz;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
   return Result; --chuanr;
end getjiz;

 
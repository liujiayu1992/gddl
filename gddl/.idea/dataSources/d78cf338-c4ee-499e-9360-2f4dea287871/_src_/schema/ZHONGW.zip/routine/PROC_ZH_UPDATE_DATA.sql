create PROCEDURE PROC_ZH_UPDATE_DATA IS
BEGIN
    DECLARE

        V_MEIKDWMC MEIKXXB.MINGC%TYPE;--煤矿名称
        V_YUNSDWMC YUNSDWB.MINGC%TYPE;--运输单位名称
        V_JIHKJB_ID JIHKJB.ID%TYPE;--计划口径ID
        V_JIHKJMC JIHKJB.MINGC%TYPE;--计划口径名称
        V_GONGYSMC GONGYSB.MINGC%TYPE;--供应商名称
        V_CHEPBTMP_ID CHEPBTMP.ID%TYPE;--车皮临时表ID
        V_CHEPB_ID CHEPB.ID%TYPE;--扯皮表ID
        V_FAHB_ID FAHB.ID%TYPE;--发货ID
        V_FAHB_EDIT_ID FAHB.ID%TYPE;
        ROW_TRUCKENTER V_TRUCKENTER%ROWTYPE;--纵横修改数据

        --读取日志表中需要进行同步的数据记录
        CURSOR CUR_MODIFYLOG IS
            SELECT * FROM T_MODIFYLOG ORDER BY HANDLEDATE;

    BEGIN
        FOR CUR IN CUR_MODIFYLOG LOOP
            BEGIN

                --查询修改的CHEPBTMP数据
                SELECT MAX(ID) INTO V_CHEPBTMP_ID FROM CHEPBTMP WHERE V_TRUCKENTER_ID = CUR.TRUCKENTERID;
                --存在CHEPBTMP数据
                IF V_CHEPBTMP_ID IS NOT NULL THEN
                    --查询数据是否导入到CHEPB中，CHEPB的ID与CHEPBTMP的ID相同
                    SELECT MAX(ID),MAX(FAHB_ID) INTO V_CHEPB_ID,V_FAHB_ID FROM CHEPB  WHERE ID = V_CHEPBTMP_ID;
                    --修改数据
                    IF  UPPER(CUR.TYPE) = 'EDITE' THEN
                        V_MEIKDWMC := '';
                        V_YUNSDWMC := '';
                        V_JIHKJMC  := '';
                        V_JIHKJB_ID := -1;
                        V_GONGYSMC := '';

                        --查询纵横修改的数据
                        SELECT * INTO ROW_TRUCKENTER FROM V_TRUCKENTER WHERE ID = CUR.TRUCKENTERID;

                        --判断煤矿编码是否存在
                        --SELECT NVL(MAX(MINGC),ROW_TRUCKENTER.COLLIERYNAME),--对应的ID找不到时，采用名称
                        --     NVL(MAX(JIHKJB_ID),-1) AS JIHKJB_ID
                        --INTO V_MEIKDWMC,V_JIHKJB_ID
                        --FROM MEIKXXB
                        --WHERE ID||'' = ''''||ROW_TRUCKENTER.COLLIERYCODE;--枪支转换成字符串连接,避免类型不匹配
                        
                        SELECT MAX(MINGC) INTO V_MEIKDWMC FROM MEIKXXB WHERE ID = ROW_TRUCKENTER.COLLIERYCODE;
                        IF V_MEIKDWMC IS NULL THEN
                           V_MEIKDWMC := ROW_TRUCKENTER.COLLIERYNAME;
                        END IF;
                        
                        --判断运输单位编码是否存在
                        --SELECT NVL(MAX(MINGC),ROW_TRUCKENTER.TRANSUNITNAME)--对应的ID找不到时，采用名称
                        --INTO V_YUNSDWMC
                        --FROM YUNSDWB
                        --WHERE ID||'' = ''''||ROW_TRUCKENTER.TRANSUNITCODE||'''';
                        
                        --判断运输单位编码是否存在
                        SELECT MAX(MINGC) INTO V_YUNSDWMC FROM YUNSDWB WHERE ID = ROW_TRUCKENTER.TRANSUNITCODE;
                        IF V_YUNSDWMC IS NULL THEN
                           V_YUNSDWMC := ROW_TRUCKENTER.TRANSUNITNAME;
                        END IF;
                
                        --根据煤矿缺省的计划口ID查询计划口径名称
                        --SELECT NVL(MAX(MINGC),'市场采购')--对应的ID找不到时，默认使用“市场采购“
                        --INTO V_JIHKJMC
                        --FROM JIHKJB
                        --WHERE ID||'' = ''''||V_JIHKJB_ID||'''';
                        
                        --计划口径名称
                        SELECT MINGC INTO V_JIHKJMC FROM JIHKJB WHERE ID =(SELECT JIHKJB_ID FROM MEIKXXB WHERE ID = ROW_TRUCKENTER.COLLIERYCODE);
                        IF V_JIHKJMC IS NULL THEN
                           V_JIHKJMC := '市场采购';
                        END IF;
                        
                        --供应商
                        --SELECT NVL(MAX(MINGC),ROW_TRUCKENTER.COLLIERYNAME) INTO V_GONGYSMC FROM GONGYSB WHERE ID IN(
                         --    SELECT GONGYSB_ID FROM GONGYSMKGLB WHERE ID||'' = ''''||ROW_TRUCKENTER.COLLIERYCODE
                        --);
                        --供应商
                        SELECT MAX(MINGC) INTO V_GONGYSMC FROM GONGYSB WHERE ID IN(
                               SELECT GONGYSB_ID FROM GONGYSMKGLB WHERE MEIKXXB_ID = ROW_TRUCKENTER.COLLIERYCODE
                        );
                        IF V_GONGYSMC IS NULL THEN
                           V_GONGYSMC := V_MEIKDWMC;
                        END IF;

                       --修改CHEPBTMP数据
                       UPDATE CHEPBTMP
                       SET
                            QINGCHH        =    ROW_TRUCKENTER.HASHNO                                              ,        --过皮衡号
                            QINGCJJY       =    ROW_TRUCKENTER.HASHUSER                                            ,        --过皮人员
                            ZHONGCSJ       =    TO_DATE(ROW_TRUCKENTER.FWEIGHTIME,'YYYY-MM-DD HH24:MI:SS')         ,        --过重时间
                            ZHONGCHH       =    ROW_TRUCKENTER.WEIGHNO                                             ,        --过重衡号
                            ZHONGCJJY       =    ROW_TRUCKENTER.WEIGHTUSER                                          ,       --过重人员
                            LURY           =    '纵横'                                                  ,
                            BEIZ           =     '', --化验编码                                                   ,            --备注
                            CAIYRQ           =    DECODE(ROW_TRUCKENTER.TOSAMDATE,NULL,SYSDATE,TO_DATE(ROW_TRUCKENTER.TOSAMDATE,'YYYY-MM-DD'))                    ,         --采样日期
                            LURSJ           =    SYSDATE                                                 ,
                            YUNSDW           =    V_YUNSDWMC                                              ,         --车队名称
                            DIANCXXB_ID       =    476                                                     ,
                            PIAOJH           =    ROW_TRUCKENTER.TAKECOALNO                                          ,         --提煤单号
                            GONGYSMC       =    V_GONGYSMC                                              ,         --供应商
                            MEIKDWMC       =    V_MEIKDWMC                                              ,         --煤矿名称
                            PINZ           =    '煤'                                                    ,
                            FAZ               =    '汽'                                                    ,
                            DAOZ           =    '汽'                                                    ,
                            JIHKJ           =    V_JIHKJMC                                               ,         --计划口径
                            FAHRQ           =    TO_DATE(ROW_TRUCKENTER.EWEIGHTDATE,'YYYY-MM-DD')                   ,
                            DAOHRQ           =    TO_DATE(ROW_TRUCKENTER.EWEIGHTDATE,'YYYY-MM-DD')                   ,
                            CAIYBH           =    '0'                                                       ,
                            YUNSFS           =    '公路'                                                  ,
                            CHEC           =    '1'                                                     ,
                            CHEPH           =    ROW_TRUCKENTER.NUMBERPLATE                                         ,         --车牌号
                            MAOZ           =    ROW_TRUCKENTER.FWEIGHT/1000                                             ,         --毛重
                            PIZ               =    ROW_TRUCKENTER.EWEIGHT/1000                                             ,         --皮重
                            BIAOZ           =    DECODE(NVL(ROW_TRUCKENTER.COALNETWEIGHT,0),0,ROW_TRUCKENTER.NETWEIGHT/1000,ROW_TRUCKENTER.COALNETWEIGHT/1000)   ,         --票重，0时保存净重
                            KOUD           =    ROW_TRUCKENTER.DEDCUTTON/1000                                           ,         --扣吨
                            JIANJFS           =    '过衡'                                                  ,
                            CHEBB_ID       =    3                                                       ,
                            YUANDZ           =    '汽'                                                    ,
                            YUANSHDW       =    '青铝发电'                                              ,
                            QINGCSJ           =    TO_DATE(ROW_TRUCKENTER.EWEIGHTIME,'YYYY-MM-DD HH24:MI:SS')         ,         --过皮时间
                            XIECFS           =    '机械'                                                  ,
                            YUANMZ           =    ROW_TRUCKENTER.FWEIGHT/1000                                             ,         --毛重
                            YUANPZ           =    ROW_TRUCKENTER.EWEIGHT/1000                                             ,          --皮重
                            V_TRUCKENTER_SAMCODE = ROW_TRUCKENTER.SAMCODE,
                            FAHBTMP_ID           =            -1,
                            UPDATE_BEIZ          =  '[' || SYSDATE || '],' ||CUR.TRUCKENTERID || ',' ||  CUR.HANDLEDATE
                        WHERE V_TRUCKENTER_ID = ROW_TRUCKENTER.ID;

                        IF V_CHEPB_ID IS NOT NULL THEN
                            --修改CHEPB数据
                            UPDATE CHEPB SET
                              QINGCHH = ROW_TRUCKENTER.HASHNO,
                              ZHONGCHH = ROW_TRUCKENTER.WEIGHNO,
                              CHEPH = ROW_TRUCKENTER.NUMBERPLATE,
                              PIAOJH = ROW_TRUCKENTER.TAKECOALNO,
                              MAOZ = ROW_TRUCKENTER.FWEIGHT/1000,
                              PIZ = ROW_TRUCKENTER.EWEIGHT/1000,
                              BIAOZ = DECODE(ROW_TRUCKENTER.COALNETWEIGHT,0,ROW_TRUCKENTER.NETWEIGHT/1000,ROW_TRUCKENTER.COALNETWEIGHT/1000),
                              YINGD = 0.000,
                              YINGK = DECODE(ROW_TRUCKENTER.COALNETWEIGHT,0,0,(ROW_TRUCKENTER.NETWEIGHT-ROW_TRUCKENTER.COALNETWEIGHT)/1000),
                              YUNS = 0.000,
                              KOUD = ROW_TRUCKENTER.DEDCUTTON/1000,
                              ZONGKD = ROW_TRUCKENTER.DEDCUTTON/1000,
                              QINGCSJ = TO_DATE(ROW_TRUCKENTER.EWEIGHTIME, 'YYYY-MM-DD HH24:MI:SS'),
                              QINGCJJY = ROW_TRUCKENTER.HASHUSER,
                              ZHONGCSJ = TO_DATE(ROW_TRUCKENTER.FWEIGHTIME, 'YYYY-MM-DD HH24:MI:SS'),
                              ZHONGCJJY = ROW_TRUCKENTER.WEIGHTUSER,
                              LURSJ = SYSDATE,
                              BEIZ = TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS')||'数据同步'
                            WHERE ID = V_CHEPB_ID;

                            --煤矿是否修改
                            SELECT ID INTO V_FAHB_EDIT_ID FROM FAHB
                            WHERE MEIKXXB_ID = ROW_TRUCKENTER.COLLIERYNAME
                                AND DAOHRQ = TO_DATE(ROW_TRUCKENTER.EWEIGHTDATE,'YYYY-MM-DD');

                            IF V_FAHB_ID<>V_FAHB_EDIT_ID THEN
                                UPDATE CHEPB SET FAHB_ID = V_FAHB_EDIT_ID WHERE ID = V_CHEPB_ID;
                            END IF;
                        END IF;
                        
                        --删除同步日志数据
                        INSERT INTO T_MODIFYLOG_BAK SELECT * FROM T_MODIFYLOG WHERE TRUCKENTERID = CUR.TRUCKENTERID AND HANDLEDATE = CUR.HANDLEDATE;
                        DELETE FROM T_MODIFYLOG WHERE TRUCKENTERID = CUR.TRUCKENTERID AND HANDLEDATE = CUR.HANDLEDATE;


                    --删除数据
                    ELSIF UPPER(CUR.TYPE) = 'DEL' THEN
                        --删除CHEPBTMP数据
                        DELETE FROM CHEPBTMP WHERE V_TRUCKENTER_ID = V_CHEPBTMP_ID;
                        IF V_CHEPB_ID IS NOT NULL THEN
                            --删除CHEPB数据
                            DELETE FROM CHEPB WHERE ID = V_CHEPB_ID;
                        END IF;
                        --删除同步日志数据
                        INSERT INTO T_MODIFYLOG_BAK SELECT * FROM T_MODIFYLOG WHERE TRUCKENTERID = CUR.TRUCKENTERID AND HANDLEDATE = CUR.HANDLEDATE;
                        DELETE FROM T_MODIFYLOG WHERE TRUCKENTERID = CUR.TRUCKENTERID AND HANDLEDATE = CUR.HANDLEDATE;

                    END IF;
                    
                END IF;

                --提交数据
                COMMIT;

            --当执行时发生异常时记录异常，并不影响下面的数据执行
            EXCEPTION  WHEN OTHERS THEN
                --回滚数据
                ROLLBACK;
                DBMS_OUTPUT.PUT_LINE('异常:' || CUR.TRUCKENTERID || SUBSTR(SQLERRM,1,500));
            END;
        END LOOP;
        COMMIT;
    EXCEPTION WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('异常:' || SUBSTR(SQLERRM,1,500));
    END;
END PROC_ZH_UPDATE_DATA;

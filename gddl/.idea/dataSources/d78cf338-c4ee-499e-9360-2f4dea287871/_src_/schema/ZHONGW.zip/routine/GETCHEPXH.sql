create FUNCTION getChepxh(lursj in date)
	Return  number as
	begin
       declare
	     intXuh number;
	     begin
            select nvl(max(c.xuh),0)+1 into intXuh from chepxhb c where to_char(c.riq,'yyyy-mm-dd') = to_char(lursj,'yyyy-mm-dd');
            return intXuh;
	     end;
	end;

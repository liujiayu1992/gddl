create trigger TRIGGER_YUEDJHZB
	before insert or update or delete
	on YUEDJHZB
	for each row
Begin

  if deleting then
   -- AddInterfaceTask('yuexqjhh',:old.id,1,:old.changbb_id,'xml',:old.id,to_date(:old.niand || :old.yued, 'yyyymm'));
   return;
  elsif updating and :new.zhuangt = 1 then
    if :new.niand <> :old.niand or :new.yued <> :old.yued or
       :new.jihfdl <> :old.jihfdl or :new.yuanmh <> :old.yuanmh or
       :new.jihgrl <> :old.jihgrl or :new.gongrymh <> :old.gongrymh or
       :new.yunssh <> :old.yunssh or :new.yueckc <> :old.yueckc or
       :new.yuemkc <> :old.yuemkc or :new.rulrz <> :old.rulrz or
       :new.rulmrz <> :old.rulmrz or :new.fadmh <> :old.fadmh or
       :new.gongrmh <> :old.gongrmh or :new.fadml <> :old.fadml or
       :new.gongrml <> :old.gongrml or :new.qithml <> :old.qithml or
       :new.qbhyyml <> :old.qbhyyml or :new.cuncshl <> :old.cuncshl or
       :new.shuifctz <> :old.shuifctz or :new.caigml <> :old.caigml or
       :new.zhuangt <> :old.zhuangt
       then
      AddInterfaceTask('yuexqjhh',
                       :new.id,
                       2,
                       :new.changbb_id,
                       'xml',
                       :new.id,
                       to_date(:new.niand || :new.yued, 'yyyymm'));
    end if;
  end if;

exception
  when others then
    if deleting then
      zengjrz('trigger_yuedjhzb', :old.id, '删除', SQLCODE, SQLERRM);
    else
      zengjrz('trigger_yuedjhzb', :old.id, '修改', SQLCODE, SQLERRM);
    end if;
End;

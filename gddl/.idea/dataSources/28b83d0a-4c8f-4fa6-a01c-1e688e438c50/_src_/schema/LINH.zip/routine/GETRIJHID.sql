create FUNCTION        "GETRIJHID" (dhrq in date,cheh in varchar2
,jjsj in date,diancxxbid in number) Return number
is begin
    declare
    jhid number;
    wcsj date;
    Cursor cur_j is
           select j.id jhid,q.wancsj
                  from qicrjhb j,qicrjhcpb q, chelxxb c
           where c.cheph = cheh and j.riq = dhrq and j.zhuangt = 0
                 and q.chelxxb_id = c.id and q.qicrjhb_id = j.id
                 and j.diancxxb_id = diancxxbid order by wancsj;
     begin
            OPEN cur_j;
            LOOP
                 FETCH cur_j INTO jhid,wcsj;
            EXIT when cur_j%NOTFOUND;
                 if jjsj < wcsj then
                    return jhid;
                 end if;
            END LOOP;
            CLOSE cur_j;
            return -1;
    end;
end;

 
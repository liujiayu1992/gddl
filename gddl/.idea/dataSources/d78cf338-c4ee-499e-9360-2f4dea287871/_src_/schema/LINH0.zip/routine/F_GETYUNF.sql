create Function f_getYunf(
in_meikxxbid Number,
in_shuib Number,
in_fazid Number,
in_daozid Number,
in_biaoz Number,
in_cheb Number,
in_jihkjid Number,
riq varchar2,
in_leix Number) Return Number Is
Begin
     --参数类型的含义：
        --估收运费，通过类型识别是运费还是交货前杂费。
        --暂时取应付的费用就可以了
        --in_shuib
        --0, "可抵税运费"
        --1, "不可抵税运费"
        --in_leix
        --0, "应付"
        --1, "拒付"
        --2, "扣付"
    Declare
      jine Number :=0;
      Cursor my_cursor Is
        Select fy.zhi
        From  biaozhpb hp,biaozhpfyb fy
        Where hp.Id = fy.biaozhpb_id
        And fy.shuib = in_shuib
        And leix = in_leix
        And meikxxb_id = in_meikxxbid
        And faz_id = in_fazid
        And daoz_id = in_daozid
        And biaoz =  in_biaoz
        And cheb = in_cheb
        And jihkjb_id = in_jihkjid
        And zuihgxrq <= to_date(riq,'yyyy-mm-dd')
        And Rownum = 1;
      my_rec my_cursor%Rowtype;
    Begin
      Open my_cursor;
        Loop
          Fetch my_cursor Into my_rec;
            Exit When my_cursor%Notfound;
            jine := my_rec.zhi;
        End Loop;
      Close my_cursor;
      Return jine;
    End;
End;

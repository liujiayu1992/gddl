create view VWDIANCDHL as
select shidl.changbb_id,shidl.niand,shidl.yued,shidl,jihl,decode(jihl,0,0,round(shidl/jihl,2)) daohl
from (
select fahb.changbb_id ,to_char(fahb.daohrq,'YYYY')niand,to_char(fahb.daohrq,'MM')yued,sum(biaoz) + sum(yingd) - sum(kuid) shidl
from fahb
group by fahb.changbb_id,to_char(fahb.daohrq,'YYYY'),to_char(fahb.daohrq,'MM')
)shidl,
(select changbb_id,niand,yued,sum(danydhl)jihl
from yuedjhfb
group by changbb_id,niand,yued)jihl
where shidl.changbb_id=jihl.changbb_id and shidl.niand=jihl.niand and shidl.yued=jihl.yued


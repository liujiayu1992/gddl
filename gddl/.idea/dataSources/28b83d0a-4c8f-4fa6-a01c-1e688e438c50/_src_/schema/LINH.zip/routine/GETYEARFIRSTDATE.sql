create FUNCTION        "GETYEARFIRSTDATE" (datDate in date) return date is
  Result date;
begin
  return to_date(to_char(datdate,'yyyy') ||'-01-01','yyyy-mm-dd');
end getYearFirstDate;

 
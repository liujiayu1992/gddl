create function get_fhlaimsl_lj(lngDiancxxb_id in number,datDate
in date) return number is
  Result number(10,2);
begin
    declare
        ljslzhi number(10,2);
        begin
             select sum(jingz) into ljslzhi  from fahb
                        where diancxxb_id =lngDiancxxb_id
                        and daohrq>=First_day(datDate)
                        and daohrq<=datDate
                        group by diancxxb_id;
        return ljslzhi;
        Exception
        WHEN NO_DATA_FOUND  THEN
             return  0;
        When Others Then
        Return  0;
End;
end;

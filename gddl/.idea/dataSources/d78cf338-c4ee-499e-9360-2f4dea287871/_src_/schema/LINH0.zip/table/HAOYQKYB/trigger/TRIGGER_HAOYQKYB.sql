create trigger TRIGGER_HAOYQKYB
	before insert or update or delete
	on HAOYQKYB
	for each row
Declare
     v_id  laiyqkb.id%Type;
Begin
     if inserting then
            select id into v_id
            from ranlkcqk
            where ranlkcqk.riq = :new.riq and pinz='油' and changbb_id=:new.changbb_id;
            AddInterfaceTask ('shouhcrbyb',v_id,2,:new.changbb_id,'xml',v_id,:new.riq);
     elsif deleting then
            select id into v_id
            from ranlkcqk
           where ranlkcqk.riq = :old.riq and pinz='油' and changbb_id=:old.changbb_id;
           AddInterfaceTask ('shouhcrbyb',v_id,2,:old.changbb_id,'xml',v_id,:old.riq);
     elsif updating then
           if :new.fadyy<>:old.fadyy or
             :new.gongryy<>:old.gongryy or
             :new.qityy<>:old.qityy then
              select id into v_id
              from ranlkcqk
             where ranlkcqk.riq = :new.riq and pinz='油' and changbb_id=:new.changbb_id;
             AddInterfaceTask ('shouhcrbyb',v_id,2,:new.changbb_id,'xml',v_id,:new.riq);
           end if ;
     end if;
    exception
       when others then
        if inserting then
           zengjrz('trigger_haoyqkyb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_haoyqkyb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_haoyqkyb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
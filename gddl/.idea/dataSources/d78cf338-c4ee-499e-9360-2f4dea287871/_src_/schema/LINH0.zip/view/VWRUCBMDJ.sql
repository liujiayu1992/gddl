create view VWRUCBMDJ as
select to_number(to_char(f.riq,'yyyy')) nianf,to_number(to_char(f.riq,'mm')) yuef,
	fh.changbb_id,f.fahdw_id,d.jianc,
	round_new(decode(sum(f.shisl),0,0,
	sum(f.meij*f.shisl)/sum(shisl)),2) yuanmdj,
	round_new(decode(sum(f.shisl),0,0,sum(
	decode(f.farl,0,0,(f.meij+f.yunf+f.kuangyf+f.yingdyf+
	f.daozzf+f.qitzf+f.jiaohqzf+f.qiyf) *29.271/f.farl)*f.shisl)
	/sum(shisl)),2) biaomdj
	from fahgjb f,fahb fh, fahdwb d where f.fahb_id =fh.id and f.fahdw_id = d.id
	group by to_number(to_char(f.riq,'yyyy')),to_number(to_char(f.riq,'mm'))
	,fh.changbb_id,f.fahdw_id,d.jianc


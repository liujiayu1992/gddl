create PROCEDURE        "PROC_ZH_IMPORT_DATA" 
IS
BEGIN
    DECLARE
        --煤矿名称
        V_MEIKDWMC   MEIKXXB.MINGC%TYPE;
        --运输单位名称
        V_YUNSDWMC   YUNSDWB.MINGC%TYPE;
        --计划口径名称
        V_JIHKJMC    JIHKJB.MINGC%TYPE;
        --供应商名称
        V_GONGYSMC GONGYSB.MINGC%TYPE;

        --定义游标
        CURSOR CUR_V_TRUCKENTER IS
            SELECT * FROM V_TRUCKENTER 
            WHERE EWEIGHTDATE >= TO_CHAR(TRUNC(SYSDATE - 7),'YYYY-MM-DD')
              AND DOWNLOADTYPE = '燃煤'
              AND NOT EXISTS (
                 SELECT CHEPBTMP.V_TRUCKENTER_ID FROM CHEPBTMP 
                 WHERE TRUNC(QINGCSJ) >= TRUNC(SYSDATE - 7) 
                     AND CHEPBTMP.V_TRUCKENTER_ID = V_TRUCKENTER.ID
              );

    BEGIN
        DBMS_OUTPUT.PUT_LINE('-------开始导入纵横过衡数据-------');

        --导入数据到CHEPBTMP
        --循环游标
        FOR  CUR IN CUR_V_TRUCKENTER LOOP
            --执行单条数据
            BEGIN
                V_MEIKDWMC := '';
                V_YUNSDWMC := '';
                V_JIHKJMC := '';
                V_GONGYSMC := '';

                --判断煤矿编码是否存在
                SELECT MAX(MINGC) INTO V_MEIKDWMC FROM MEIKXXB WHERE ID = CUR.COLLIERYCODE;
                IF V_MEIKDWMC IS NULL THEN
                   V_MEIKDWMC := CUR.COLLIERYNAME;
                END IF;
                
                --供应商
                SELECT MAX(MINGC) INTO V_GONGYSMC FROM GONGYSB WHERE ID IN(
                       SELECT GONGYSB_ID FROM GONGYSMKGLB WHERE MEIKXXB_ID = CUR.COLLIERYCODE
                );
                IF V_GONGYSMC IS NULL THEN
                   V_GONGYSMC := V_MEIKDWMC;
                END IF;
                
                --判断运输单位编码是否存在
                SELECT MAX(MINGC) INTO V_YUNSDWMC FROM YUNSDWB WHERE ID = CUR.TRANSUNITCODE;
                IF V_YUNSDWMC IS NULL THEN
                   V_YUNSDWMC := CUR.TRANSUNITNAME;
                END IF;
                
                --计划口径名称
                SELECT MINGC INTO V_JIHKJMC FROM JIHKJB WHERE ID =(SELECT JIHKJB_ID FROM MEIKXXB WHERE ID = CUR.COLLIERYCODE);
                IF V_JIHKJMC IS NULL THEN
                   V_JIHKJMC := '市场采购';
                END IF;

                UPDATE CHEPBTMP
                SET
                    QINGCHH        =    CUR.HASHNO                                              ,        --过皮衡号
                    QINGCJJY       =    CUR.HASHUSER                                            ,        --过皮人员
                    ZHONGCSJ       =    TO_DATE(CUR.FWEIGHTIME,'YYYY-MM-DD HH24:MI:SS')         ,        --过重时间
                    ZHONGCHH       =    CUR.WEIGHNO                                             ,        --过重衡号
                    ZHONGCJJY       =    CUR.WEIGHTUSER                                          ,        --过重人员
                    LURY           =    '纵横'                                                  ,
                    BEIZ           =      ''                                                   ,            --备注
                    CAIYRQ           =     decode(CUR.TOSAMDATE,null,sysdate,TO_DATE(CUR.TOSAMDATE,'YYYY-MM-DD'))                     ,         --采样日期
                    LURSJ           =    SYSDATE                                                 ,
                    YUNSDW           =    V_YUNSDWMC                                              ,         --车队名称
                    DIANCXXB_ID       =    476                                                     ,
                    PIAOJH           =    CUR.TAKECOALNO                                          ,         --提煤单号
                    GONGYSMC       =    V_GONGYSMC                                              ,         --供应商
                    MEIKDWMC       =    V_MEIKDWMC                                              ,         --煤矿名称
                    PINZ           =    '煤'                                                    ,
                    FAZ               =    '汽'                                                    ,
                    DAOZ           =    '汽'                                                    ,
                    JIHKJ           =    V_JIHKJMC                                               ,         --计划口径
                    FAHRQ           =    TO_DATE(CUR.EWEIGHTDATE,'YYYY-MM-DD')                   ,
                    DAOHRQ           =    TO_DATE(CUR.EWEIGHTDATE,'YYYY-MM-DD')                   ,
                    CAIYBH           =    '0'                                                       ,
                    YUNSFS           =    '公路'                                                  ,
                    CHEC           =    '1'                                                     ,
                    CHEPH           =    CUR.NUMBERPLATE                                         ,         --车牌号
                    MAOZ           =    CUR.FWEIGHT/1000                                             ,         --毛重
                    PIZ               =    CUR.EWEIGHT/1000                                             ,         --皮重
                    BIAOZ           =    DECODE(nvl(CUR.COALNETWEIGHT,0),0,CUR.NETWEIGHT/1000,CUR.COALNETWEIGHT/1000)   ,         --票重，0时保存净重
                    KOUD           =    CUR.DEDCUTTON/1000                                           ,         --扣吨
                    JIANJFS           =    '过衡'                                                  ,
                    CHEBB_ID       =    3                                                       ,
                    YUANDZ           =    '汽'                                                    ,
                    YUANSHDW       =    '青铝发电'                                              ,
                    QINGCSJ           =    TO_DATE(CUR.EWEIGHTIME,'YYYY-MM-DD HH24:MI:SS')         ,         --过皮时间
                    XIECFS           =    '机械'                                                  ,
                    YUANMZ           =    CUR.FWEIGHT/1000                                             ,         --毛重
                    YUANPZ           =    CUR.EWEIGHT/1000                                             ,          --皮重
                    V_TRUCKENTER_SAMCODE = CUR.SAMCODE                                                 ,     --纵横采样码
                    fahbtmp_id       = -1
                    
                WHERE V_TRUCKENTER_ID = CUR.ID;

                DBMS_OUTPUT.PUT_LINE('更新CHEPBTMP影响的数据记录:' || SQL%ROWCOUNT);
                --如果影响的数据记录为0，插入一条数据
                IF SQL%ROWCOUNT = 0 THEN
                  INSERT INTO CHEPBTMP
                  (
                    QINGCHH                             ,
                    QINGCJJY                         ,
                    ZHONGCSJ                         ,
                    ZHONGCHH                         ,
                    ZHONGCJJY                         ,
                    LURY                             ,
                    BEIZ                             ,
                    CAIYRQ                             ,
                    LURSJ                             ,
                    YUNSDW                             ,
                    ID                                 ,
                    DIANCXXB_ID                         ,
                    PIAOJH                             ,
                    GONGYSMC                         ,
                    MEIKDWMC                         ,
                    PINZ                             ,
                    FAZ                                 ,
                    DAOZ                             ,
                    JIHKJ                             ,
                    FAHRQ                             ,
                    DAOHRQ                             ,
                    CAIYBH                             ,
                    YUNSFS                             ,
                    CHEC                             ,
                    CHEPH                             ,
                    MAOZ                             ,
                    PIZ                                 ,
                    BIAOZ                             ,
                    KOUD                             ,
                    JIANJFS                             ,
                    CHEBB_ID                         ,
                    YUANDZ                             ,
                    YUANSHDW                           ,
                    QINGCSJ                             ,
                    XIECFS                             ,
                    YUANMZ                             ,
                    YUANPZ                             ,
                    V_TRUCKENTER_ID                    ,
                    V_TRUCKENTER_SAMCODE               ,
                    fahbtmp_id
                  )
                  VALUES
                  (
                    CUR.HASHNO                                              ,        --过皮衡号
                    CUR.HASHUSER                                            ,        --过皮人员
                    TO_DATE(CUR.FWEIGHTIME,'YYYY-MM-DD HH24:MI:SS')         ,        --过重时间
                    CUR.WEIGHNO                                             ,        --过重衡号
                    CUR.WEIGHTUSER                                          ,        --过重人员                                                  ,
                    '纵横'                                                  ,
                    ''                                                     ,         --备注
                    decode(CUR.TOSAMDATE,null,sysdate,TO_DATE(CUR.TOSAMDATE,'YYYY-MM-DD'))                     ,         --采样日期
                    SYSDATE                                                 ,
                    V_YUNSDWMC                                              ,         --车队名称
                    GETNEWID(476)                                           ,
                    476                                                     ,
                    CUR.TAKECOALNO                                          ,         --提煤单号
                    V_GONGYSMC                                              ,         --供应商
                    V_MEIKDWMC                                              ,         --煤矿名称
                    '煤'                                                    ,
                    '汽'                                                    ,
                    '汽'                                                    ,
                    V_JIHKJMC                                               ,         --计划口径
                    TO_DATE(CUR.EWEIGHTDATE,'YYYY-MM-DD')                   ,         
                    TO_DATE(CUR.EWEIGHTDATE,'YYYY-MM-DD')                   ,
                    '0'                                             ,         
                    '公路'                                                  ,
                    '1'                                                     ,
                    CUR.NUMBERPLATE                                         ,         --车牌号
                    CUR.FWEIGHT/1000                                             ,         --毛重
                    CUR.EWEIGHT/1000                                             ,         --皮重
                    DECODE(nvl(CUR.COALNETWEIGHT,0),0,CUR.NETWEIGHT/1000,CUR.COALNETWEIGHT/1000)   ,         --票重，0时保存净重
                    CUR.DEDCUTTON/1000                                           ,         --扣吨
                    '过衡'                                                  ,
                    3                                                       ,
                    '汽'                                                    ,
                    '青铝发电'                                              ,                                                               
                    TO_DATE(CUR.EWEIGHTIME,'YYYY-MM-DD HH24:MI:SS')         ,         --过皮时间
                    '机械'                                                  ,
                    CUR.FWEIGHT/1000                                             ,         --毛重
                    CUR.EWEIGHT/1000                                             ,         --皮重
                    CUR.ID                                                       ,
                    CUR.SAMCODE        ,
                    -1
                  );
              END IF;
              --提交数据
              COMMIT;

            --当执行时发生异常时记录异常，并不影响下面的数据执行
            EXCEPTION  WHEN OTHERS THEN
                --回滚数据
                ROLLBACK;
                DBMS_OUTPUT.PUT_LINE('异常:' || SUBSTR(SQLERRM,1,500));
            END;

        END LOOP;

        DBMS_OUTPUT.PUT_LINE('-------结束导入纵横过衡数据-------');
    EXCEPTION  WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM,1,500));
    END;
END PROC_ZH_IMPORT_DATA;

 
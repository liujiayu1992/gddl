create function GetHuayy(zhilbid number) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_huayy zhillsb.huayy%TYPE;
   CURSOR C_huayy IS SELECT huayy FROM zhillsb  where zhilb_id in(zhilbid);

   BEGIN
       OPEN C_huayy;
       loop
           FETCH C_huayy INTO v_huayy;
                 if C_huayy%FOUND then
                    Result:=Result||v_huayy||',';
                 end if;
                 EXIT WHEN C_huayy%NOTFOUND;
           end loop;
           CLOSE C_huayy;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end GetHuayy;

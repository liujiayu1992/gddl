create view VWYUANSHDW as
select id,mingc from shouhdwb union
select id,mingc from diancxxb where jib=3

 

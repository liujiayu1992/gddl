create trigger TR_INSERT_RIGJB_YUNSFS
	before insert
	on RIGJB
	for each row
Declare
  v_Fahb_Id     Number := 0;
  v_Fahb_Yunsfs Varchar2(20) := '';
Begin
  v_Fahb_Id := :New.Id;
  Select Yunsfs Into v_Fahb_Yunsfs From Fahb Where Id = v_Fahb_Id;
  :New.Yunsfs := v_Fahb_Yunsfs;
Exception
  When Others Then
    :New.Yunsfs := '火运';
End Tr_Insert_Rigjb_Yunsfs;
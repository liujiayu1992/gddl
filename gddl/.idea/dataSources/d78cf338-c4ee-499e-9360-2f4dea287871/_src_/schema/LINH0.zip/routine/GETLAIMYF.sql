create Function getLAIMYF (MEIKID Number,FAZID Varchar2,RIQ1 Varchar2,RIQ2 Varchar2)
       Return Varchar2 Is
Begin
    Declare
      v_yuef Varchar2(1000) :='';
      v_loopcounter Integer :=1;
      Cursor my_cursor Is
         Select Distinct to_char(c.guohsj,'MM') As mingc
          From fahb f,chepb c
          Where f.Id = c.fahb_id
          And f.meikxxb_id =MEIKID--小康
          And f.faz_id = FAZID--大青
          And c.guohsj Between to_date(RIQ1,'yyyy-mm-dd hh24:mi:ss')
          And to_date(RIQ2,'yyyy-mm-dd hh24:mi:ss') + 1
          Order By to_char(c.guohsj,'MM') ;
      my_rec my_cursor%Rowtype;
    Begin

      Open my_cursor;
        Loop
          Fetch my_cursor Into my_rec;
            Exit When my_cursor%Notfound;
          If substr(my_rec.mingc,1,1) = '0' Then
             my_rec.mingc := substr(my_rec.mingc,2,1);
          End If;

          If v_loopcounter = 1 Then
            v_yuef := my_rec.mingc||'月';
          Else
            v_yuef := v_yuef|| ',' ||my_rec.mingc||'月';
          End If;
          v_loopcounter := v_loopcounter + 1;
        End Loop;
      Close my_cursor;
      Return v_yuef;
    End;
End;

create FUNCTION        "GETDAOHRQ" (strriq STRING, strbanz STRING,strmk STRING) RETURN varchar2 AS
RESULT VARCHAR2(200);
begin
     declare
     xl varchar2(10);
     rq VARCHAR2(200);
     i NUMBER(2);
     CURSOR c_dhrq IS select to_char(f.daohrq,'yyyy/mm/dd') INTO xl
            from fahhybzb h,fahb f,meikxxb m
            WHERE h.riq = to_date(strriq,'yyyy-mm-dd')
            AND banzm = strbanz AND h.fahb_id = f.id AND f.meikxxb_id = m.id
            AND m.mingc = strmk;
     BEGIN
       OPEN c_dhrq;
         i := 0;
       LOOP

         FETCH c_dhrq INTO rq;
           IF c_dhrq%FOUND THEN
             IF i=0 THEN
                RESULT := RESULT||rq;
             ELSIF i>0 THEN
                 RESULT := RESULT||'.'|| substr(rq,length(rq)-1,length(rq));
             END IF;
           END IF;
           i := i+1;
           EXIT WHEN c_dhrq%NOTFOUND;
       END LOOP;
       CLOSE c_dhrq;
       RETURN RESULT;
END;
END getDaohrq;

 
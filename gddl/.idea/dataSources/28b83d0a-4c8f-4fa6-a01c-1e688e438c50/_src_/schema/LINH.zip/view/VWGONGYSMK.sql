create view VWGONGYSMK as
select l.diancxxb_id,g.id,g.mingc,1 lx from gongysb g, gongysdcglb l
where g.id = l.gongysb_id and g.leix = 1 and zhuangt=1
union select l.diancxxb_id,m.id,m.mingc,0 lx
from meikxxb m, gongysb g, gongysdcglb l, gongysmkglb ml
where g.id = l.gongysb_id  and g.id = ml.gongysb_id
and m.id = ml.meikxxb_id and g.leix = 1

 

create FUNCTION GETQICKCLJ(P_YUETJKJB_ID NUMBER) RETURN NUMBER IS
BEGIN
  DECLARE
    L_QICKC NUMBER;

  BEGIN
    L_QICKC := 0;
    BEGIN
      SELECT QICKC
        INTO L_QICKC
        FROM (SELECT KJ.ID
                FROM YUETJKJB KJ,
                     (SELECT RIQ,
                             DIANCXXB_ID,
                             GONGYSB_ID,
                             JIHKJB_ID,
                             PINZB_ID,
                             YUNSFSB_ID
                        FROM YUETJKJB
                       WHERE ID = P_YUETJKJB_ID) KJ2
               WHERE KJ.DIANCXXB_ID = KJ2.DIANCXXB_ID
                 AND KJ.GONGYSB_ID = KJ2.GONGYSB_ID
                 AND KJ.JIHKJB_ID = KJ2.JIHKJB_ID
                 AND KJ.PINZB_ID = KJ2.PINZB_ID
                 AND KJ.YUNSFSB_ID = KJ2.YUNSFSB_ID
                 AND KJ.RIQ = TRUNC(KJ2.RIQ, 'y')) YKJ,
             YUEHCB HC
       WHERE HC.YUETJKJB_ID = YKJ.ID
         AND HC.FENX = '累计';
    EXCEPTION
      WHEN OTHERS THEN
        RETURN L_QICKC;
    END;

    RETURN L_QICKC;

  END;
END GETQICKCLJ;

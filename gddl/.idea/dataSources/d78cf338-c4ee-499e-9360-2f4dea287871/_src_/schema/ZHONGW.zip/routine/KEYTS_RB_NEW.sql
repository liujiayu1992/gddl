create function keyts_rb_new(lngDiancxxb_id in number,datRiq date,lngjb in number) return number is

  Result number(10,2);

begin

    declare

        begin

             if lngjb =1 then

                select decode(rijhm,0,0,round(nvl(kuc,0)/(rijhm),1))  into Result

                from

                 (select sum(kuc) as kuc,sum(keyts_rijhm_new(lngDiancxxb_id,haoyqkdr,datriq,lngjb)) as rijhm

                        from shouhcrbb s,vwdianc d where s.diancxxb_id=d.id

                        and d.rlgsid=lngDiancxxb_id

                        and s.riq=datRiq) rb;

                return Result;

             elsif lngjb=2 then

                select decode(rijhm,0,0,round(nvl(kuc,0)/(rijhm),1))  into Result

                from

                 (select sum(kuc) as kuc,sum(keyts_rijhm_new(lngDiancxxb_id,haoyqkdr,datriq,lngjb)) as rijhm

                        from shouhcrbb s,vwdianc d where s.diancxxb_id=d.id

                        and (d.fgsid=lngDiancxxb_id or d.shangjgsid=lngDiancxxb_id)

                        and s.riq=datRiq) rb;

                return Result;

             elsif lngjb=3 then

                select decode(rijhm,0,0,round(nvl(kuc,0)/(rijhm),1))  into Result

                from

                 (select sum(kuc) as kuc,sum(keyts_rijhm_new(lngDiancxxb_id,haoyqkdr,datriq,lngjb)) as rijhm

                        from shouhcrbb s,vwdianc d where s.diancxxb_id=d.id

                        and s.diancxxb_id=lngDiancxxb_id

                        and s.riq=datRiq) rb;

                return Result;

             end if;

        end;

end keyts_rb_new;

create view VWCHEPB as
Select
f.Id As fahb_id,z.Id As zhilb_id,c.Id As chepb_id,f.diancxxb_id,f.changbb_id,
f.jihkjb_id,f.fahdwb_id,f.meikxxb_id,f.ranlpzb_id,f.faz_id,f.daoz_id,c.Cheph,c.Ches,
c.Xuh,f.Daohrq,f.Fahrq,c.Guohsj,z.Caiysj,z.Huaysj,z.Bianh,z.Huaybh,
nvl(c.Biaoz,0)+nvl(c.Yingd,0)-nvl(c.Kuid,0)-nvl(c.Koud,0)-nvl(c.Kouz,0) As shissl,
nvl(c.maoz,0) As maoz,nvl(c.Piz,0) As piz,nvl(c.Biaoz,0) As biaoz,nvl(c.Yingd,0) As yingd,
nvl(c.Kuid,0) As kuid,nvl(c.Koud,0) As koud,nvl(c.Kouz,0) As kouz,nvl(c.Koussl,0) As koussl,
z.farl As qnet,z.shoudjhf As aar,z.ganzjhf As ad,z.huiff As vdaf,
z.quansf As mt,z.liuf As stad,z.kongqgzjhf As aad,z.kongqgzjsf As mad,
z.dantrl As qbad,z.kongqgzjq As had,z.kongqgzjhff As vad,
z.ganzjl As std,z.hdaf,z.jijsf,z.jijfrl,
f.Hedbz As shulshzt,c.Hedbz As chepshzt,z.shenhzt,z.shangjshzt
From fahb f,chepb c,zhilb z
Where f.Id = c.Fahb_Id
And f.Zhilb_Id = z.Id


create FUNCTION get_qicjjy (m_jianmsj VARCHAR2) return VARCHAR2 is
begin
    declare
      renys VARCHAR2(4000) :='';
      v_loopcounter integer :=1;
      CURSOR my_cursor IS
 select distinct q.jianjy as lury
	from qichjjbtmp q, meikdqb dq, meikxxb m, ranlpzb r, zhilb z
 where q.meikdqb_id = dq.id(+)
	 and q.meikxxb_id = m.id(+)
	 and q.ranlpzb_id = r.id(+)
	 and to_char(q.jianmsj, 'yyyy-mm-dd') = m_jianmsj;
      my_rec my_cursor%ROWTYPE;
    begin
      OPEN my_cursor;
        LOOP
          FETCH my_cursor INTO my_rec;
            EXIT WHEN my_cursor%NOTFOUND;
            IF v_loopcounter = 1 THEN
              renys := my_rec.lury;
            ELSE
                renys := renys||','||my_rec.lury;
            END IF;
          v_loopcounter := v_loopcounter + 1;
        END LOOP;
      CLOSE my_cursor;
      RETURN renys;
    END;
END;

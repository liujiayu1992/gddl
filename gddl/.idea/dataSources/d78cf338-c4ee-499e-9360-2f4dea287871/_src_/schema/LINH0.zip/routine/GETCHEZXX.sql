create FUNCTION getChezxx (fahdwbid NUMBER,riq varchar2) return VARCHAR2 is
begin
    declare
      fazs VARCHAR2(1000) :='';
      v_loopcounter integer :=1;
      CURSOR my_cursor IS
       select distinct faz
         from yunsjhb
         where fahdwb_id=fahdwbid
         and riq=riq;
      my_rec my_cursor%ROWTYPE;
    begin

      OPEN my_cursor;
        LOOP
          FETCH my_cursor INTO my_rec;
            EXIT WHEN my_cursor%NOTFOUND;
          IF v_loopcounter = 1 THEN
            fazs := my_rec.faz;
          ELSE
            fazs := fazs|| ',' ||my_rec.faz;
          END IF;
          v_loopcounter := v_loopcounter + 1;
        END LOOP;
      CLOSE my_cursor;
      RETURN fazs;
    END;
END;

create trigger TRIGGER_HAOYQKMB
	before insert or update or delete
	on HAOYQKMB
	for each row
Declare
Begin

     if inserting then
        if :new.banz<>'合计' then
        AddInterfaceTask ('meihyb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);
        end if;
     elsif deleting then
        if :old.banz<>'合计' then
        AddInterfaceTask ('meihyb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);
        end if;
     elsif updating then
        if :new.banz<>'合计' then
        AddInterfaceTask ('meihyb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
        end if;
     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_haoyqkmb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_haoyqkmb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_haoyqkmb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
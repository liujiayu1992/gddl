create FUNCTION getChepsj(var_jiesb_id in number,cans in number)--名称:车皮数据:参数为：参数,0:净重1,运损2,运输方式3,赢吨4亏吨
	Return  number as
	begin
	     declare
       numresult number;
	     var_jingz number;
       var_yuns number;
       var_yunsfsb_id number;
       var_yingd number;
       var_kuid number;
             begin
          select nvl(sum(jingz),0)jingz,nvl(sum(yuns),0)yuns,nvl(max(yunsfsb_id),0)yunsfsb_id,nvl(sum(yingd),0)yingd,nvl(sum(kuid),0)kuid into var_jingz,var_yuns,var_yunsfsb_id,var_yingd,var_kuid
          from(
          select round(sum(chepb.maoz-chepb.piz)) jingz, round(sum(chepb.yuns))yuns,max(yunsfsb.id) yunsfsb_id,round(sum(chepb.yingd))yingd,round(sum(chepb.kuid))kuid
          from chepb,fahb,yunsfsb
          where chepb.jiesb_id=var_jiesb_id and chepb.fahb_id=fahb.id and fahb.yunsfs=yunsfsb.mingc
          group by chepb.fahb_id);

          if cans=0 then
             numresult:=var_jingz;
          elsif  cans=1 then
             numresult:=var_yuns;
          elsif cans=2 then
             numresult:=var_yunsfsb_id;
          elsif cans=3 then
             numresult:=var_yingd;
          else
             numresult:=var_kuid;
          end if;
	         return numresult;
         exception
             when others then return 0;
	     end;
	end;
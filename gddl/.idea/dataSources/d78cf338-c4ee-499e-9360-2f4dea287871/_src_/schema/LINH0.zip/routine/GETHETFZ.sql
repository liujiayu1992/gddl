create Function getHETFZ (HETID Number)
       Return Varchar2 Is r_faz Varchar2(500);
Begin

    Select '''' || Replace(Faz, ',', '''' || ',' || '''') || '''' Into r_faz
    From Nianjhhtb h
    Where h.Hetxxb_Id = HETID;
  Return(r_faz);
End getHETFZ;

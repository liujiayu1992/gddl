create view VWKUCMLFX as
select k.nianf,k.yuef,k.changbb_id,zhuangjrl,rijhm,rijhm*7 as jingjx,
	xianfhkc*10000 xianfhkc,zuidkc*10000 zuidkc,nvl(k.shijkc,0) as shijkc,nvl(k.sj,0) as sj ,
	nvl(decode(rijhm,0,0,null,0,floor(k.shijkc/rijhm)),0) as khyts
	from diancxxb, (select nianf,yuef,changbb_id,shijkc
	,round_new(decode(tshijkc,0,0,null,0,(shijkc-tshijkc)*100/tshijkc),2) sj
	from (select nianf,yuef,changbb_id,shijkc,(select t.shijkc from yuedfxsj t
	where t.nianf+1=nianf and t.yuef =yuef and t.changbb_id = changbb_id) tshijkc
	from yuedfxsj)) k


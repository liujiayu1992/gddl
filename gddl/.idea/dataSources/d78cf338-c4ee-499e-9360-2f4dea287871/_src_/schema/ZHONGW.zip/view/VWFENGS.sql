create view VWFENGS as
select id,mingc,xuh from diancxxb where jib=2


create trigger TRIGGER_HETZLXYB
	before insert or update or delete
	on HETZLXYB
	for each row
Declare
      v_id          hetxxb.changbb_id%Type;

Begin

     if inserting then
          select changbb_id into v_id from hetxxb h
           where h.id=:new.hetxxb_id;
          AddInterfaceTask ('hetzlb',:new.id,0,v_id,'xml',:new.id,sysdate);

     elsif deleting then
          select changbb_id into v_id from hetxxb h
           where h.id=:old.hetxxb_id;
          AddInterfaceTask ('hetzlb',:old.id,1,v_id,'xml',:old.id,sysdate);

     elsif updating then
          select changbb_id into v_id from hetxxb h
           where h.id=:new.hetxxb_id;
          AddInterfaceTask ('hetzlb',:new.id,2,v_id,'xml',:new.id,sysdate);

     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_hetzlxyb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_hetzlxyb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_hetzlxyb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
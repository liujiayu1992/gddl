create view VWQICHJJ as
select q.id, q.cheph, q.chengydw, q.meikdqb_id,
	q.meikxxb_id, q.ranlpzb_id, q.jihkjb_id, q.zhuangt,zhilb_id,
	q.meicb_id, q.changbb_id, q.meigy, q.jianmsj as daohrq,q.jianmsj as jianmsj, q.jianpsj,
	to_date(to_char(q.jianmsj,'yyyy-mm-dd'),'yyyy-mm-dd') jianmrq,
	case  when to_char(jianmsj,'HH24')
	< nvl((select zhi from xitxxb where shifsy=1
	and duixm='汽车衡采样分组时间' ),0) then 'am'
	else 'pm' end sj  from qichjjbtmp q


create view VWDAOZ as
select id,jianc, lujxxb_id from v_chezxxb
union
select g.gangkou_id,g.gangkoumc,0 as zhuguanlj  from w_gangkouxx g


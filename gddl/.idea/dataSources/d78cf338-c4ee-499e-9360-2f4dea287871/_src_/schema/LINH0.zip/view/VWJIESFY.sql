create view VWJIESFY as
select j.id
       ,j.jiessl
       ,j.meikxxb_id
       ,j.yansrl
       ,j.jiasje
       ,j.tielyf
       ,j.kuangqyf
       ,j.zaf
       ,0 as qiyf
       ,j.jiaksk
       ,j.yunfsk
       ,j.yunfsl
       ,j.jiaksl
       ,j.jiasje+j.tielyf+j.kuangqyf+j.zaf+j.jiaksk+j.yunfsk as daoczhj_hs
       ,j.jiasje+j.tielyf+j.kuangqyf+j.zaf as daoczhj_bhs
       ,round((j.jiasje+j.tielyf+j.kuangqyf+j.zaf+j.jiaksk+j.yunfsk)/j.jiessl,7) as danj_hs
       ,round((j.jiasje+j.tielyf+j.kuangqyf+j.zaf)/j.jiessl,7) as danj_bhs
       from jiesb j


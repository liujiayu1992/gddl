create view VWQIYCYFZFS as
select f.diancxxb_id, f.gongysb_id, f.meikxxb_id, f.pinzb_id, f.faz_id,
       f.jihkjb_id, f.fahrq, f.daohrq, f.zhilb_id, c.caiyrq caiyrq, f.chec, f.beiz
       from fahb f,caiyb c
       where f.zhilb_id = c.zhilb_id and f.yunsfsb_id = 2
       union
       select q.diancxxb_id,q.gongys_id,q.meikxxb_id,q.pinz_id,1,q.kouj_id
       ,q.riq fahrq,q.riq daohrq,q.zhilb_id,q.riq caiyrq,q.chec, q.beiz from qicrjhb q
       where q.zhilb_id != 0


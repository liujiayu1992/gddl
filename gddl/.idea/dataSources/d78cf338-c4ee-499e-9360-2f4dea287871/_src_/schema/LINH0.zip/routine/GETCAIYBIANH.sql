create function GetCaiyBianh(zhilbid number) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_caiybh zhilbtmp.caiybh%TYPE;
   CURSOR C_caiybh IS SELECT leib||':'||caiybh FROM zhilbtmp where zhilb_id=zhilbid;

   BEGIN
       OPEN C_caiybh;
       loop
           FETCH C_caiybh INTO v_caiybh;
                 if C_caiybh%FOUND then
                    Result:=Result||v_caiybh||',';
                 end if;
                 EXIT WHEN C_caiybh%NOTFOUND;
           end loop;
           CLOSE C_caiybh;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end GetCaiyBianh;

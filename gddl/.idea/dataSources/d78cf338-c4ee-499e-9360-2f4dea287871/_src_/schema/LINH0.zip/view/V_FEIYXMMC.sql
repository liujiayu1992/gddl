create view V_FEIYXMMC as
Select Distinct c.Tuosbh,x.Feiymc
From chepb c,Danjcpb d,Feiyb f,Feiyxmb x
Where  d.Chepb_Id = c.Id
And d.Yunfdjb_Id = f.Yunfdjb_Id
And f.Feiyxmb_Id = x.Id
And c.Tuosbh Is Not Null
And c.Jiesb_Id != 0
And f.Shuib = 1
With Read Only


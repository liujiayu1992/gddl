create view VWRUCBMDJGYBHQK as
select  v.nianf,v.changbb_id,v.jianc,
	(select biaomdj from vwrucbmdj where nianf = v.nianf and yuef = 1
	and changbb_id = v.changbb_id and fahdw_id = v.fahdw_id) Jan,
	(select biaomdj from vwrucbmdj where nianf = v.nianf and yuef = 2
	and changbb_id = v.changbb_id and fahdw_id = v.fahdw_id) Feb,
	(select biaomdj from vwrucbmdj where nianf = v.nianf and yuef = 3
	and changbb_id = v.changbb_id and fahdw_id = v.fahdw_id) Mar,
	(select biaomdj from vwrucbmdj where nianf = v.nianf and yuef = 4
	and changbb_id = v.changbb_id and fahdw_id = v.fahdw_id) Apr,
	(select biaomdj from vwrucbmdj where nianf = v.nianf and yuef = 5
  and changbb_id = v.changbb_id and fahdw_id = v.fahdw_id) May,
  (select biaomdj from vwrucbmdj where nianf = v.nianf and yuef = 6
  and changbb_id = v.changbb_id and fahdw_id = v.fahdw_id) Jun,
  (select biaomdj from vwrucbmdj where nianf = v.nianf and yuef = 7
  and changbb_id = v.changbb_id and fahdw_id = v.fahdw_id) Jul,
  (select biaomdj from vwrucbmdj where nianf = v.nianf and yuef = 8
  and changbb_id = v.changbb_id and fahdw_id = v.fahdw_id) Aug,
  (select biaomdj from vwrucbmdj where nianf = v.nianf and yuef = 9
  and changbb_id = v.changbb_id and fahdw_id = v.fahdw_id) Sep,
  (select biaomdj from vwrucbmdj where nianf = v.nianf and yuef = 10
  and changbb_id = v.changbb_id and fahdw_id = v.fahdw_id) Oct,
  (select biaomdj from vwrucbmdj where nianf = v.nianf and yuef = 11
  and changbb_id = v.changbb_id and fahdw_id = v.fahdw_id) Nov,
  (select biaomdj from vwrucbmdj where nianf = v.nianf and yuef = 12
  and changbb_id = v.changbb_id and fahdw_id = v.fahdw_id) Dec
  from (select distinct nianf,changbb_id,jianc,fahdw_id from vwrucbmdj) v


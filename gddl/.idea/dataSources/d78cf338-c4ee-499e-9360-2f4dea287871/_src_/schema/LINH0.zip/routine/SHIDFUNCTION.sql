create function shidFunction (nian varchar2,yue1 varchar2,yue2 varchar2,changbbid varchar2)
return shidtab as
l_tab_emp2 shidtab:= shidtab();
begin
select shidrow(fahdwb_id,shidl)
bulk collect into l_tab_emp2
from(
select fahdwb_id,(sum(biaoz) + sum(yingd) - sum(kuid))shidl
          from(
              select gonghs.fahdwb_id,round_new(sum(chepb.biaoz),0)biaoz ,round_new(sum(chepb.yingd),0)yingd,
              round_new(sum(chepb.kuid),0)kuid
              from fahb,
              (Select h.Id As meijb_id, v.Id As fahdwb_id
From Hetxxb h,Vwfahdwqc v
Where h.Meikdqfdw_Id = v.Id)
              gonghs ,chepb ,meikxxb
              where gonghs.meijb_id = fahb.meijb_id
                 and chepb.fahb_id=fahb.id
                 and to_char(chepb.guohsj,'YYYY')=nian
                 and to_number(to_char(chepb.guohsj,'MM'))>=yue1
                 and to_number(to_char(chepb.guohsj,'MM'))<=yue2
                 and fahb.changbb_id=changbbid
                 and fahb.hedbz=1
                 and fahb.meikxxb_id=meikxxb.id
                 and meikxxb.tongjbz=1
              group by gonghs.fahdwb_id,fahb.zhilb_id)
          group by fahdwb_id);
   return l_tab_emp2;
end;

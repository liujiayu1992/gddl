create trigger TR_ZHILBTMP_UPDATE_DELETE
	before update or delete
	on ZHILBTMP
	for each row
Declare
      v_zhilbtmp_id  Zhilbtmp_LOG.Zhilbtmp_Id%Type;
      v_zhilb_id  ZHILBTMP_LOG.zhilb_id%Type;
      v_caiysj  ZHILBTMP_LOG.caiysj%Type;
      v_caiybh  ZHILBTMP_LOG.caiybh%Type;
      v_lury1  ZHILBTMP_LOG.lury1%Type;
      v_caiyry  ZHILBTMP_LOG.caiyry%Type;
      v_caiyfs  ZHILBTMP_LOG.caiyfs%Type;
      v_beiz1  ZHILBTMP_LOG.beiz1%Type;
      v_huaybh  ZHILBTMP_LOG.huaybh%Type;
      v_huaysj  ZHILBTMP_LOG.huaysj%Type;
      v_farl  ZHILBTMP_LOG.farl%Type;
      v_shoudjhf  ZHILBTMP_LOG.shoudjhf%Type;
      v_ganzjhf  ZHILBTMP_LOG.ganzjhf%Type;
      v_ganzwhjhff  ZHILBTMP_LOG.ganzwhjhff%Type;
      v_quansf  ZHILBTMP_LOG.quansf%Type;
      v_kongqgzjl  ZHILBTMP_LOG.kongqgzjl%Type;
      v_kongqgzjhf  ZHILBTMP_LOG.kongqgzjhf%Type;
      v_kongqgzjsf  ZHILBTMP_LOG.kongqgzjsf%Type;
      v_dantrl  ZHILBTMP_LOG.dantrl%Type;
      v_kongqgzjq  ZHILBTMP_LOG.kongqgzjq%Type;
      v_kongqgzjhff  ZHILBTMP_LOG.kongqgzjhff%Type;
      v_konggjt  ZHILBTMP_LOG.konggjt%Type;
      v_ganzjl  ZHILBTMP_LOG.ZHILBtmp_id%Type;
      v_huird  ZHILBTMP_LOG.huird%Type;
      v_ganzjgwrz  ZHILBTMP_LOG.ganzjgwrz%Type;
      v_huayy  ZHILBTMP_LOG.huayy%Type;
      v_lury2  ZHILBTMP_LOG.lury2%Type;
      v_beiz2  ZHILBTMP_LOG.beiz2%Type;
      v_shenhzt  ZHILBTMP_LOG.shenhzt%Type;
      v_shenhry  ZHILBTMP_LOG.shenhry%Type;
      v_leib  ZHILBTMP_LOG.leib%Type;
      v_fcad  ZHILBTMP_LOG.fcad%Type;
      v_hdaf  ZHILBTMP_LOG.hdaf%Type;
      v_daybz  ZHILBTMP_LOG.daybz%Type;
      v_ganzwhjgwrz  ZHILBTMP_LOG.ganzwhjgwrz%Type;
      v_sdaf  ZHILBTMP_LOG.sdaf%Type;
      v_shangjshzt ZHILBTMP_LOG.shangjshzt%Type;
      v_shenhrq ZHILBTMP_LOG.Shenhrq%Type;
      v_ischange Boolean;
      v_leix Varchar2(10);
Begin
      If deleting Then
          v_ischange :=True;
          v_zhilbtmp_id := :Old.Id;
          v_zhilb_id := :Old.zhilb_id;
          v_caiysj := :Old.caiysj;
          v_caiybh := :Old.caiybh;
          v_lury1 := :Old.lury1;
          v_caiyry := :Old.caiyry;
          v_caiyfs := :Old.caiyfs;
          v_beiz1 := :Old.beiz1;
          v_huaybh := :Old.huaybh;
          v_huaysj := :Old.huaysj;
          v_farl := :Old.farl;
          v_shoudjhf := :Old.shoudjhf;
          v_ganzjhf := :Old.ganzjhf;
          v_ganzwhjhff := :Old.ganzwhjhff;
          v_quansf:= :Old.quansf;
          v_kongqgzjl := :Old.kongqgzjl;
          v_kongqgzjhf := :Old.kongqgzjhf;
          v_kongqgzjsf := :Old.kongqgzjsf;
          v_dantrl := :Old.dantrl;
          v_kongqgzjq := :Old.kongqgzjq;
          v_kongqgzjhff := :Old.kongqgzjhff;
          v_konggjt := :Old.konggjt;
          v_ganzjl := :Old.ganzjl;
          v_huird := :Old.huird;
          v_ganzjgwrz := :Old.ganzjgwrz;
          v_huayy := :Old.huayy;
          v_lury2 := :Old.lury2;
          v_beiz2 := :Old.beiz2;
          v_shenhzt := :Old.shenhzt;
          v_shenhry := :Old.shenhry;
          v_leib := :Old.leib;
          v_fcad := :Old.fcad;
          v_hdaf := :Old.hdaf;
          v_daybz := :Old.daybz;
          v_ganzwhjgwrz := :Old.ganzwhjgwrz;
          v_sdaf := :Old.sdaf;
          v_shangjshzt := :Old.shangjshzt;
          v_shenhrq := :Old.shenhrq;
          v_leix := 'Delete';
      Elsif updating Then
            v_ischange :=False;
            v_zhilbtmp_id := :New.Id;
            v_zhilb_id := :New.zhilb_id;
            v_caiysj := :New.caiysj;
            v_caiybh := :New.caiybh;
            v_lury1 := :New.lury1;
            v_caiyry := :New.caiyry;
            v_caiyfs := :New.caiyfs;
            v_beiz1 := :New.beiz1;
            v_huaybh := :New.huaybh;
            v_huaysj := :New.huaysj;
            v_farl := :New.farl;
            v_shoudjhf := :New.shoudjhf;
            v_ganzjhf := :New.ganzjhf;
            v_ganzwhjhff := :New.ganzwhjhff;
            v_quansf:= :New.quansf;
            v_kongqgzjl := :New.kongqgzjl;
            v_kongqgzjhf := :New.kongqgzjhf;
            v_kongqgzjsf := :New.kongqgzjsf;
            v_dantrl := :New.dantrl;
            v_kongqgzjq := :New.kongqgzjq;
            v_kongqgzjhff := :New.kongqgzjhff;
            v_konggjt := :New.konggjt;
            v_ganzjl := :New.ganzjl;
            v_huird := :New.huird;
            v_ganzjgwrz := :New.ganzjgwrz;
            v_huayy := :New.huayy;
            v_lury2 := :New.lury2;
            v_beiz2 := :New.beiz2;
            v_shenhzt := :New.shenhzt;
            v_shenhry := :New.shenhry;
            v_leib := :New.leib;
            v_fcad := :New.fcad;
            v_hdaf := :New.hdaf;
            v_daybz := :New.daybz;
            v_ganzwhjgwrz := :New.ganzwhjgwrz;
            v_sdaf := :New.sdaf;
            v_shangjshzt := :New.shangjshzt;
            v_shenhrq := :New.shenhrq;
            If v_zhilbtmp_id != :Old.Id Then
            	v_ischange := True ;
            Elsif v_zhilb_id != :Old.zhilb_id Then
            	v_ischange := True ;
            Elsif v_caiysj != :Old.caiysj Then
            	v_ischange := True ;
            Elsif v_caiybh != :Old.caiybh Then
            	v_ischange := True ;
            Elsif v_lury1 != :Old.lury1 Then
            	v_ischange := True ;
            Elsif v_caiyry != :Old.caiyry Then
            	v_ischange := True ;
            Elsif v_caiyfs != :Old.caiyfs Then
            	v_ischange := True ;
            Elsif v_beiz1 != :Old.beiz1 Then
            	v_ischange := True ;
            Elsif v_huaybh != :Old.huaybh Then
            	v_ischange := True ;
            Elsif v_huaysj != :Old.huaysj Then
            	v_ischange := True ;
            Elsif v_farl != :Old.farl Then
            	v_ischange := True ;
            Elsif v_shoudjhf != :Old.shoudjhf Then
            	v_ischange := True ;
            Elsif v_ganzjhf != :Old.ganzjhf Then
            	v_ischange := True ;
            Elsif v_ganzwhjhff != :Old.ganzwhjhff Then
            	v_ischange := True ;
            Elsif v_quansf!= :Old.quansf Then
            	v_ischange := True ;
            Elsif v_kongqgzjl != :Old.kongqgzjl Then
            	v_ischange := True ;
            Elsif v_kongqgzjhf != :Old.kongqgzjhf Then
            	v_ischange := True ;
            Elsif v_kongqgzjsf != :Old.kongqgzjsf Then
            	v_ischange := True ;
            Elsif v_dantrl != :Old.dantrl Then
            	v_ischange := True ;
            Elsif v_kongqgzjq != :Old.kongqgzjq Then
            	v_ischange := True ;
            Elsif v_kongqgzjhff != :Old.kongqgzjhff Then
            	v_ischange := True ;
            Elsif v_konggjt != :Old.konggjt Then
            	v_ischange := True ;
            Elsif v_ganzjl != :Old.ganzjl Then
            	v_ischange := True ;
            Elsif v_huird != :Old.huird Then
            	v_ischange := True ;
            Elsif v_ganzjgwrz != :Old.ganzjgwrz Then
            	v_ischange := True ;
            Elsif v_huayy != :Old.huayy Then
            	v_ischange := True ;
            Elsif v_lury2 != :Old.lury2 Then
            	v_ischange := True ;
            Elsif v_beiz2 != :Old.beiz2 Then
            	v_ischange := True ;
            Elsif v_shenhzt != :Old.shenhzt Then
            	v_ischange := True ;
            Elsif v_shenhry != :Old.shenhry Then
            	v_ischange := True ;
            Elsif v_leib != :Old.leib Then
            	v_ischange := True ;
            Elsif v_fcad != :Old.fcad Then
            	v_ischange := True ;
            Elsif v_hdaf != :Old.hdaf Then
            	v_ischange := True ;
            Elsif v_daybz != :Old.daybz Then
            	v_ischange := True ;
            Elsif v_ganzwhjgwrz != :Old.ganzwhjgwrz Then
            	v_ischange := True ;
            Elsif v_sdaf != :Old.sdaf Then
            	v_ischange := True ;
            Elsif v_shangjshzt != :Old.shangjshzt Then
            	v_ischange := True ;
            Elsif v_shenhrq != :Old.shenhrq Then
            	v_ischange := True ;
            End If;
            v_leix := 'Update';
      Else
          Return;
      End If;

      If v_ischange Then

        Insert Into zhilbtmp_log
          (Id, zhilbtmp_id, zhilb_id, caiysj, caiybh, lury1, caiyry, caiyfs, beiz1, huaybh, huaysj,
          farl, shoudjhf, ganzjhf, ganzwhjhff, quansf, kongqgzjl, kongqgzjhf, kongqgzjsf, dantrl,
          kongqgzjq, kongqgzjhff, konggjt, ganzjl, huird, ganzjgwrz, huayy, lury2, beiz2, shenhzt,
          shenhry, leib, fcad, hdaf, daybz, ganzwhjgwrz, sdaf, shangjshzt, shenhrq, leix)
        Values
          (Xl_Zhilbtmp_Id.Nextval, v_zhilbtmp_id, v_zhilb_id, v_caiysj, v_caiybh, v_lury1, v_caiyry, v_caiyfs, v_beiz1, v_huaybh, v_huaysj,
          v_farl, v_shoudjhf, v_ganzjhf, v_ganzwhjhff, v_quansf, v_kongqgzjl, v_kongqgzjhf, v_kongqgzjsf, v_dantrl,
          v_kongqgzjq, v_kongqgzjhff, v_konggjt, v_ganzjl, v_huird, v_ganzjgwrz, v_huayy, v_lury2, v_beiz2, v_shenhzt,
          v_shenhry, v_leib, v_fcad, v_hdaf, v_daybz, v_ganzwhjgwrz, v_sdaf, v_shangjshzt, v_shenhrq, v_leix);
      End If;
End;

create trigger TRIGGER_FAHB
	before insert or update or delete
	on FAHB
	for each row
DECLARE

  V_SJ       CHEPB.GUOHSJ%TYPE;
  V_MEIJB_ID FAHB.MEIJB_ID%TYPE;----2011年11月16日 Qiuzw
BEGIN
  --接口用
  SELECT MIN(GUOHSJ)
    INTO V_SJ
    FROM CHEPB C
   WHERE C.FAHB_ID = :NEW_VALUE.ID;

  IF INSERTING THEN
    SELECT MIN(GUOHSJ)
      INTO V_SJ
      FROM CHEPB C
     WHERE C.FAHB_ID = :OLD_VALUE.ID;
    ----2011年11月16日 Qiuzw
    -- 查找匹配的合同
    V_MEIJB_ID := MATCHHET(:NEW_VALUE.FAHDWB_ID,
                           :NEW_VALUE.MEIKXXB_ID,
                           :NEW_VALUE.RANLPZB_ID,
                           :NEW_VALUE.JIHKJB_ID,
                           :NEW_VALUE.FAZ_ID,
                           TRUNC(:NEW_VALUE.FAHRQ));
   :NEW_VALUE.MEIJB_ID:=V_MEIJB_ID;
   ----------------------------------------------------------------
    ADDINTERFACETASK('fahb',
                     :NEW_VALUE.ID,
                     0,
                     :NEW_VALUE.CHANGBB_ID,
                     'xml',
                     :NEW_VALUE.ID,
                     V_SJ);

  ELSIF DELETING THEN

    ADDINTERFACETASK('fahb',
                     :OLD_VALUE.ID,
                     1,
                     :OLD_VALUE.CHANGBB_ID,
                     'xml',
                     :OLD_VALUE.ID,
                     :OLD_VALUE.DAOHRQ);

  ELSIF UPDATING THEN
    SELECT MIN(GUOHSJ)
      INTO V_SJ
      FROM CHEPB C
     WHERE C.FAHB_ID = :NEW_VALUE.ID;
    ----2011年11月16日 Qiuzw
    --需要检查新值和旧值直接是否有变化，如果关键值发生变化，需要重新计算合同id，否则不用
    --------------------请补充这里
    IF (:NEW_VALUE.FAHDWB_ID <> :OLD_VALUE.FAHDWB_ID OR
       :NEW_VALUE.MEIKXXB_ID <> :OLD_VALUE.MEIKXXB_ID OR
       :NEW_VALUE.RANLPZB_ID <> :OLD_VALUE.RANLPZB_ID OR
       :NEW_VALUE.JIHKJB_ID <> :OLD_VALUE.JIHKJB_ID OR
       :NEW_VALUE.FAZ_ID <> :OLD_VALUE.FAZ_ID OR
       TRUNC(:NEW_VALUE.FAHRQ) <> TRUNC(:OLD_VALUE.FAHRQ)) THEN

      -- 查找匹配的合同
      V_MEIJB_ID := MATCHHET(:NEW_VALUE.FAHDWB_ID,
                             :NEW_VALUE.MEIKXXB_ID,
                             :NEW_VALUE.RANLPZB_ID,
                             :NEW_VALUE.JIHKJB_ID,
                             :NEW_VALUE.FAZ_ID,
                             TRUNC(:NEW_VALUE.FAHRQ));
     :NEW_VALUE.MEIJB_ID:=V_MEIJB_ID;
    END IF;
    ----------------------------------------------------------------------
    IF :NEW_VALUE.ID <> :OLD_VALUE.ID OR
       :NEW_VALUE.FAHDWB_ID <> :OLD_VALUE.FAHDWB_ID OR
       :NEW_VALUE.MEIKXXB_ID <> :OLD_VALUE.MEIKXXB_ID OR
       :NEW_VALUE.JIHKJB_ID <> :OLD_VALUE.JIHKJB_ID OR
       :NEW_VALUE.FAHRQ <> :OLD_VALUE.FAHRQ OR
       :NEW_VALUE.DAOHRQ <> :OLD_VALUE.DAOHRQ OR
       :NEW_VALUE.CHEC <> :OLD_VALUE.CHEC OR
       :NEW_VALUE.FAZ_ID <> :OLD_VALUE.FAZ_ID OR
       :NEW_VALUE.DAOZ_ID <> :OLD_VALUE.DAOZ_ID OR
       :NEW_VALUE.CHANGBB_ID <> :OLD_VALUE.CHANGBB_ID OR
       :NEW_VALUE.YUNSFS <> :OLD_VALUE.YUNSFS OR
       :NEW_VALUE.RANLPZB_ID <> :OLD_VALUE.RANLPZB_ID OR
       :NEW_VALUE.SHENHSJ <> :OLD_VALUE.SHENHSJ OR
       :NEW_VALUE.SHENHRY <> :OLD_VALUE.SHENHRY THEN
      ADDINTERFACETASK('fahb',
                       :NEW_VALUE.ID,
                       2,
                       :NEW_VALUE.CHANGBB_ID,
                       'xml',
                       :NEW_VALUE.ID,
                       NVL(V_SJ, :OLD_VALUE.DAOHRQ));
      RETURN;
    END IF;

    IF :OLD_VALUE.HEDBZ <> :NEW_VALUE.HEDBZ THEN
      ADDINTERFACETASK('fahb',
                       :NEW_VALUE.ID,
                       3,
                       :NEW_VALUE.CHANGBB_ID,
                       '修改hedbz',
                       :NEW_VALUE.ID,
                       NVL(V_SJ, :OLD_VALUE.DAOHRQ));
    END IF;

    IF :NEW_VALUE.KUANGFZLB_ID <> :OLD_VALUE.KUANGFZLB_ID THEN
      ADDINTERFACETASK('fahb',
                       :NEW_VALUE.ID,
                       3,
                       :NEW_VALUE.CHANGBB_ID,
                       '修改kuangfzlb_id',
                       :NEW_VALUE.KUANGFZLB_ID,
                       NVL(V_SJ, :OLD_VALUE.DAOHRQ));
    END IF;

    IF :NEW_VALUE.MEIJB_ID <> :OLD_VALUE.MEIJB_ID THEN
      ADDINTERFACETASK('fahb',
                       :NEW_VALUE.ID,
                       3,
                       :NEW_VALUE.CHANGBB_ID,
                       '修改meijb_id',
                       :NEW_VALUE.MEIJB_ID,
                       NVL(V_SJ, :OLD_VALUE.DAOHRQ));
    END IF;

    IF :NEW_VALUE.JIHKJB_ID <> :OLD_VALUE.JIHKJB_ID THEN
      ADDINTERFACETASK('fahb',
                       :NEW_VALUE.ID,
                       3,
                       :NEW_VALUE.CHANGBB_ID,
                       '修改jihkjb_id',
                       :NEW_VALUE.JIHKJB_ID,
                       NVL(V_SJ, :OLD_VALUE.DAOHRQ));
    END IF;

    IF :NEW_VALUE.ZHILB_ID <> :OLD_VALUE.ZHILB_ID THEN
      ADDINTERFACETASK('fahb',
                       :NEW_VALUE.ID,
                       3,
                       :NEW_VALUE.CHANGBB_ID,
                       '修改zhilb_id',
                       :NEW_VALUE.ZHILB_ID,
                       NVL(V_SJ, :OLD_VALUE.DAOHRQ));
    END IF;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    IF INSERTING THEN
      ZENGJRZ('trigger_fahb', :NEW_VALUE.ID, '增加', SQLCODE, SQLERRM);
    ELSIF DELETING THEN
      ZENGJRZ('trigger_fahb', :OLD_VALUE.ID, '删除', SQLCODE, SQLERRM);
    ELSE
      ZENGJRZ('trigger_fahb', :OLD_VALUE.ID, '修改', SQLCODE, SQLERRM);
    END IF;
END;

create FUNCTION        "GETDECRYPTSTR" (varPassword in Blob) return varchar2
 as language java name 'Util.getDecryptStr(oracle.sql.BLOB) return String';

 
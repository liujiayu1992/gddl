create view VWKUIDKKSPFX as
select to_number(to_char(j.jiesrq,'yyyy')) nianf,to_number(to_char(j.jiesrq,'mm')) yuef,
	j.jiesbm,case when sum(j.yingk)>0  then 0 else abs(sum(j.yingk)) end as kuid
	,case when sum(j.yingk)>0  then 0 else round_new(abs(sum(j.yingk*j.shulzjbz)),3) end as kuidje
	,case when sum(j.yingk)>0  then 0 else round_new(abs(sum(shulzjje)),3) end as dsuopje
	,case when sum(j.yingk)>0  then 0 else round_new(abs(decode(
	sum(j.yingk*j.shulzjbz),0,0,sum(shulzjje*100)/sum(j.yingk*j.shulzjbz))),3) end as kuidspv
	,case when sum(j.yansrl-j.relxx)>0 then 0 else abs(sum(j.yansrl-j.relxx)) end as kuik
	,case when sum(j.yansrl-j.relxx)>0 then 0 else round_new(abs(sum(j.relzjje)),3) end as kuikje
	,case when sum(j.yansrl-j.relxx)>0 then 0 else round_new(abs(sum(j.relzjje)),3) end as ksuopje
	,case when sum(j.yansrl-j.relxx)>0 then 0 else 100 end as kuikspv from jiesb j
	group by (to_number(to_char(j.jiesrq,'yyyy')),to_number(to_char(j.jiesrq,'mm')),j.jiesbm)


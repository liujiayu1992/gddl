create FUNCTION f_getnearlydata (orgidata IN NUMBER,biaoz IN VARCHAR2,scale IN NUMBER
    )
RETURN  NUMBER AS
BEGIN
	DECLARE
		v_nearlydata NUMBER;

		BEGIN
      IF biaoz IS not NULL THEN
        IF biaoz = 'JW' THEN
          SELECT ceil(orgidata) AS val
          INTO v_nearlydata
          FROM dual;
        ELSIF biaoz = 'SQ' THEN
          SELECT floor(orgidata) AS val
          INTO v_nearlydata
          FROM dual;
        ELSIF biaoz = 'JD' THEN
          SELECT Trunc(orgidata) AS val
          INTO v_nearlydata
          FROM dual;
        ELSE
          SELECT Round(orgidata,scale) AS val
          INTO v_nearlydata
          FROM dual;
        END IF;
      ELSE
        v_nearlydata := orgidata;
      END IF;
			RETURN  v_nearlydata;
		EXCEPTION WHEN OTHERS THEN
			RETURN orgidata;
		END;
END;

create Function f_getKuangqyf(meikid Number,riq Varchar2,leix Varchar2) Return number Is
BEGIN
  --参数类型的含义：
        --C, "按车计价"
        --其他, "默认按吨计价"
    Declare
      danj Number :=0;
      Cursor my_cursor Is
        Select nvl(yuan_che,0) As chedj,nvl(yuan_dun,0) As dundj
        From kuangqyfb ky
        Where ky.meik_id = meikid
        And zhixrq <= to_date(riq,'yyyy-mm-dd')
        And Rownum = 1;
      my_rec my_cursor%Rowtype;
    Begin
      Open my_cursor;
        Loop
          Fetch my_cursor Into my_rec;
            Exit When my_cursor%Notfound;
            If leix = 'C' Then
              danj := my_rec.chedj;
            Else
              danj := my_rec.dundj;
            End If;
        End Loop;
      Close my_cursor;
      Return danj;
    End;
End;

create PROCEDURE        "UPDCPBYMP" (driq in date,diancxxbid in number
,yunsfs in varchar2 )
is begin
    declare
    jhid number;
    mkid number;
    pzid number;
    ysdwid number;
    mk varchar2(50);
    pz varchar2(50);
    ysdw varchar2(50);
    Cursor cur_p is
           select distinct p.meikxxb_id,p.pinzb_id,p.yunsdwb_id,c.meikdwmc,c.pinz,c.yunsdw
                    from chepbtmp c, qicjhppb p
                    where c.meikdwmc = p.meikdwmc and c.pinz = p.pinz
                    			and c.yunsdw = p.yunsdw and c.qicrjhb_id = -1
                          and p.diancxxb_id= c.diancxxb_id  and c.diancxxb_id = diancxxbid
			                    and c.daohrq= driq and (c.yunsfs = yunsfs or yunsfs = '全部');

     begin
            OPEN cur_p;
            LOOP
                 FETCH cur_p INTO mkid,pzid,ysdwid,mk,pz,ysdw;
            EXIT when cur_p%NOTFOUND;
                 select nvl(max(id),0) into jhid from qicrjhb q where q.meikxxb_id =mkid
                 and q.pinz_id = pzid and q.yunsdwb_id = ysdwid and q.riq = driq
                 and q.diancxxb_id = diancxxbid;

                 if jhid <> 0 then
                    update chepbtmp set qicrjhb_id = jhid where meikdwmc = mk
                    and pinz = pz and yunsdw = ysdw and qicrjhb_id = -1 and daohrq= driq
                    and diancxxb_id = diancxxbid;

                 end if;
            END LOOP;
            CLOSE cur_p;
    end;
end;

 
create view VWFENX_TONGQBQ as
select 1 as xhu, decode(1,1,'同期') as fenx from dual
  union
  select 2 as xhu,decode(1,1,'本期') as fenx from dual

 

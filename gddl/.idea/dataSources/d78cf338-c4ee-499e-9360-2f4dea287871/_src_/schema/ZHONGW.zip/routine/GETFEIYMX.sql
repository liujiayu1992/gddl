create function GetFeiymx(fyzid number) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   mingc feiymcb.mingc%TYPE;
   CURSOR p_mingc IS select fymc.mingc||':'||fy.zhi||'  '
                    from feiyb fy,feiyxmb fyxm,feiymcb fymc
                    where fy.feiyxmb_id = fyxm.id
                          and fyxm.feiymcb_id = fymc.id
                          and fy.id = fyzid
                    order by fymc.mingc;
   BEGIN
       OPEN p_mingc;
       loop
           FETCH p_mingc INTO mingc;
                 if p_mingc%FOUND then
                    Result:=Result||mingc;
                 end if;
                 EXIT WHEN p_mingc%NOTFOUND;
           end loop;
           CLOSE p_mingc;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end GetFeiymx;

create function GetChepRizjj(rizid number) return varchar2 is
  Result varchar2(2000);
begin
   DECLARE
   v_jj varchar2(2000);
   CURSOR C_jj IS SELECT caozy||':'||to_char(caozsj,'yyyy-mm-dd hh24:mi:ss') FROM rizb where biaoid = rizid;
   BEGIN
       OPEN C_jj;
       loop
           FETCH C_jj INTO v_jj;
                 if C_jj%FOUND then
                    Result:=Result||v_jj||',';
                 end if;
                 EXIT WHEN C_jj%NOTFOUND;
           end loop;
           CLOSE C_jj;
           if Length(Result)>0 then
            Result:=substr(Result,0,Length(Result)-1);
           end if;
          return(Result);
   END;
end GetChepRizjj;

create Function f_getDaozzf(fahid Number,leix Number) Return Number Is
Begin
     --参数类型的含义：
        --1, "吨"
        --2, "车"
        --3, "批次"
    Declare
      danj Number :=0;
      Cursor my_cursor Is
        Select zhi
        From daozzfb z,zafxmb x
        Where z.zafxmb_id = x.Id
        And x.xingz = 1
        And jieszt = 1
        And jijfs = leix
        And fahb_id = fahid;
      my_rec my_cursor%Rowtype;
    Begin
      Open my_cursor;
        Loop
          Fetch my_cursor Into my_rec;
            Exit When my_cursor%Notfound;
            danj := my_rec.zhi;
        End Loop;
      Close my_cursor;
      Return danj;
    End;
End;

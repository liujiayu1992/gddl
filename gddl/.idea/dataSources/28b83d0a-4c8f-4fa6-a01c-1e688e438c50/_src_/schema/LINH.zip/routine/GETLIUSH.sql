create FUNCTION        "GETLIUSH" (lursj in date)
	Return  varchar2 as
	begin
       declare
	     intXuh number;
	     begin
            select nvl(max(c.xuh),0)+1 into intXuh from chepxhb c where to_char(c.riq,'yyyy-mm-dd') = to_char(lursj,'yyyy-mm-dd');
	          if intXuh = 1 then
               insert into chepxhb values(lursj,intXuh);
            else
                update chepxhb set xuh = intXuh where to_char(riq,'yyyy-mm-dd') = to_char(lursj,'yyyy-mm-dd');
            end if;
            return to_char(lursj,'yymmddhh24mi') || trim(to_char(intXuh,'000'));
	     end;
	end;

 
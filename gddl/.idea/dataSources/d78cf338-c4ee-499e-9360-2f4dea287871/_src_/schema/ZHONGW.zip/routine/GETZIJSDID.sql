create function GetZijsdid(jiesb_id in long) return varchar2 is
  Result varchar2(200);
begin
  DECLARE
  v_id  varchar2(40);
   CURSOR C_Jiesid IS

             select id from
                 (select id from jiesb
                       where fuid=jiesb_id
                       union
                select id from jiesyfb
                       where fuid=jiesb_id);

       BEGIN
           OPEN C_Jiesid;
           loop
               FETCH C_Jiesid INTO v_id;
                     if C_Jiesid%FOUND then
                        Result:=Result||v_id||',';
                     end if;
                     EXIT WHEN C_Jiesid%NOTFOUND;
               end loop;
               CLOSE C_Jiesid;
               if Length(Result)>0 then
                  Result:=substr(Result,0,Length(Result)-1);
               end if;
              return(Result);
       END;

  return(Result);
end getzijsdid;

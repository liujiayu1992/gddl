create trigger TRIGGER_RULMZLB
	before insert or update or delete
	on RULMZLB
	for each row
begin
  if deleting and :old.shenhzt=3 then
     AddInterfaceTask ('rulmzlb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.rulrq);
  elsif updating then
      if :old.shenhzt<>:new.shenhzt and :new.shenhzt=3 then
          AddInterfaceTask ('rulmzlb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.rulrq);
      elsif :old.shenhzt=3 and :old.shenhzt<>:new.shenhzt then
          AddInterfaceTask ('rulmzlb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.rulrq);
      elsif :old.shenhzt=3  then
          AddInterfaceTask ('rulmzlb',:old.id,2,:old.changbb_id,'xml',:old.id,:old.rulrq);
      end if;
  elsif inserting and :new.shenhzt=3 then
 	  AddInterfaceTask ('rulmzlb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.rulrq);
  end if;
 exception
 when others then
        if inserting then
           zengjrz('trigger_rulmzlb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_rulmzlb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_rulmzlb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
create trigger TRIGGER_HETJSXYB
	before insert or update or delete
	on HETJSXYB
	for each row
Declare
      v_id          hetxxb.changbb_id%Type;

Begin

     if inserting then
     select changbb_id into v_id from hetxxb h
      where h.id=:new.hetxxb_id;
          if :new.biaoz=0 then
             AddInterfaceTask ('hetjgb',:new.id,0,v_id,'xml',:new.id,sysdate);
          elsif :new.biaoz=1 then
             AddInterfaceTask ('hetzkkb',:new.id,0,v_id,'xml',:new.id,sysdate);
          end if;

     elsif deleting then
     select changbb_id into v_id from hetxxb h
      where h.id=:old.hetxxb_id;
          if :old.biaoz=0 then
              AddInterfaceTask ('hetjgb',:old.id,1,v_id,'xml',:old.id,sysdate);
          elsif :old.biaoz=1 then
              AddInterfaceTask ('hetzkkb',:old.id,1,v_id,'xml',:old.id,sysdate);
          end if;

     elsif updating then
     select changbb_id into v_id from hetxxb h
      where h.id=:new.hetxxb_id;
          if :new.biaoz=0 then
              AddInterfaceTask ('hetjgb',:new.id,2,v_id,'xml',:new.id,sysdate);
          elsif :new.biaoz=1 then
              AddInterfaceTask ('hetzkkb',:new.id,2,v_id,'xml',:new.id,sysdate);
          end if;

     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_hetjsxyb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_hetjsxyb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_hetjsxyb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
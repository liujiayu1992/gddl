create Function getDiancId_Fuid(SonDiancID In number)
Return  number as
begin
     declare
     diancid number;
     begin
     select fuid into diancid from diancxxb dc where dc.id=SonDiancID;
     return diancid;
     end;
End;

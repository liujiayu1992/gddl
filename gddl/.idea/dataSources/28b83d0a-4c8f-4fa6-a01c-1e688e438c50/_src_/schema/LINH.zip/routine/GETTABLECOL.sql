create FUNCTION        "GETTABLECOL" (TableName in varchar2, GetColName in varchar2, ColName in varchar2, Value in varchar2) return varchar2 is

  Result varchar2(200);



  Resvalue varchar2(200);

begin

  execute immediate ' select to_char('|| GetColName ||') from '||TableName||' where '||ColName||'='''||Value||''''

         into Resvalue;

         if not (Resvalue is null)  then



            Result:=Resvalue;

         else



            Result:='';

         end if;

  return(Result);

end getTableCol;

 
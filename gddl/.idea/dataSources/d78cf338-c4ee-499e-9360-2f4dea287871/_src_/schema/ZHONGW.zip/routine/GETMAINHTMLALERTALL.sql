create function getMainHtmlAlertAll(leix in varchar2,PagePath in varchar2,PageName in varchar2, ParameterName in varchar2, Parameter in varchar2,StrValue in varchar2,Fabrq in varchar2,BiaotSize in number) return varchar2 is
  Result varchar2(200);
  begin
         declare
                strTitle varchar2(100);
         begin
           strTitle := StrValue;
           if (StrValue is null or StrValue='()') then
               Result:='';
           elsif leix='main' then
                 Result:='<a target=_blank title='||strTitle||Fabrq||' href='||PagePath||'/app?service=page/'||PageName||'&'||ParameterName||'='||Parameter||'>'||StrValue||Fabrq||'</a>';
            else
                 Result:='<a target=_blank title='||strTitle||Fabrq||' href='||PagePath||'/app?service=page/'||PageName||'&'||ParameterName||'='||Parameter||'>'||StrValue||Fabrq||'</a>';
             end if;
           return(Result);
         end;
end getMainHtmlAlertAll;

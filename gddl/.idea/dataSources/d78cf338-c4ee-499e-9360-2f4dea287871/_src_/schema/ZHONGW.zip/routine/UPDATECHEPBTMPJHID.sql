create Procedure updateChepbtmpjhid(dhrq in date,diancxxbid in number)
is begin
    declare
    jhid number;
    cpid number;
    cheh chepbtmp.cheph%type;
    jjsj date;
    Cursor cur is
           select c.id,c.cheph,c.qingcsj,getRiJhid(dhrq,c.cheph,c.qingcsj,diancxxbid) jid from chepbtmp c
           where c.daohrq = dhrq and c.diancxxb_id = diancxxbid
           and qicrjhb_id = -1 order by c.qingcsj;
     begin
            OPEN cur;
            LOOP
                 FETCH cur INTO cpid,cheh,jjsj,jhid;
            EXIT when cur%NOTFOUND;
                 if jhid <> 0 then
                    update chepbtmp set qicrjhb_id = jhid where id = cpid;
                 end if;
            END LOOP;
            CLOSE cur;
    end;
end;

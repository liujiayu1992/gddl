create FUNCTION        "GETCHAZ" (chuanr IN NUMBER)
  return NUMBER is Result NUMBER(15,2);

BEGIN

   DECLARE
    v_xiax KAOHBZB.xiax%TYPE;
   CURSOR C_xiax IS select k.xiax xiax from KAOHBZB k where k.shangx > chuanr and k.xiax<=chuanr;
   begin


OPEN C_xiax;
    loop
           FETCH C_xiax INTO v_xiax;
                 if C_xiax%FOUND  then

                    Result:=chuanr-v_xiax;


                 end if;
                 EXIT WHEN C_xiax%NOTFOUND;
           end loop;
           CLOSE C_xiax;
           --if Length(Result)>0 then
           -- Result:=substr(Result,0,Length(Result)-1);
          -- end if;
          return(Result) ;
   END;
   return Result; --chuanr;
end getchaz;

 
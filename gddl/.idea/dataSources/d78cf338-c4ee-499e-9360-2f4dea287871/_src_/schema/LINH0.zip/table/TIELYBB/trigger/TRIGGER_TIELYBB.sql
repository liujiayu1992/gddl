create trigger TRIGGER_TIELYBB
	before insert or update or delete
	on TIELYBB
	for each row
Begin

     if inserting then
          AddInterfaceTask ('tielyb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);

     elsif deleting then
          AddInterfaceTask ('tielyb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);

     elsif updating then

           if :new.lujxxb_id<>:old.lujxxb_id or
              :new.chezxxb_id<>:old.chezxxb_id or
              :new.ches<>:old.ches or
              :new.banjh<>:old.banjh
            then
              AddInterfaceTask ('tielyb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
           end if ;
     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_tielybb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_tielybb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_tielybb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
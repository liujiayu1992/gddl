create FUNCTION        "GETHUAYHBL" (stad in number,hstad in number,tiaozz in number) return number is
  Result number(15,10);
begin
if stad <=hstad then return stad;
else
  result:=stad;
  loop
  result:=result-tiaozz;
  exit when result <=hstad;
  end loop;
  return result;
end if;
end GetHuayhbl;

 
create trigger TRIGGER_HETXXB
	before insert or update or delete
	on HETXXB
	for each row
BEGIN
    --审核情况下删除增加都能发出指令；审核状态下修改也能发出指令；审核回退都能发出指令；
  if inserting and :new.shenhbz=1 then
      AddInterfaceTask ('hetb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.qiandrq);
      AddInterfaceTask ('hetfujb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.qiandrq);
  elsif  deleting and :old.shenhbz=1   then
      AddInterfaceTask ('hetb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.qiandrq);
      AddInterfaceTask ('hetfujb',:new.id,1,:new.changbb_id,'xml',:new.id,:new.qiandrq);
  elsif  updating   then
      if :old.shenhbz<>:new.shenhbz and :new.shenhbz=1 then
          AddInterfaceTask ('hetb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.qiandrq);
          AddInterfaceTask ('hetfujb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.qiandrq);
      elsif :old.shenhbz<>:new.shenhbz and :new.shenhbz=0 then
          AddInterfaceTask ('hetb',:old.id,2,:old.changbb_id,'xml',:old.id,:old.qiandrq);
          AddInterfaceTask ('hetfujb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.qiandrq);
      elsif :old.shenhbz=1 then
          AddInterfaceTask ('hetb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.qiandrq);
          AddInterfaceTask ('hetfujb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.qiandrq);
      end if;
  end if;
  exception
  when others then
      if inserting then
         zengjrz('trigger_hetxxb',:new.id,'增加',SQLCODE,SQLERRM);
      elsif deleting  then
         zengjrz('trigger_hetxxb',:old.id,'删除',SQLCODE,SQLERRM);
      else
         zengjrz('trigger_hetxxb',:old.id,'修改',SQLCODE,SQLERRM);
      end if;
End;

create package ofs_compress is
  function is_active return boolean;
  procedure comp(src in     blob,
                 dst in out nocopy blob);
  function uncomp(src in blob) return blob;
  procedure uncomp(src in     blob,
                   dst in out nocopy blob);
end;

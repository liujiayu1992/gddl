create function getJiesFarl(lngJiesb_id number) return integer is
  Result integer;
begin
  select jies into Result
  from  jieszbsjb
  where id=(select max(id) from jieszbsjb where jiesdid=lngJiesb_id
  and zhibb_id =(select max(id ) from zhibb where mingc='收到基低位热值')
  )
  ;
  return(Result);
end getJiesFarl;

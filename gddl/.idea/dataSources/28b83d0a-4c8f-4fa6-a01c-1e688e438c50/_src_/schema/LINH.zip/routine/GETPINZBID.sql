create FUNCTION        "GETPINZBID" (strPinzName In varchar2)
Return  number as
begin
     declare
     pinzbid number;
     begin
     select max(id) into pinzbid from pinzb p where p.leib='煤' and p.mingc=strPinzName;
     return pinzbid;
     end;
End;

 
create Function f_Getjihkjmc(Jihkjb_Id In Number)
  Return Varchar2 Is
  Strmc Varchar2(50);
Begin

  Select j.Mingc Into Strmc From Jihkjb j Where Id = Jihkjb_Id;

  Return(Strmc);
End f_Getjihkjmc;

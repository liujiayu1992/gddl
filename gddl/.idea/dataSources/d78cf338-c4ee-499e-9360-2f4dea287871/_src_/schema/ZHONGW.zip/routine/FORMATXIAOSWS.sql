create FUNCTION Formatxiaosws (chuanrr IN NUMBER,weis in number)
  return varchar2 is Result varchar2(2000);

BEGIN

   DECLARE


      i number(15,2);
      j number(15,2);
      f number(15,2);
      chuanr varchar2(50);
   begin

      i:=0;
      j:=0;
      f:=0;
    f:=instr(to_char(chuanrr),'-');
   -- dbms_output.put_line(chuanrr);
     -- dbms_output.put_line(f);
--1、符号处理
    IF f>0 --小数以零开始的转换
       THEN
       --负数  截取负号后数据
       chuanr:=substr(to_char(chuanrr),2);
       Result :=  to_char(chuanr);
           --dbms_output.put_line(chuanr);
          --   dbms_output.put_line(4);
    ELSIF f=0--有小数点但是位数不够
      THEN

      --正数

      chuanr:=to_char(chuanrr);
      Result :=  to_char(chuanr);
      --dbms_output.put_line(chuanr);
    END IF;
--2、小数点后面数据位处理
      IF instr(to_char(chuanr),'.') = 0--没有小数点

      THEN

         Result :=  to_char(chuanr)||'.';--增加小数点  concat(chuanr,'.')
         loop

           j:=j+1;
            --dbms_output.put_line(Result);
           Result := concat(Result,'0');
           -- dbms_output.put_line(Result);
           if j >= weis then--循环次数
              exit;
           end if;

         end loop;

      ELSIF instr(to_char(chuanr),'.') > 0 and LENGTH(to_char(chuanr))-instr(to_char(chuanr),'.') <= (weis-1)--有小数点但是位数不够
      THEN
      --dbms_output.put_line(LENGTH(to_char(chuanr))-instr(to_char(chuanr),'.'));
           Result :=to_char(chuanr);
     --dbms_output.put_line(Result);
             loop
             i:=i+1;
             Result := concat(Result,'0');


             if i>=(weis-LENGTH(to_char(chuanr))+instr(to_char(chuanr),'.')) then
                 exit;
             end if;
             end loop;
      ELSIF instr(to_char(chuanr),'.') > 0 and LENGTH(to_char(chuanr))-instr(to_char(chuanr),'.') = weis
          THEN
          Result :=to_char(chuanr);
     --dbms_output.put_line(Result);



      END IF;

--3、小数点前面"0"的处理

      IF instr(Result,'.') = 1--小数以零开始的转换

       THEN

           Result := '0'||Result;
       -- dbms_output.put_line(Result);
        -- dbms_output.put_line(100);
      END IF;

      IF f>0 --小数以零开始的转换

       THEN

           Result := '-'||substr(Result,1);
       END IF;
   END;
     --  dbms_output.put_line(Result);
       -- dbms_output.put_line(100);
   return Result; --chuanr;
end;

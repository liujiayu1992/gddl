create FUNCTION        "FC_JJFX_ZB" (strBegrq in varchar2,strEndrq in varchar2,
           strDiancxxbId in varchar2)
  return   table_export_objects
  AS
  RETURN(
        select * from
           (select sum(nvl(yuezbb.fadl,0)) as fadl_by
           from yuezbb,diancxxb
               where diancxxb_id=diancxxb.id
                   and riq>=to_date(strBegrq,'yyyy-MM-dd')
                   and riq<=to_date(strEndrq,'yyyy-MM-dd')
                   and fenx='本月'
                   and diancxxb_id=strEndrq
                   )benyzb,
        (select sum(nvl(yuezbb.fadl,0)) as fadl_lj
           from yuezbb,diancxxb
               where diancxxb_id=diancxxb.id
                   and riq>=to_date(strBegrq,'yyyy-MM-dd')
                   and riq<=to_date(strEndrq,'yyyy-MM-dd')
                   and fenx='累计'
                   and diancxxb_id=strEndrq
                   )leijzb,
        (select sum(nvl(yuezbb.fadl,0)) as fadl_sy
           from yuezbb,diancxxb
               where diancxxb_id=diancxxb.id
                   and riq>=add_months(to_date(strBegrq,'yyyy-MM-dd'),-1)
                   and riq<=add_months(to_date(strEndrq,'yyyy-MM-dd'),-1)
                   and fenx='本月'
                   and diancxxb_id=strEndrq
                   )shangyzb,
        (select sum(nvl(yuezbb.fadl,0)) as fadl_tq
           from yuezbb,diancxxb
               where diancxxb_id=diancxxb.id
                   and riq>=add_months(to_date(strBegrq,'yyyy-MM-dd'),-12)
                   and riq<=add_months(to_date(strEndrq,'yyyy-MM-dd'),-12)
                   and fenx='累计'
                   and diancxxb_id=strEndrq
                   )tongqzb
   )
   end SalesByStore

 
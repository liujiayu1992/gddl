create view V_CHEZXXB as
select c.id,c.jianc as jianc,to_number(c.lujxxb_id) As lujxxb_id from chezxxb c


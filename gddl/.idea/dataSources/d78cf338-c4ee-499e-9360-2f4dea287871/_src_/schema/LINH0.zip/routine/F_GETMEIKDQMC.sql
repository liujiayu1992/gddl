create Function f_Getmeikdqmc(fahdwb_id Number)
       return varchar2 is
begin
    declare
    Value1 varchar2(100);
    begin
       select meikdqmc into Value1 from meikdqb where id = fahdwb_id;
       return Value1;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         dbms_output.put_line('no record and id='||to_char(fahdwb_id));
         Value1 := to_char('合计');
         return Value1;
      WHEN OTHERS THEN
         dbms_output.put_line('no record and id='||to_char(fahdwb_id));
         Value1:= to_char(fahdwb_id);
         return Value1;
    end;
end f_Getmeikdqmc;

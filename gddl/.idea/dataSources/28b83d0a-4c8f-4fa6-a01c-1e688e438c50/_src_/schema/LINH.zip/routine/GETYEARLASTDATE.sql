create FUNCTION        "GETYEARLASTDATE" (datDate in date) return date is
  Result date;
begin
  return to_date(to_char(datdate,'yyyy') ||'-12-31','yyyy-mm-dd');
end getYearLastDate;

 
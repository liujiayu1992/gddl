create Function f_Shouhcrb_Shenhzt(Changb_Id In Number,
                                              Haoyrq In Date)
  Return Number Is Result Number;
Begin
  Select r.Zhuangt
    Into Result
    From Shouhcrbmb r
   Where r.Changbb_Id = Changb_Id
     And r.Riq = Haoyrq
     And r.Zhuangt = 1;
  Return Result;
Exception
  When No_Data_Found Then
    Return 0;
  When Others Then
    Return 1;
End f_Shouhcrb_Shenhzt;

create FUNCTION        "GETHUAYFZ4ZL" (zhilbId long)  return varchar2 is
       Result varchar2(2000);
-- 根据质量id 得到发货信息
  begin
      declare
      tmp varchar2(500);
      cursor fah is
          select distinct c.mingc
                 from fahb f,chezxxb c
          where f.zhilb_id = zhilbId and f.faz_id = c.id;
      begin
          open fah;
               loop
                     fetch fah into tmp;
                     EXIT when fah%NOTFOUND;
                     if Result is null then
                        Result:=tmp;
                     Else
                        Result:=Result||','||tmp;
                     end if;
               end loop;
          close fah;
      end;
      if Result is null then
         Result := '';
      end if;
      return(Result);
  end getHuayFz4zl;

 
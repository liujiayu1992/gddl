create FUNCTION        "GETBIAOZ" (chuanr IN NUMBER,chuan IN varchar2)
  --return varchar2 is Result varchar2(2000);
return number is Result number(15,4);
BEGIN

   DECLARE
    v_biaoz KAOHBZB.biaoz%TYPE;
   CURSOR C_biaoz IS select k.biaoz biaoz from KAOHBZB k,item it where k.shangx > chuanr and k.xiax<=chuanr and k.kaohxm_id=it.id and it.bianm=chuan;
   begin


OPEN C_biaoz;
    loop
           FETCH C_biaoz INTO v_biaoz;
                 if C_biaoz%FOUND --and instr(to_char(v_biaoz),'.') =1
                 then

                    --Result:=Result||'0'||v_biaoz||',';
                     Result:=v_biaoz;
                    --elsif C_biaoz%FOUND and instr(to_char(v_biaoz),'.') >1
                   -- then
                   --  Result:=Result||v_biaoz||',';
                 end if;
                 EXIT WHEN C_biaoz%NOTFOUND;
           end loop;
           CLOSE C_biaoz;
           --if Length(Result)>0 then
            --Result:=substr(Result,0,Length(Result)-1);
           --end if;
          return(Result);
   END;
   return Result; --chuanr;
end getbiaoz;

 
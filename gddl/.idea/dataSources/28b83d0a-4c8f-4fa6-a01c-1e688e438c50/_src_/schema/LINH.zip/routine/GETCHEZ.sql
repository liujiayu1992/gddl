create FUNCTION        "GETCHEZ" (mid number) return varchar2 is
  Result varchar2(2000);
begin
  DECLARE
    v_mingc chezxxb.mingc%TYPE;
    CURSOR C_chezxxb IS
      select cz.quanc
        from kuangzglb kgl, chezxxb cz
       where kgl.meikxxb_id = mid
         and cz.id = kgl.chezxxb_id
         and cz.leib = '车站';
  BEGIN
    OPEN C_chezxxb;
    loop
      FETCH C_chezxxb
        INTO v_mingc;
      if C_chezxxb%FOUND then
        Result := Result || v_mingc || ',';
      end if;
      EXIT WHEN C_chezxxb%NOTFOUND;
    end loop;
    CLOSE C_chezxxb;
    if Length(Result) > 0 then
      Result := substr(Result, 0, Length(Result) - 1);
    end if;
    return(Result);
  END;
end GetChez;

 
create trigger TRG_JK_BASICDATA
	before insert
	on JK_BASICDATA
	for each row
declare
  -- local variables here
begin
  select Seq_Jk_Basicdata.Nextval into :new.id from dual;
end trg_jk_basicdata;


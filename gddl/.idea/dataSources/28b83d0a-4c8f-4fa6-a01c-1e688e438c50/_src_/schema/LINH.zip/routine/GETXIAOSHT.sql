create FUNCTION        "GETXIAOSHT" (jiesbid number) return varchar2 is
  Result varchar2(100);
begin
   DECLARE
   xiaosht hetb.hetbh%TYPE;
   CURSOR p_xiaosht IS select distinct h.hetbh||' '||g.mingc||' '||min(jg.jij) as xx
                        from jiesb j,hetb h,gongysb g,hetjgb jg
                        where j.gongysb_id = h.gongysb_id
                              and j.jihkjb_id = h.jihkjb_id
                              and h.gongysb_id = g.id
                              and jg.hetb_id = h.id
                              and j.yansksrq>=h.qisrq
                              and j.yansjzrq<=h.guoqrq
                              and h.leib = 1
                              and j.id = jiesbid
                        group by h.id,h.hetbh,g.mingc;
   BEGIN
       OPEN p_xiaosht;
       loop
           FETCH p_xiaosht INTO xiaosht;
                 if p_xiaosht%FOUND then
                    Result:=xiaosht;
                 end if;
                 EXIT WHEN p_xiaosht%NOTFOUND;
           end loop;
       CLOSE p_xiaosht;
       return(Result);
   END;
end GetXiaosht;

 
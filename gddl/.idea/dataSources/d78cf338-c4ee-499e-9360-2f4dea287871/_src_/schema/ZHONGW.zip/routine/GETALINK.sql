create function getAlink(strLeix in varchar2,strID in varchar2, strLable in  varchar2) return varchar2 is
		begin
	       if strID='-1' then
	          return strLable;
         else
           return '<a href="#" onclick="openChildItem('||strID||','||chr(39)||strLeix||chr(39)||')">'||strLable||'</a>';
         end if;
    end getAlink;

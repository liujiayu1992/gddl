create view RISJ as
select "RIQ","LAIML","QNETAR_RC","QNET_AR","AAR","MAD","MT","STD","VAD","FHZ","DZZ","SZMZ"
from (select  z.riq as riq,nvl(laiml,0)laiml,nvl(qnetar_rc*1000,0)qnetar_rc,nvl(qnet_ar*1000,0)qnet_ar,nvl(aar,0)aar,
nvl(mad,0)mad,nvl(mt,0)mt,nvl(std,0)std,nvl(vad,0)vad,nvl(fhz,0)fhz,nvl(dzz,0)dzz,nvl(szmz,0)szmz
from (
select f.daohrq+1 as daohrq,sum(round(f.laimsl,0))laiml,
decode(sum(round(f.laimsl,0)),0,0,round_new(
sum(z.qnet_ar*round(f.laimsl,0))/sum(decode(z.qnet_ar,null,0,round(f.laimsl,0)))
,3))qnetar_rc
from zgdt.fahb f,zgdt.zhilb z
where f.zhilb_id=z.id  and f.hedbz=3
group by f.daohrq)a,
(--入厂取前一天数据，
select r.rulrq,decode(sum(fadhy+gongrhy+qity),0,0,round_new(sum(qnet_ar*(fadhy+gongrhy+qity))/sum(fadhy+gongrhy+qity),2))qnet_ar,
decode(sum(fadhy+gongrhy+qity),0,0,round_new(sum(aar*(fadhy+gongrhy+qity))/sum(fadhy+gongrhy+qity),2)) aar,
decode(sum(fadhy+gongrhy+qity),0,0,round_new(sum(mt*(fadhy+gongrhy+qity))/sum(fadhy+gongrhy+qity),1))mt,
decode(sum(fadhy+gongrhy+qity),0,0,round_new(sum(mad*(fadhy+gongrhy+qity))/sum(fadhy+gongrhy+qity),2)) mad,
decode(sum(fadhy+gongrhy+qity),0,0,round_new(sum(std*(fadhy+gongrhy+qity))/sum(fadhy+gongrhy+qity),2)) std,
decode(sum(fadhy+gongrhy+qity),0,0,round_new(sum(vad*(fadhy+gongrhy+qity))/sum(fadhy+gongrhy+qity),2))vad
from  zgdt.rulmzlb r,zgdt.meihyb m where r.shenhzt=3 and m.rulmzlb_id=r.id
group by r.rulrq
)b,
(select riq,sum(fhz)fhz,sum(dzz)dzz,sum(szmz)szmz
from(
select r.riq,round(sum(zhi)/count(*),3) fhz,0 dzz,0 szmz
from zgdt.rulqtzbb r,zgdt.item i
where r.item_id=i.id and i.bianm='FH'
group by  r.riq
union
select r.riq,0 fhz,round_new(sum(zhi)/count(*),3) dzz,0 szmz
from zgdt.rulqtzbb r,zgdt.item i
where r.item_id=i.id and i.bianm='DZ'
group by  r.riq
union
select r.riq,0 fhz,0 dzz,round_new(sum(zhi)/count(*),3) szmz
from zgdt.rulqtzbb r,zgdt.item i
where r.item_id=i.id and i.bianm='SZM'
group by  r.riq
) group by riq
)d,(select distinct riq from (select f.daohrq+1 as riq from zgdt.fahb f,zgdt.zhilb z
where f.zhilb_id=z.id  and f.hedbz=3
union select r.rulrq as riq from zgdt.rulmzlb r,zgdt.meihyb m
where r.shenhzt=3 and m.rulmzlb_id=r.id
union
select riq
from(
select r.riq
from zgdt.rulqtzbb r,zgdt.item i
where r.item_id=i.id and i.bianm='FH'
group by  r.riq
union
select r.riq
from zgdt.rulqtzbb r,zgdt.item i
where r.item_id=i.id and i.bianm='DZ'
group by  r.riq
union
select r.riq
from zgdt.rulqtzbb r,zgdt.item i
where r.item_id=i.id and i.bianm='SZM'
group by  r.riq
)
group by riq)) z  where z.riq=a.daohrq(+)
and z.riq=b.rulrq(+) and z.riq=d.riq(+)) order by riq

 

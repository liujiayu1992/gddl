create Function getFirstFazBM (strFaz Varchar2) Return Varchar2 Is
Begin
    Declare
      faz Varchar2(20) :=' ';
      bmFaz Varchar2(20):=' ';
      loc number;
    Begin
      loc:=instr(strFaz,',',1,1);
      if loc=0 then
         faz:=strFaz;
       else
         faz:=substr(strFaz,1,loc-1);
       end if;
       bmFaz:=faz;
       -- select chezxxb.chezbm into bmFaz from chezxxb where chezxxb.jianc=faz;
         return bmFaz;
    End;
End;
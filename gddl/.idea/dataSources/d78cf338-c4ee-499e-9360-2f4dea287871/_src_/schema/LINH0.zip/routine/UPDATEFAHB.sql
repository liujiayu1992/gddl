create PROCEDURE UPDATEFAHB(FAHBID  IN NUMBER,
                                       V_CHES  IN NUMBER,
                                       V_MAOZ  IN NUMBER,
                                       V_PIZ   IN NUMBER,
                                       V_YUNS  IN NUMBER,
                                       V_BIAOZ IN NUMBER,
                                       V_KOUD  IN NUMBER,
                                       V_KOUZ  IN NUMBER,
                                       V_YINGD IN NUMBER) IS
BEGIN

  DECLARE
    VCHES FAHB.CHES%TYPE;
  BEGIN
    UPDATE FAHB
       SET CHES  = CHES + V_CHES,
           MAOZ  = MAOZ + V_MAOZ,
           PIZ   = PIZ + V_PIZ,
           YUNS  = YUNS + V_YUNS,
           BIAOZ = BIAOZ + V_BIAOZ,
           KOUD  = KOUD + V_KOUD,
           KOUZ  = KOUZ + V_KOUZ,
           YINGD = YINGD + V_YINGD
     WHERE ID = FAHBID;

    --删除空发货记录
    SELECT CHES INTO VCHES FROM FAHB WHERE ID = FAHBID;
    IF VCHES <= 0 THEN
      DBMS_OUTPUT.PUT_LINE(FAHBID);
      /*       delete from zhillsb where zhilb_id in (select zhilb_id from fahb where id=fahbid);
      delete from yangpdhb where caiyb_id in (select id from caiyb where zhilb_id in (select zhilb_id from fahb where id=fahbid));
      delete from caiyb where zhilb_id in (select zhilb_id from fahb where id=fahbid);
      DELETE FROM zhuanmb WHERE zhillsb_id IN (SELECT ID FROM zhillsb WHERE zhilb_id IN (select zhilb_id from fahb where id=fahbid));*/
      DELETE FROM FAHB WHERE ID = FAHBID;
    END IF;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('no fahb');
  END;
END UPDATEFAHB;

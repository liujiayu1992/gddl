create trigger TRIGGER_UD_CHEPB
	before update or delete
	on CHEPB
	for each row
Declare
  L_action      rizb.caozlx%Type;
  C_user        rizb.caozy%Type;
  C_zid         rizb.zid%Type;
  C_yuanzall    rizb.yuanz%Type;
  C_yuanz rizb.yuanz%Type;
  C_xinz        rizb.xinz%Type;
  b_trigger Boolean := True;
  --I_loopcounter integer := 1;
Begin
  C_zid      := '';
  C_yuanzall := '';
  C_yuanz    := '';
  C_xinz     := '';
  If :new_value.DIAODRY Is Not Null Then
    C_User := :new_value.DIAODRY;
  Else
    C_User := '未知';
  End If;
  If updating Then
    l_action := '更新';
  Elsif deleting Then
    l_action := '删除';
  Else
    raise_application_error(-99999, '这里也能出错，那我也不知道是什么错了');
  End If;
  If :new_value.XUH != :old_value.XUH Then
    C_zid   := 'XUH' || ',';
    C_yuanz := C_yuanz || :old_value.XUH || ',';
    C_xinz  := C_xinz || :new_value.XUH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.XUH || ',';
  End If;
  If :new_value.CHEPH != :old_value.CHEPH Then
    C_zid   := 'CHEPH' || ',';
    C_yuanz := C_yuanz || :old_value.CHEPH || ',';
    C_xinz  := C_xinz || :new_value.CHEPH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.CHEPH || ',';
  End If;
  If :new_value.PIAOJH != :old_value.PIAOJH Then
    C_zid   := 'PIAOJH' || ',';
    C_yuanz := C_yuanz || :old_value.PIAOJH || ',';
    C_xinz  := C_xinz || :new_value.PIAOJH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.PIAOJH || ',';
  End If;
  If :new_value.MAOZ != :old_value.MAOZ Then
    C_zid   := 'MAOZ' || ',';
    C_yuanz := C_yuanz || :old_value.MAOZ || ',';
    C_xinz  := C_xinz || :new_value.MAOZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.MAOZ || ',';
  End If;
  If :new_value.PIZ != :old_value.PIZ Then
    C_zid   := 'PIZ' || ',';
    C_yuanz := C_yuanz || :old_value.PIZ || ',';
    C_xinz  := C_xinz || :new_value.PIZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.PIZ || ',';
  End If;
  If :new_value.BIAOZ != :old_value.BIAOZ Then
    C_zid   := 'BIAOZ' || ',';
    C_yuanz := C_yuanz || :old_value.BIAOZ || ',';
    C_xinz  := C_xinz || :new_value.BIAOZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.BIAOZ || ',';
  End If;
  If :new_value.YINGK != :old_value.YINGK Then
    C_zid   := 'YINGK' || ',';
    C_yuanz := C_yuanz || :old_value.YINGK || ',';
    C_xinz  := C_xinz || :new_value.YINGK || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YINGK || ',';
  End If;
  If :new_value.YUNS != :old_value.YUNS Then
    C_zid   := 'YUNS' || ',';
    C_yuanz := C_yuanz || :old_value.YUNS || ',';
    C_xinz  := C_xinz || :new_value.YUNS || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUNS || ',';
  End If;
  If :new_value.YUNSL != :old_value.YUNSL Then
    C_zid   := 'YUNSL' || ',';
    C_yuanz := C_yuanz || :old_value.YUNSL || ',';
    C_xinz  := C_xinz || :new_value.YUNSL || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUNSL || ',';
  End If;
  If :new_value.KOUD != :old_value.KOUD Then
    C_zid   := 'KOUD' || ',';
    C_yuanz := C_yuanz || :old_value.KOUD || ',';
    C_xinz  := C_xinz || :new_value.KOUD || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.KOUD || ',';
  End If;
  If :new_value.CHES != :old_value.CHES Then
    C_zid   := 'CHES' || ',';
    C_yuanz := C_yuanz || :old_value.CHES || ',';
    C_xinz  := C_xinz || :new_value.CHES || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.CHES || ',';
  End If;
  If :new_value.JIANJFS != :old_value.JIANJFS Then
    C_zid   := 'JIANJFS' || ',';
    C_yuanz := C_yuanz || :old_value.JIANJFS || ',';
    C_xinz  := C_xinz || :new_value.JIANJFS || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.JIANJFS || ',';
  End If;
  If :new_value.GUOHB_ID != :old_value.GUOHB_ID Then
    C_zid   := 'GUOHB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.GUOHB_ID || ',';
    C_xinz  := C_xinz || :new_value.GUOHB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.GUOHB_ID || ',';
  End If;
  If :new_value.FAHB_ID != :old_value.FAHB_ID Then
    C_zid   := 'FAHB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.FAHB_ID || ',';
    C_xinz  := C_xinz || :new_value.FAHB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.FAHB_ID || ',';
  End If;
  If :new_value.CHEB != :old_value.CHEB Then
    C_zid   := 'CHEB' || ',';
    C_yuanz := C_yuanz || :old_value.CHEB || ',';
    C_xinz  := C_xinz || :new_value.CHEB || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.CHEB || ',';
  End If;
  If :new_value.HEDBZ != :old_value.HEDBZ Then
    C_zid   := 'HEDBZ' || ',';
    C_yuanz := C_yuanz || :old_value.HEDBZ || ',';
    C_xinz  := C_xinz || :new_value.HEDBZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.HEDBZ || ',';
  End If;
  If :new_value.YUANMKDW != :old_value.YUANMKDW Then
    C_zid   := 'YUANMKDW' || ',';
    C_yuanz := C_yuanz || :old_value.YUANMKDW || ',';
    C_xinz  := C_xinz || :new_value.YUANMKDW || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUANMKDW || ',';
  End If;
  If :new_value.YUNSDW != :old_value.YUNSDW Then
    C_zid   := 'YUNSDW' || ',';
    C_yuanz := C_yuanz || :old_value.YUNSDW || ',';
    C_xinz  := C_xinz || :new_value.YUNSDW || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUNSDW || ',';
  End If;
  If :new_value.QUSCF != :old_value.QUSCF Then
    C_zid   := 'QUSCF' || ',';
    C_yuanz := C_yuanz || :old_value.QUSCF || ',';
    C_xinz  := C_xinz || :new_value.QUSCF || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.QUSCF || ',';
  End If;
  If :new_value.YUANMZ != :old_value.YUANMZ Then
    C_zid   := 'YUANMZ' || ',';
    C_yuanz := C_yuanz || :old_value.YUANMZ || ',';
    C_xinz  := C_xinz || :new_value.YUANMZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUANMZ || ',';
  End If;
  If :new_value.QINGCSJ != :old_value.QINGCSJ Then
    C_zid   := 'QINGCSJ' || ',';
    C_yuanz := C_yuanz || :old_value.QINGCSJ || ',';
    C_xinz  := C_xinz || :new_value.QINGCSJ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.QINGCSJ || ',';
  End If;
  If :new_value.ZHONGCSJ != :old_value.ZHONGCSJ Then
    C_zid   := 'ZHONGCSJ' || ',';
    C_yuanz := C_yuanz || :old_value.ZHONGCSJ || ',';
    C_xinz  := C_xinz || :new_value.ZHONGCSJ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.ZHONGCSJ || ',';
  End If;
  If :new_value.MEICB_ID != :old_value.MEICB_ID Then
    C_zid   := 'MEICB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.MEICB_ID || ',';
    C_xinz  := C_xinz || :new_value.MEICB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.MEICB_ID || ',';
  End If;
  If :new_value.BEIZ != :old_value.BEIZ Then
    C_zid   := 'BEIZ' || ',';
    C_yuanz := C_yuanz || :old_value.BEIZ || ',';
    C_xinz  := C_xinz || :new_value.BEIZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.BEIZ || ',';
  End If;
  If :new_value.YUANSHDW != :old_value.YUANSHDW Then
    C_zid   := 'YUANSHDW' || ',';
    C_yuanz := C_yuanz || :old_value.YUANSHDW || ',';
    C_xinz  := C_xinz || :new_value.YUANSHDW || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUANSHDW || ',';
  End If;
  If :new_value.YINGD != :old_value.YINGD Then
    C_zid   := 'YINGD' || ',';
    C_yuanz := C_yuanz || :old_value.YINGD || ',';
    C_xinz  := C_xinz || :new_value.YINGD || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YINGD || ',';
  End If;
  If :new_value.KUID != :old_value.KUID Then
    C_zid   := 'KUID' || ',';
    C_yuanz := C_yuanz || :old_value.KUID || ',';
    C_xinz  := C_xinz || :new_value.KUID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.KUID || ',';
  End If;
  If :new_value.GUOHSJ != :old_value.GUOHSJ Then
    C_zid   := 'GUOHSJ' || ',';
    C_yuanz := C_yuanz || :old_value.GUOHSJ || ',';
    C_xinz  := C_xinz || :new_value.GUOHSJ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.GUOHSJ || ',';
  End If;
  If :new_value.JILHH != :old_value.JILHH Then
    C_zid   := 'JILHH' || ',';
    C_yuanz := C_yuanz || :old_value.JILHH || ',';
    C_xinz  := C_xinz || :new_value.JILHH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.JILHH || ',';
  End If;
  If :new_value.DAOZCH != :old_value.DAOZCH Then
    C_zid   := 'DAOZCH' || ',';
    C_yuanz := C_yuanz || :old_value.DAOZCH || ',';
    C_xinz  := C_xinz || :new_value.DAOZCH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.DAOZCH || ',';
  End If;
  If :new_value.JIEXDH != :old_value.JIEXDH Then
    C_zid   := 'JIEXDH' || ',';
    C_yuanz := C_yuanz || :old_value.JIEXDH || ',';
    C_xinz  := C_xinz || :new_value.JIEXDH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.JIEXDH || ',';
  End If;
  If :new_value.YUANFAHBID != :old_value.YUANFAHBID Then
    C_zid   := 'YUANFAHBID' || ',';
    C_yuanz := C_yuanz || :old_value.YUANFAHBID || ',';
    C_xinz  := C_xinz || :new_value.YUANFAHBID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.YUANFAHBID || ',';
  End If;
  If :new_value.JIHKJB_ID != :old_value.JIHKJB_ID Then
    C_zid   := 'JIHKJB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.JIHKJB_ID || ',';
    C_xinz  := C_xinz || :new_value.JIHKJB_ID || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.JIHKJB_ID || ',';
  End If;
  If :new_value.TUOSBH != :old_value.TUOSBH Then
    C_zid   := 'TUOSBH' || ',';
    C_yuanz := C_yuanz || :old_value.TUOSBH || ',';
    C_xinz  := C_xinz || :new_value.TUOSBH || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.TUOSBH || ',';
  End If;
  If :new_value.BANZ != :old_value.BANZ Then
    C_zid   := 'BANZ' || ',';
    C_yuanz := C_yuanz || :old_value.BANZ || ',';
    C_xinz  := C_xinz || :new_value.BANZ || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.BANZ || ',';
  End If;
  If :new_value.BANC != :old_value.BANC Then
    C_zid   := 'BANC' || ',';
    C_yuanz := C_yuanz || :old_value.BANC || ',';
    C_xinz  := C_xinz || :new_value.BANC || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.BANC || ',';
  End If;
  If :new_value.DIAODRY != :old_value.DIAODRY Then
    C_zid   := 'DIAODRY' || ',';
    C_yuanz := C_yuanz || :old_value.DIAODRY || ',';
    C_xinz  := C_xinz || :new_value.DIAODRY || ',';
  Else
    C_yuanzall := C_yuanzall || :old_value.DIAODRY || ',';
  End If;
  --结算数量标识（暂时不使用此字段）
  If :new_value.JIESSLBZ != :old_value.JIESSLBZ Then
    C_zid   := 'JIESSLBZ' || ',';
    C_yuanz := C_yuanz || :old_value.JIESSLBZ || ',';
    C_xinz  := C_xinz || :new_value.JIESSLBZ || ',';
    --b_trigger := False;
  Else
    C_yuanzall := C_yuanzall || :old_value.JIESSLBZ || ',';
    --b_trigger := False;
  End If;

  --煤价表id标识（暂时不使用此字段）
  If :new_value.MEIJB_ID != :old_value.MEIJB_ID Then
    C_zid   := 'MEIJB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.MEIJB_ID || ',';
    C_xinz  := C_xinz || :new_value.MEIJB_ID || ',';
    --b_trigger := False;
  Else
    C_yuanzall := C_yuanzall || :old_value.MEIJB_ID || ',';
    --b_trigger := False;
  End If;

  --结算指标表id标识
  If :new_value.JIESZBB_ID != :old_value.JIESZBB_ID Then
    C_zid   := 'JIESZBB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.JIESZBB_ID || ',';
    C_xinz  := C_xinz || :new_value.JIESZBB_ID || ',';
    --b_trigger := False;
  Else
    C_yuanzall := C_yuanzall || :old_value.JIESZBB_ID || ',';
    --b_trigger := False;
  End If;

  --结算表id标识
  If :new_value.JIESB_ID != :old_value.JIESB_ID Then
    C_zid   := 'JIESB_ID' || ',';
    C_yuanz := C_yuanz || :old_value.JIESB_ID || ',';
    C_xinz  := C_xinz || :new_value.JIESB_ID || ',';
    --b_trigger := False;
  Else
    C_yuanzall := C_yuanzall || :old_value.JIESB_ID || ',';
    --b_trigger := False;
  End If;


  If C_zid Is Not Null Then
    C_zid := substr(C_zid, 0, length(C_zid) - 1);
  Else
    C_zid := getcolname('chepb');
  End If;
  If C_yuanz Is Not Null Then
    C_yuanz := substr(C_yuanz, 0, length(C_yuanz) - 1);
  Else
    C_yuanz := C_yuanzall;
  End If;
  If C_xinz Is Not Null Then
    C_xinz := substr(C_xinz, 0, length(C_xinz) - 1);
  End If;
  If b_trigger Then

    Insert Into rizb
      (Id,
       mokmc,
       biaomc,
       biaoid,
       zid,
       yuanz,
       xinz,
       caozy,
       caozsj,
       caozlx,
       diz)
    Values
      (xl_rizb_id.Nextval,
       '数量信息',
       'chepb',
       :old_value.Id,
       C_zid,
       C_yuanz,
       C_xinz,
       C_User,
       Sysdate,
       l_action,
       '暂无');
  End If;
  exception
  when others then
        if inserting then
           zengjrz('trigger_ud_chepb',:new_value.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_ud_chepb',:old_value.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_ud_chepb',:old_value.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
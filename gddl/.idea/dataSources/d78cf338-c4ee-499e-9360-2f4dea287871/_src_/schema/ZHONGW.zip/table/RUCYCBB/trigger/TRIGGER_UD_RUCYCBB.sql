create trigger TRIGGER_UD_RUCYCBB
	before insert or update or delete
	on RUCYCBB
	for each row
Declare
  Begin
    if inserting then
      AddInterfaceTask('rucycbb', :new.id,0, :new.diancxxb_id, 'xml', :new.id,:new.riq );
    elsif deleting then
      AddInterfaceTask('rucycbb', :old.id,1 , :old.diancxxb_id, 'xml', :old.id,:old.riq);
    elsif updating then
      AddInterfaceTask('rucycbb', :old.id, 2, :old.diancxxb_id, 'xml', :old.id,:old.riq );
    end if;
    exception
    when others then
    return ;
  End;

create FUNCTION        "GETJIESDZB" (TablName in varchar2,Id in number, Zhiibm in varchar2,colname in varchar2) return varchar2 is

  zhibm varchar2(200);
begin
      execute immediate ' select to_char('|| colname ||') from '||TablName||' d,jieszbsjb j,zhibb z  where d.id=j.jiesdid and j.zhibb_id=z.id and z.bianm='''||Zhiibm||''' and d.id='||Id
         into zhibm;
         if not (zhibm is null)  then

            return zhibm;
         else

            return '';
         end if;

end getJiesdzb;

 
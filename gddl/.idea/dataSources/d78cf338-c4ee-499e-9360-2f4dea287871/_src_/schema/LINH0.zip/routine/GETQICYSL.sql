create function GetQicysl(qichjjbtmpid number) return number is
	  Result chepb.yunsl%Type;
	begin
	   DECLARE
	   CURSOR qicysl IS SELECT m.qicysl FROM qichjjbtmp q,meikxxb m where q.id = qichjjbtmpid and q.meikxxb_id = m.id;
	   BEGIN
	       OPEN qicysl;
	            FETCH qicysl INTO Result;
	       CLOSE qicysl;
	       return(Result);
	   END;
	end GetQicysl;

create view VWYOUPD as
select id,panmyqkbgzb_id,sum(BENYJY)BENYJY,sum(FADH)FADH,sum(GONGRH)GONGRH,sum(QITY)QITY,sum(ZHANGMKC)ZHANGMKC
,sum(SHIJKC)SHIJKC,sum(PANYK)PANYK
from (
select  panmyqkbgzb_id id,panmyqkbgzb_id,shuly BENYJY,0 FADH,0 GONGRH,0 QITY,0 ZHANGMKC,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='本月进量'
union all
select panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,shuly FADH,0 GONGRH,0 QITY,0 ZHANGMKC,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='  发电耗'
union all
select panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,shuly GONGRH ,0 QITY,0 ZHANGMKC,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='  供热耗'
union all
select panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,0 GONGRH ,shuly QITY,0 ZHANGMKC,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='  其他耗'
union all
select panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,0 GONGRH ,0 QITY,shuly ZHANGMKC ,0 SHIJKC,0 PANYK
from panmyqkbgb f
where f.xiangm='盘点时账面库存'
union all
select panmyqkbgzb_id  id,panmyqkbgzb_id,0 BENYJY,0 FADH,0 GONGRH ,0 QITY,0 ZHANGMKC ,shuly  SHIJKC ,0 PANYK
from panmyqkbgb f
where f.xiangm='盘点存合计'
union all
select panmyqkbgzb_id id,panmyqkbgzb_id,0 BENYJY,0 FADH,0 GONGRH ,0 QITY,0 ZHANGMKC ,0  SHIJKC ,shuly  PANYK
from panmyqkbgb f
where f.xiangm='盘盈(+)或盘亏(-)')
group by panmyqkbgzb_id,id

create function getPandlhtz(diancxxbid in number, panddate in date) return number is
begin
     declare
        pandlhtzl number;
        begin

          select (nvl(my.pandhjmyl_m,0)-nvl(my.pandhhmyl_m,0)) into pandlhtzl from YUEMCMYZB zb,YUEMCMYb my
          where my.yuemcmyzb_id=zb.id and zb.diancxxb_id = diancxxbid
                and zb.riq=panddate ;

          return pandlhtzl;
        end;
end getPandlhtz;

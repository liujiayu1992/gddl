create FUNCTION getcolname(tablename varchar2) return varchar2 is
begin
    declare
      colnames varchar2(1500) := '';
      v_loopcounter integer :=1;
      CURSOR my_cursor IS
      select column_id,column_name from sys.all_tab_columns  where OWNER =upper('cpicrmis') and TABLE_NAME = upper(tablename) order by column_id ;
      my_rec my_cursor%ROWTYPE;
      begin
        OPEN my_cursor;
          LOOP
          FETCH my_cursor INTO my_rec;
          EXIT WHEN my_cursor%NOTFOUND;
               IF v_loopcounter = 1 THEN
                  colnames := my_rec.column_name;
                  v_loopcounter := v_loopcounter + 1;
               ELSE
                   colnames := colnames || ',' || my_rec.column_name;
               END IF;
          END LOOP;
        CLOSE my_cursor;
        RETURN colnames;
      END;
END;

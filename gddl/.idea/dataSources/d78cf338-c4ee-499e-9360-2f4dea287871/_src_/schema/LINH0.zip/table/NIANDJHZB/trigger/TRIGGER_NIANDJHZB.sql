create trigger TRIGGER_NIANDJHZB
	before insert or update or delete
	on NIANDJHZB
	for each row
Begin

     if inserting and :new.shenhzt=1 then
          AddInterfaceTask ('nianxqjhh',:new.id,0,:new.changbb_id,'xml',:new.id, to_date(:new.niand||'-01-01','yyyy-mm-dd'));

     elsif deleting and :old.shenhzt=1 then
          AddInterfaceTask ('nianxqjhh',:old.id,1,:old.changbb_id,'xml',:old.id, to_date(:old.niand||'-01-01','yyyy-mm-dd'));
     elsif updating and :new.shenhzt=1 then
          AddInterfaceTask ('nianxqjhh',:new.id,2,:new.changbb_id,'xml',:new.id,to_date(:new.niand||'-01-01','yyyy-mm-dd'));
     end if ;

     exception
     when others then
        if inserting then
           zengjrz('trigger_niandjhzb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_niandjhzb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_niandjhzb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;

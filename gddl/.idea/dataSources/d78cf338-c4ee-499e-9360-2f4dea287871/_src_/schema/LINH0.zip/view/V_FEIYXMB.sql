create view V_FEIYXMB as
select x.Id,x.diancxxb_id,x.feiymc,x.gongs,x.beiz,x.xuh,x.feiylx,x.shuib,x.fukbz,x.defaultval
   from feiyxmb x Where beiz is null or beiz = '使用中'
With Read Only


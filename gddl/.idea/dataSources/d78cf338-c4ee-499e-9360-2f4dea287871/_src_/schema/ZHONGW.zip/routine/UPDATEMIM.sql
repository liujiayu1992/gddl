create procedure UpdateMim(aviID in number, varmim varchar2) AS
    numof    number(7);
    blob_loc blob;
  BEGIN

    update renyxxb set mim = empty_blob() where id = aviID;

    SELECT mim
      INTO blob_loc --   获取定位器并锁定行
      FROM renyxxb
     WHERE id = aviID
       FOR UPDATE;

    numof := LENGTHB(varmim);
    dbms_lob.write(blob_loc, numof, 1, UTL_RAW.cast_to_raw(varmim));

    COMMIT;
  END;

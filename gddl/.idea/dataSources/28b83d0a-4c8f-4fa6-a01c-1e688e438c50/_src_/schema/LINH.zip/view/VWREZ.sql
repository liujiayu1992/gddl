create view VWREZ as
select dy.jihkjb_id,dy.gongysb_id,dy.diancxxb_id, dy.riq,sum(decode(dy.fenx,'本月',dy.jingz)) jbeny,
       sum(decode(dy.fenx,'累计',dy.jingz)) jleij,sum(decode(dy.fenx,'本月',sy.jingz)) jsy,
       sum(decode(dy.fenx,'累计',tq.jingz)) jtq,
       nvl(decode(sum(decode(dy.fenx,'本月',dy.jingz)),0,0,
       sum(decode(dy.fenx,'本月',dy.rcrz*dy.jingz))/sum(decode(dy.fenx,'本月',dy.jingz))),0) cbeny,
       nvl(decode(sum(decode(dy.fenx,'累计',dy.jingz)),0,0,
       sum(decode(dy.fenx,'累计',dy.rcrz*dy.jingz))/sum(decode(dy.fenx,'累计',dy.jingz))),0) cleij,
       nvl(decode(sum(decode(dy.fenx,'本月',sy.jingz)),0,0,
       sum(decode(dy.fenx,'本月',sy.rcrz*sy.jingz))/sum(decode(dy.fenx,'本月',sy.jingz))),0) csy,
       nvl(decode(sum(decode(dy.fenx,'累计',tq.jingz)),0,0,
       sum(decode(dy.fenx,'累计',tq.rcrz*tq.jingz))/sum(decode(dy.fenx,'累计',tq.jingz))),0) ctq,
       nvl(decode(sum(decode(dy.fenx,'本月',dy.jingz)),0,0,
       sum(decode(dy.fenx,'本月',dy.kfrz*dy.jingz))/sum(decode(dy.fenx,'本月',dy.jingz))),0) kbeny,
       nvl(decode(sum(decode(dy.fenx,'累计',dy.jingz)),0,0,
       sum(decode(dy.fenx,'累计',dy.kfrz*dy.jingz))/sum(decode(dy.fenx,'累计',dy.jingz))),0) kleij,
       nvl(decode(sum(decode(dy.fenx,'本月',sy.jingz)),0,0,
       sum(decode(dy.fenx,'本月',sy.kfrz*sy.jingz))/sum(decode(dy.fenx,'本月',sy.jingz))),0) ksy,
       nvl(decode(sum(decode(dy.fenx,'累计',tq.jingz)),0,0,
       sum(decode(dy.fenx,'累计',tq.kfrz*tq.jingz))/sum(decode(dy.fenx,'累计',tq.jingz))),0) ktq
       from
(select  k.diancxxb_id,k.jihkjb_id,k.gongysb_id,k.riq,y.fenx,s.jingz,y.qnet_ar rcrz,
y.qnet_ar_kf kfrz
       from yuezlb y, yuetjkjb k, yueslb s
where y.yuetjkjb_id = k.id and y.yuetjkjb_id = s.yuetjkjb_id
) dy,
(select  k.diancxxb_id,k.jihkjb_id,k.gongysb_id,k.riq,y.fenx,s.jingz,y.qnet_ar rcrz,
y.qnet_ar_kf kfrz
       from yuezlb y, yuetjkjb k, yueslb s
where y.yuetjkjb_id = k.id and y.yuetjkjb_id = s.yuetjkjb_id
) sy,
(select  k.diancxxb_id,k.jihkjb_id,k.gongysb_id,k.riq,y.fenx,s.jingz,y.qnet_ar rcrz,
y.qnet_ar_kf kfrz
       from yuezlb y, yuetjkjb k, yueslb s
where y.yuetjkjb_id = k.id and y.yuetjkjb_id = s.yuetjkjb_id
) tq
where dy.diancxxb_id = sy.diancxxb_id (+) and dy.diancxxb_id = tq.diancxxb_id(+)
and dy.jihkjb_id = sy.jihkjb_id(+) and dy.jihkjb_id = tq.jihkjb_id(+)
and dy.gongysb_id = sy.gongysb_id (+) and dy.gongysb_id = tq.gongysb_id(+)
and dy.fenx = sy.fenx(+) and dy.fenx = tq.fenx(+)
and dy.riq = add_months(sy.riq(+),-1) and dy.riq = add_months(tq.riq(+),-12)
group by dy.jihkjb_id,dy.gongysb_id,dy.diancxxb_id, dy.riq

 

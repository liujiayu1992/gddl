create view VWGONGYSMKKJ as
select rownum wid,id,mingc,fuid,jib,diancxxb_id from
(select 2 jib,0 fuid,g.id,g.mingc,gl.diancxxb_id
        from gongysb g, gongysdcglb gl
        where g.id = gl.gongysb_id and g.leix = 1
union
select 3 jib,ml.gongysb_id,m.id,m.mingc,gl.diancxxb_id
       from meikxxb m, gongysmkglb ml,gongysdcglb gl, gongysb g
       where ml.meikxxb_id = m.id
       and ml.gongysb_id = gl.gongysb_id
       and gl.gongysb_id = g.id
       and g.leix = 1
       and m.zhuangt=1
union
select distinct 4 jib,f.meikxxb_id,j.id,j.mingc,f.diancxxb_id
  from fenkcyfsb f, jihkjb j, gongysmkglb ml,
  gongysdcglb gl, gongysb g
 where f.jihkjb_id = j.id and j.id!=4
       and f.meikxxb_id = ml.meikxxb_id
       and ml.gongysb_id = gl.gongysb_id
       and g.id = gl.gongysb_id
       and g.leix =1
       and f.chezxxb_id = 1
)

 

create FUNCTION getShihcybm(cyriq in date,Xuh in number)
  Return  varchar2 as
  begin
       begin
            return to_char(cyriq,'yymmdd') || trim(to_char(Xuh,'000'));
       end;
  end;

create view VWMEIPD_YM as
select id,yuemcmyzb_id,sum(pandssjkc)pandssjkc,sum(pandhjmyl)pandhjmyl,sum(pandhhmyl)pandhhmyl, sum(fadh)fadh,
sum(gongrh)gongrh,sum(qith)qith,sum(pandhccsh)pandhccsh,sum(pandhyssh)pandhyssh,
sum(pandhdcl)pandhdcl,sum(yuemzmkc)yuemzmkc,sum(yuemsjkc)yuemsjkc
,sum(pandhsfctz)pandhsfctz,sum(panyk)panyk
from (
select  yuemcmyzb_id id,yuemcmyzb_id,shulm pandssjkc,0 pandhjmyl,0 pandhhmyl,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='盘点时实际库存'
union all
select  yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,shulm pandhjmyl,0 pandhhmyl,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='盘点后进煤(油）量'
union all
select  yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,shulm pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='盘点后耗煤(油)量'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,shulm fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='  发电耗'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,shulm gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='  供热耗'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,shulm qith,0 pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='  其他耗'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,shulm pandhccsh,0 pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='  盘点后储存损耗'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,shulm pandhyssh,0 pandhdcl,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm=' 盘点后运输损耗'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,shulm pandhdcl ,0 pandhsfctz,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm=' 盘点后调出量'
union all
select  yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl ,shulm  pandhsfctz ,0 yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm=' 盘点后水分差调整'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl ,0  pandhsfctz ,shulm  yuemsjkc,0 yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='月末24时实际库存'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl ,0  pandhsfctz ,0  yuemsjkc,shulm yuemzmkc,0 panyk
from yuemcmyb f
where f.xiangm='月末24时帐面库存'
union all
select yuemcmyzb_id id,yuemcmyzb_id,0 pandssjkc,0 pandhjmyl,0 pandhhmyl ,0 fadh,0 gongrh,0 qith,0 pandhccsh,0 pandhyssh,0 pandhdcl ,0  pandhsfctz ,0  yuemsjkc,0 yuemzmkc,shulm panyk
from yuemcmyb f
where f.xiangm='盘盈(+)或盘亏(-)')
group by yuemcmyzb_id,id

create FUNCTION getYunsfsb_id(riq varchar2 )--2008-01
	Return  number as
	begin
	     declare
       var_yunsfsb_id number;
	     begin
           select max(yunsfsb.id)yunsfsb_id into var_yunsfsb_id
            from fahb,yunsfsb,chepb
            where fahb.yunsfs=yunsfsb.mingc and fahb.id=chepb.fahb_id
            and to_char(chepb.guohsj,'yyyy-mm')=riq;
	         return var_yunsfsb_id;
	     end;
	end;
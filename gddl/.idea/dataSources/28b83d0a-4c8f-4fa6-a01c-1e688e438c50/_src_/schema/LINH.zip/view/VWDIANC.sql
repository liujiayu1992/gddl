create view VWDIANC as
select dc.id as id,dc.mingc , dc.xuh ,dc.fuid,dc.shangjgsid,
        fgs.id as fgsid,fgs.mingc as fgsmc,fgs.xuh as fgsxh,
        rlgs.id as rlgsid ,rlgs.mingc as rlgsmc,rlgs.xuh as rlgsxh,dc.jingjcml
  from diancxxb dc,diancxxb fgs,diancxxb rlgs
  where ( dc.jib=2 or  dc.jib=3)
  and dc.fuid=fgs.id(+)
  and dc.shangjgsid=rlgs.id(+)
 

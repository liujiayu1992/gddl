create view BIJ as
select baoz.riq,nvl(ddd,0) laiy,haoy.fadyy fadyy,haoy.gongryy,haoy.qityy from
(select to_date('2008-01-01', 'yyyy-mm-dd') + rownum - 1 riq,0 shuj
  from user_objects
 where to_date('2008-01-01', 'yyyy-mm-dd') + rownum - 1 <=
       to_date('2008-10-31', 'yyyy-mm-dd')) baoz,
        (select riq, sum(shourl) ddd
         from laiyqkb
        where changbb_id = 1
        and riq between to_date('2008-01-01', 'yyyy-mm-dd') and
              to_date('2008-10-31', 'yyyy-mm-dd')
        group by riq) laiy,
          (select riq, sum(fadyy) fadyy,sum(gongryy) gongryy,sum(qityy) qityy
         from haoyqkyb
        where changbb_id = 1
        and riq between to_date('2008-01-01', 'yyyy-mm-dd') and
              to_date('2008-10-31', 'yyyy-mm-dd')
              and banzh = '合计'
        group by riq) haoy
        where baoz.riq = laiy.riq(+)
        and baoz.riq = haoy.riq(+)

create FUNCTION getQicrjh_Caiybh(zhilbId long)  return varchar2 is
       Result varchar2(2000);
-- 得到汽车日计划的采样编号串
  begin
       declare
       varCaiybh varchar2(2000);
       varbm varchar2(1000);

       cursor Caiybh is
            select zhuanmb.bianm
                   from zhuanmb,zhuanmlb,yangpdhb,caiyb
                   where  zhuanmb.zhuanmlb_id=zhuanmlb.id and zhuanmlb.jib=1
		                      and yangpdhb.caiyb_id=caiyb.id
		                      and zhuanmb.zhillsb_id=yangpdhb.zhilblsb_id
                          and caiyb.zhilb_id=zhilbId order by zhuanmb.bianm;
            begin
                open Caiybh;
                     fetch Caiybh into varCaiybh;
                     while Caiybh%found  loop

                           if Result is null then

                              Result:=varCaiybh;
                              varbm:=varCaiybh;
                           Elsif varbm<>varCaiybh then

                              Result:=Result||','||varCaiybh;
                              varbm:=varCaiybh;
                           end if;

                           fetch Caiybh into varCaiybh;
                     end loop;
                close Caiybh;
            end;

           return(Result);
  end getQicrjh_Caiybh;

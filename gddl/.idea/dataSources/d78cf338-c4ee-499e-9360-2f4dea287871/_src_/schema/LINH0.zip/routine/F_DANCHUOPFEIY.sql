create Function f_Danchuopfeiy(Mk_Id In Number,
                                          Fz_Id In Number,
                                          Pz    In Number,
                                          Fhrq  Date) Return Number Is
Begin
  Declare
    Zje Number := 0.0;
  Begin
    Select Zongje
      Into Zje
      From v_Fahgj
     Where Meikxxb_Id = Mk_Id
       And Faz_Id = Fz_Id
       And Biaoz = Pz
       And Fahrq <= Fhrq
     Order By Fahrq Desc;
    Return Zje;
  Exception
    When Others Then
      Return 0;
  End;
End f_Danchuopfeiy;
create FUNCTION getQittk (hetid NUMBER) return VARCHAR2 is
begin
    declare
      qittk VARCHAR2(4000) :='';
      v_loopcounter integer :=1;
      v_tiaokmc varchar2(200) :='';
      CURSOR my_cursor IS
        select mingc,neir from hettkmxb where hetxxb_id=hetid order by mingc;
      my_rec my_cursor%ROWTYPE;
    begin
      OPEN my_cursor;
        LOOP
          FETCH my_cursor INTO my_rec;
            EXIT WHEN my_cursor%NOTFOUND;
            IF v_loopcounter = 1 THEN
              v_tiaokmc := my_rec.mingc;
              qittk := v_tiaokmc||chr(13)||chr(9)||my_rec.neir;
            ELSE
              if v_tiaokmc != my_rec.mingc THEN
                qittk := qittk||chr(13)||my_rec.mingc||chr(13)||chr(9)||my_rec.neir;
              ELSE
                qittk := qittk||chr(13)||chr(9)||my_rec.neir;
              END IF;
            END IF;
          v_tiaokmc := my_rec.mingc;
          v_loopcounter := v_loopcounter + 1;
        END LOOP;
      CLOSE my_cursor;
      RETURN qittk;
    END;
END;

create Function f_getJihxh(strJitName varchar2,strDiqmc varchar2) Return Number Is
Begin
    Declare
       intxuh number;
    Begin
      if (strJitName is null) then 
           if strDiqmc is null then
               return 99999;
           else
               select min(xuh) into intxuh from meikdqb where meikdqmc=strDiqmc;
               return intxuh;
           end if;
     else
         select min(xuh) into intxuh from meikdqb where quyjtmc=strJitName;
         return intxuh;
     end if;
    End;
End;

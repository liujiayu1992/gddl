create PROCEDURE        "SAVECHELXX" (diancxxbid in number, yunsdw in number,
yunsfs in number, cheph in varchar2, imaoz in number,ipiz in number )
is begin
    declare
    clid number;
    begin
          select nvl(min(c.id),0) into clid from chelxxb c where diancxxb_id = diancxxbid
          and cheph = cheph and yunsfsb_id = yunsfs and yunsdwb_id = yunsdw;
         if clid = 0 then
             insert into chelxxb(id,diancxxb_id,yunsdwb_id,yunsfsb_id,cheph,maoz,piz)
             values(getnewid(diancxxbid),diancxxbid,yunsdw,yunsfs,cheph,imaoz,ipiz);
          else
             update chelxxb set maoz=imaoz,piz = ipiz where id = clid;
          end if;
    end;
end;

 
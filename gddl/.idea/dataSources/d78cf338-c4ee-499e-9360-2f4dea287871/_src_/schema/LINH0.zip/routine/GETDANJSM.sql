create FUNCTION getDanjsm(hetid NUMBER) return VARCHAR2 is
begin
  declare
    zhilyq        VARCHAR2(500) := '';
    v_loopcounter integer := 1;
    CURSOR my_cursor IS
      select hetxmb.mingc || tiaoj || xiax || '-' || shangx || hetdwb.mingc || '以' ||
             hetjsxyb.jis || '为基数' || hetjsxyb.jisdw || '扣价' ||
             hetjsxyb.koufj || '增价' || hetjsxyb.zengfj || hetjsxyb.jiagdw as mingc
        from hetjsxyb, hetxmb, hetdwb, hetjgdwb
       where hetjsxyb.xiangm = hetxmb.id
         and hetjsxyb.danw = hetdwb.id
         and hetjsxyb.jis = hetdwb.id
         and hetjsxyb.jisdw = hetjgdwb.id
         and hetjsxyb.hetxxb_id = hetid
         and hetjsxyb.biaoz = 1;
    my_rec my_cursor%ROWTYPE;
  begin

    OPEN my_cursor;
    LOOP
      FETCH my_cursor
        INTO my_rec;
      EXIT WHEN my_cursor%NOTFOUND;
      IF v_loopcounter = 1 THEN
        zhilyq := my_rec.mingc;
      ELSE
        zhilyq := zhilyq || '；' || my_rec.mingc;
      END IF;
      v_loopcounter := v_loopcounter + 1;
    END LOOP;
    CLOSE my_cursor;
    RETURN zhilyq;
  END;
END;
-------

create Procedure saveqicjhpp(qicjhid in number, meikdwm in varchar2
,yunsdwm in varchar2,pinzm in varchar2,diancxxbid in number )
is begin
    declare
    jhid number;
    mkid number;
    pzid number;
    ysdwid number;
    begin
         select nvl(min(q.id),0) into jhid from qicjhppb q where meikdwmc = meikdwm
         and yunsdw = yunsdwm and pinz = pinzm and diancxxb_id = diancxxbid;
         select meikxxb_id,pinz_id,yunsdwb_id into mkid,pzid,ysdwid
         from qicrjhb where id = qicjhid;
         if jhid = 0 then
            insert into qicjhppb(id,diancxxb_id,meikxxb_id,pinzb_id,yunsdwb_id,meikdwmc,pinz,yunsdw)
            values(getnewid(diancxxbid),diancxxbid,mkid,pzid,ysdwid,meikdwm,pinzm,yunsdwm);
          else
             update qicjhppb set meikxxb_id = mkid,pinzb_id = pzid,yunsdwb_id= ysdwid
             where id = jhid;
          end if;
    end;
end;

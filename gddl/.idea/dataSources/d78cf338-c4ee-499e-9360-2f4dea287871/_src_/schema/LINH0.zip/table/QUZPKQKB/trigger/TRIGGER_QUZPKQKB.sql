create trigger TRIGGER_QUZPKQKB
	before insert or update or delete
	on QUZPKQKB
	for each row
Begin

     if inserting then
          AddInterfaceTask ('quzpkb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);

     elsif deleting then
          AddInterfaceTask ('quzpkb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);

     elsif updating then

           if :new.riq<>:old.riq or
              :new.quz18<>:old.quz18 or
              :new.paik18<>:old.paik18 or
              :new.daix18<>:old.daix18 or
              :new.zhanc18<>:old.zhanc18 or
              :new.quz6<>:old.quz6 or
              :new.paik6<>:old.paik6 or
              :new.daix6<>:old.daix6 or
              :new.zhanc6<>:old.zhanc6 or
              :new.changtsj<>:old.changtsj
            then
              AddInterfaceTask ('quzpkb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
           end if ;
     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_quzpkqkb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_quzpkqkb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_quzpkqkb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
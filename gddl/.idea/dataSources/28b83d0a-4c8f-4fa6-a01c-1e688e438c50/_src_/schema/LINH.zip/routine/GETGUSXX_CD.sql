create FUNCTION        "GETGUSXX_CD" (Fahb_id in number, colname in varchar2,condt in varchar2)

return varchar2 is

       zhi varchar2(50);

       Result varchar2(50);

begin





     execute immediate ' select to_char('|| colname ||') from guslsb where fahb_id='||Fahb_id||'

                       and rownum=1 '|| condt ||' order by leix desc,id desc ' into zhi;



                         if not (zhi is null)  then



                                Result:= zhi;

                         else

                                Result:='';



                         end if;



  return(Result);

end getGusxx_cd;

 
create function fun_JitName(strdwId in number)
       return varchar2 is strdwmc varchar2(50);
begin

     select zhuguandwmc into strdwmc
          from
             (select w_zhuguandw.*,level as jib,rownum d from w_zhuguandw
                     start with  zhuguandw_id=strdwId
                     connect by prior shangjidw_id=zhuguandw_id
                     order by level desc)
          where jib=2;

  return(strdwmc);
end fun_JitName;

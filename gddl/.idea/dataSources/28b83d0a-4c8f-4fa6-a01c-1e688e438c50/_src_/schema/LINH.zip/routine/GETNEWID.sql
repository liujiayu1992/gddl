create FUNCTION        "GETNEWID" (diancxxbid In Number)
Return  Varchar2 As
Begin
	Declare
		v_newid number(15);
		Begin
			Select xl_xul_id.nextval
      Into v_newid
      From dual;
			Return  diancxxbid || v_newid;
		Exception When Others Then
			Return  -999999;
		End;
End;

 
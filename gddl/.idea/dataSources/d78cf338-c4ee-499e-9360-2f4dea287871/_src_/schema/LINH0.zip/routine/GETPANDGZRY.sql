create FUNCTION getPandgzry (pandgz varchar2,pandrq varchar2) return VARCHAR2 is
begin
    declare
      reny VARCHAR2(4000) :='';
      v_loopcounter integer :=1;
      CURSOR my_cursor IS
        select p.reny as mingc from pandbp p
				where riq = to_date(pandrq,'yyyy-mm-dd')
				and p.gongznr = pandgz;
      my_rec my_cursor%ROWTYPE;
    begin
      OPEN my_cursor;
        LOOP
          FETCH my_cursor INTO my_rec;
            EXIT WHEN my_cursor%NOTFOUND;
            IF v_loopcounter = 1 THEN
              reny := my_rec.mingc;
            ELSE
                reny := reny||'、'||my_rec.mingc;
            END IF;
          v_loopcounter := v_loopcounter + 1;
        END LOOP;
      CLOSE my_cursor;
      RETURN reny;
    END;
END;

create trigger TRIGGER_SHOUHCRBMB
	before insert or update or delete
	on SHOUHCRBMB
	for each row
Begin
     if updating then
          if :new.zhuangt<>:old.zhuangt then
              if :new.zhuangt=1 then--提交
                  AddInterfaceTask ('shouhcrbb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);
              else--回退
                  AddInterfaceTask ('shouhcrbb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);
              end if;
           end if;

           if (:new.FADY<>:old.FADY or
              :new.GONGRY<>:old.GONGRY or
              :new.QITY<>:old.QITY or
              :new.CHUS<>:old.CHUS or
              :new.DIAOC<>:old.DIAOC or
              :new.TIAOZ<>:old.TIAOZ or
              :new.TIAOCL<>:old.TIAOCL or
              :new.SHUIFCTZ<>:old.SHUIFCTZ or
	      :new.YUNS<>:old.YUNS or
	      :new.SHISL<>:old.SHISL or
              :new.KUC<>:old.KUC) and  :old.zhuangt=1 then
              AddInterfaceTask ('shouhcrbb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);

           end if ;
       elsif deleting and :old.zhuangt =1  then
              AddInterfaceTask ('shouhcrbb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);
       elsif inserting and :new.zhuangt =1 then
              AddInterfaceTask ('shouhcrbb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);
     end if;
    exception
        when others then
        if inserting then
           zengjrz('trigger_shouhcrbmb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_shouhcrbmb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_shouhcrbmb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
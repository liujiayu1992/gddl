create view VWFAHGJXX as
select gj.id as fahgjb_id
, dq.id as meikdqb_id--   煤矿地区id      （二级单位）
, dq.meikdqmc        --   煤矿地区名称
, m.id as meikxxb_id --   煤矿信息表id    （三级单位）
, m.meikdwmc         --   煤矿单位名称
, xy.zhi as  hetrl   --   合同热值        （质量要求）
, r.id as ranlpzb_id --   燃料品种表id
, r.pinz             --   燃料品种
, gj.fahb_id         --   发货表id
, gj.hetxxb_id       --   合同信息表id
, gj.diwfrl as yansrl          --   低位发热量      （大卡）
, gj.shoudjhf as yanshf        --   收到基灰分
, gj.ganzwhjhff as yanshff      --   干燥无灰基挥发分
, gj.quansf as yanssf          --   全水分
, 0 as yansl--gj.liuf            --   硫分
, gj.jiag            --   价格            （单价）
, gj.jiag * (select zhi from xitxxb
where duixm ='煤款税率'
and shifsy = 1) as meiksj  --   煤款税价  （单价）
, gj.jij             --   基价            （单价）
, gj.zhixrq          --   执行日期
, gj.yunf            --   运费            （单价）
, gj.yunf * (select zhi
from xitxxb where
duixm ='运费税率'
and shifsy = 1) as  yunfsj --   运费税价        （单价）
, gj.fazzf           --   发站杂费        （单价）
, gj.daozzf          --   到站杂费        （单价）
, gj.kuangyf         --   矿运费          （单价）
, gj.qitzf           --   其它杂费        （单价）
, gj.qiyf            --   汽运费          （单价）
, round((gj.jiag + gj.yunf + gj.fazzf + gj.daozzf +
gj.kuangyf + gj.qitzf + gj.qiyf)*7000/gj.diwfrl,8) as biaomdj   --  标煤单价

from fahgjb gj, fahb f, meikxxb m, meikdqb dq
, hetxxb h, hetzlxyb xy, ranlpzb r,
(select fahb_id, count(*) as ches from chepb where jiesb_id = 0
group by fahb_id ) c
where gj.fahb_id = f.id and f.meikxxb_id = m.id
and m.meikdqb_id = dq.id and gj.hetxxb_id = h.id
and xy.hetxxb_id(+) = h.id and xy.xiangm = 9
and f.ranlpzb_id = r.id and c.fahb_id = f.id
and c.fahb_id = f.id


--select * from fahgjb

--select * from xitxxb where duixm='过衡文件备份目录'


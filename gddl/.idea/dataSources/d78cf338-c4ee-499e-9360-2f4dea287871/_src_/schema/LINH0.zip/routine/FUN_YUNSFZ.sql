create function fun_YUNSFZ
(strfahdwid in number,strfaz in varchar2,riq1 in varchar2,riq2 varchar2)
       return varchar2 is v_faz varchar2(100);
begin
    select distinct y.faz into v_faz
    from yunsjhb y, fahdwb fh 
    where y.fahdwb_id = strfahdwid
    and y.riq >= riq1
    and y.riq <= riq2
    and instr(y.faz,strfaz) > 0 
    and rownum = 1;
    Return v_faz;
    Exception
    When No_Data_Found Then
      Return strfaz;
    When Others Then
      Return strfaz; 
end fun_YUNSFZ;

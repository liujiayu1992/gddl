create FUNCTION        "GETFAHXX4ZL" (zhilbId long)  return varchar2 is
       Result varchar2(2000);
-- 根据质量id 得到发货信息
  begin
      declare
      tmp varchar2(500);
      cursor fah is
          select g.mingc ||'-' || m.mingc || '-' ||
         nvl((SELECT mingc FROM yunsdwb WHERE ID =
           (SELECT MAX(c.yunsdwb_id) FROM chepb c WHERE c.fahb_id=f.id)),'')
          || to_char(f.fahrq,'yyyy-mm-dd') || '发货,' ||
          to_char(f.daohrq,'yyyy-mm-dd') || '到货,车次:' || f.chec ||
          ',车数:' || f.ches
                 from fahb f, gongysb g ,meikxxb m
          where f.zhilb_id = zhilbId
          AND  f.gongysb_id = g.id
          AND f.meikxxb_id=m.id;
      begin
          open fah;
               loop
                     fetch fah into tmp;
                     EXIT when fah%NOTFOUND;
                     if Result is null then
                        Result:=tmp;
                     Else
                        Result:=Result||';'||tmp;
                     end if;
               end loop;
          close fah;
      end;
      if Result is null then
         Result := '';
      end if;
      return(Result);
  end getFahxx4zl;

 
create function GetLiuc_Hjzt(Liucdz_Hjid in number) return varchar2 is
       Result varchar2(2000);
       --得到某一个流程动作的后继状态
begin
       DECLARE
        v_mingc leibztb.mingc%TYPE;
        begin
           select decode(liucztb.leibztb_id,0,'发起',1,'结束',leibztb.mingc) into v_mingc
                  from liucdzb,liucztb,leibztb
                       where liucdzb.liuczthjid=liucztb.id
                             and liucztb.leibztb_id=leibztb.id(+)
                             and liucdzb.id=Liucdz_Hjid and rownum=1;

                  if not (v_mingc is null) then

                     Result:=v_mingc;

                  else
                     Result:='';

                  end if;

                  return Result;
         end;

end;

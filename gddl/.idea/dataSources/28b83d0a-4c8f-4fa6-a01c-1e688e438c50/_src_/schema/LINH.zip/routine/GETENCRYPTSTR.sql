create FUNCTION        "GETENCRYPTSTR" (varPassword in varchar2) return varchar2
 as language java name 'Util.getEncryptStr(java.lang.String) return String';

 
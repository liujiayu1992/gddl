create FUNCTION "FUN_ZONGHRLFRL" (NumFaDBZML number,NumShiYFDML number,NumMiTFDML number)   return number is
  begin
    --NumFaDBZML (24); NumShiYFDML(13); NumMiTFDML (6)'
    begin
        if (NumShiYFDML*2+NumMiTFDML)=0 then
          return 0;
        else
          return round(NumFaDBZML*7000*0.0041816/(NumShiYFDML*2+NumMiTFDML),2);
        end if;
    end;
  end FUN_ZONGHRLFRL;

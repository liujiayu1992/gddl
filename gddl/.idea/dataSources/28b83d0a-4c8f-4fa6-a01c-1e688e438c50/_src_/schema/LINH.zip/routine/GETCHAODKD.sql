create FUNCTION        "GETCHAODKD" (Chepb_Id in long,value1 in varchar2,value2 in varchar2,xiaoscl in varchar2,ChaodOrKuid in varchar2) return number is
  Result number;
  Resvalue number;

begin

   if ChaodOrKuid='CD' then
      execute immediate ' select case when '||value1||'<'||value2||' then '||value2||'-'||value1||' else 0 end  from chepb where id='||Chepb_Id||''
              into Resvalue;

   elsif ChaodOrKuid='KD' then

      execute immediate ' select case when '||value1||'>'||value2||' then '||value2||'-'||value1||' else 0 end  from chepb where id='||Chepb_Id||''
              into Resvalue;
   end if;

       Resvalue:=abs(Resvalue);

       if xiaoscl='舍去' then

          Resvalue:=trunc(Resvalue);

       elsif  xiaoscl='进位' then

          Resvalue:=ceil(Resvalue);

       elsif  xiaoscl='四舍五入' then

          Resvalue:=round_new(Resvalue,0);

       end if;

       if  ChaodOrKuid='CD' then

           Result:=Resvalue;
       elsif  ChaodOrKuid='KD' then

           Result:=-Resvalue;
       end if;

  return(Result);
end getChaodkd;

 
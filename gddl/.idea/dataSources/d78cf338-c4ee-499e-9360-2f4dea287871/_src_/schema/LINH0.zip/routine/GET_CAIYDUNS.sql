create Function Get_CaiyDuns(zhilbid Number,jiesbid Number) Return Number Is
  Result Number(10);
Begin
   Declare
   v_duns chepb.Id%Type;
   Cursor C_chepb Is Select round_new(Sum(c.biaoz),0)+round_new(Sum(c.yingd),0)-round_new(Sum(c.kuid),0) As duns
       From chepb c,fahb f
       Where f.Id = c.Fahb_Id
       And f.Zhilb_Id=zhilbid
       And c.Jiesb_Id=jiesbid;
   Begin
       Open C_chepb;
       Loop
           Fetch C_chepb Into v_duns;
                 If C_chepb%Found Then
                    Result:=v_duns;
                 End If;
                 Exit When C_chepb%Notfound;
           End Loop;
           Close C_chepb;
          Return(Result);
   End;
End Get_CaiyDuns;
create function GetNeir(rizbid number) return varchar2 is
  Result varchar2(8000);
begin
   DECLARE
   neir riznrb.neir%TYPE;
   CURSOR p_neir IS select distinct n.neir from riznrb n where n.rizb_id = rizbid;

   BEGIN
       OPEN p_neir;
       loop
           FETCH p_neir INTO neir;
                 if p_neir%FOUND then
                    Result:=Result||neir;
                 end if;
                 EXIT WHEN p_neir%NOTFOUND;
           end loop;
       CLOSE p_neir;
          return(Result);
   END;
end GetNeir;

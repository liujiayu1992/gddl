create FUNCTION GETCHEPBTMPLOG
Return  Varchar2 As
Begin
  Declare
    v_newid number(15);
    Begin
      Select XL_CHEPBTMP_LOG.nextval
      Into v_newid
      From dual;
      Return  v_newid;
    Exception When Others Then
      Return  -999999;
    End;
End;

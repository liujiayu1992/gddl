create FUNCTION getJiexsbb  return VARCHAR2 is
begin
    declare
      qingk VARCHAR2(500) :='';
      v_loopcounter integer :=1;
      CURSOR my_cursor IS
        select  s.bianh||s.shebmc as mingh, nvl(j.shebzt,' ') AS shebzt,nvl(jianxkssj ,'') as jianxkssj,
        nvl (jianxjssj ,'') as jianxjssj
        from jiexsbb j,shebjccsb s where j.sheb_id = s.id;
      my_rec my_cursor%ROWTYPE;
    begin
      OPEN my_cursor;
        LOOP
          FETCH my_cursor INTO my_rec;
            EXIT WHEN my_cursor%NOTFOUND;
            IF v_loopcounter = 1 THEN
               if my_rec.jianxkssj is not null then
                  qingk := my_rec.mingh||' 状态：'||my_rec.shebzt||' 检修开始时间：'||to_char(my_rec.jianxkssj,'yyyy-mm-dd')||' 检修结束时间：'||to_char(my_rec.jianxjssj,'yyyy-mm-dd');
               else
                   qingk := my_rec.mingh||' 状态：'||my_rec.shebzt;
               end if;

            ELSE
               if my_rec.jianxkssj is not null then
                  qingk := qingk||';'||my_rec.mingh||' 状态：'||my_rec.shebzt||' 检修开始时间：'||to_char(my_rec.jianxkssj,'yyyy-mm-dd')||' 检修结束时间：'||to_char(my_rec.jianxjssj,'yyyy-mm-dd');
               else
                   qingk := qingk||';'||my_rec.mingh||' 状态：'||my_rec.shebzt;
               end if;
            END IF;
         v_loopcounter := v_loopcounter + 1;
        END LOOP;
      CLOSE my_cursor;
      RETURN qingk;
    END;
END;

create view VWSHIHPZDY as
select max(id) id,shihpzb_id, shihpz from shihcptmp
where shihpzb_id <>0 group by shihpzb_id, shihpz

 

create trigger TRIGGER_DIANLRB
	before insert or update or delete
	on DIANLRB
	for each row
Begin
     if inserting then
        if :new.jizh<>'合计'and (:new.gongdl <> 0 or :new.gongrl <> 0 or :new.fadl<>0) then
            AddInterfaceTask ('riscsjb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);
        end if;
        if :new.jizh<>'合计' and :new.jizzk is not null then
            AddInterfaceTask ('jizyxqkb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);
        end if;
     elsif deleting then
        if :old.jizh<>'合计'and (:old.gongdl <> 0 or :old.gongrl <> 0 or :old.fadl<>0) then
          AddInterfaceTask ('riscsjb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);
        end if;
        if :old.jizh<>'合计'and :old.jizzk is not null then
          AddInterfaceTask ('jizyxqkb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);
        end if;
     elsif updating then
           if :new.gongdl<>:old.gongdl or
              :new.fadl<>:old.fadl or
              :new.gongrl<>:old.gongrl or
              :new.jizh<>:old.jizh or
              :new.fadfhl<>:old.fadfhl or
              :new.gongrlv<>:old.gongrlv then
              AddInterfaceTask ('riscsjb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
           end if;
             if  :new.jizh<>:old.jizh or
              :new.jizzk<>:old.jizzk or
              :new.jianxkssj<>:old.jianxkssj or
               :new.jianxjssj<>:old.jianxjssj then
              AddInterfaceTask ('jizyxqkb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
           end if;
     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_dianlrb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_dianlrb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_dianlrb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
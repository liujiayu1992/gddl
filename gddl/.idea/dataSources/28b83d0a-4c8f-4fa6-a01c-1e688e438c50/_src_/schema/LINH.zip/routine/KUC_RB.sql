create FUNCTION        "KUC_RB" (lngDiancxxb_id in number,datDate in date) return number is
  Result number(10,2);
begin
    declare
        dblJingjkc number(10,2);

        begin
           if lngDiancxxb_id=137 or lngDiancxxb_id=138 or lngDiancxxb_id=133 or lngDiancxxb_id=134
              or lngDiancxxb_id=135 or lngDiancxxb_id=136 then
                 select sum(hc.kuc) into dblJingjkc  from shouhcrbb hc
                        where diancxxb_id in(137,138,133,134,135,136)
                        and riq=datDate;
           else
                 select hc.kuc into dblJingjkc  from shouhcrbb hc
                        where diancxxb_id =lngDiancxxb_id
                        and riq=datDate;
           end if;
           return dblJingjkc;
        end;
end Kuc_RB;

 
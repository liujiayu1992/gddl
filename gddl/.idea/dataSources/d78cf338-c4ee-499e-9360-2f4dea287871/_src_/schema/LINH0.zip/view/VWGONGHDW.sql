create view VWGONGHDW as
select id,fahdwb.jianc as gonghdw,fahdwb.quanc  from fahdwb
union
select id,meikdqb.meikdqmc as gonghdw,meikdqb.meikdqqc from  meikdqb


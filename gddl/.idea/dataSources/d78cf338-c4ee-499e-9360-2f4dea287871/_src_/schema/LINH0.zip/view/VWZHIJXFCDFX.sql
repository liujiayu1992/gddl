create view VWZHIJXFCDFX as
select s.nianf,s.yuef,s.changbb_id,s.fahdwb_id,f.jianc,'本月' xiangm,
	round_new(s.hetrz,0) hetrz,round_new(s.rucrz,0) rucrz,
	round_new(s.jiesrz,0) jiesrz,round_new(s.daohl,2) daohl,
	round_new(s.hetrz-s.rucrz,0) hrc,round_new(s.rucrz-s.jiesrz,0) rjc,
	round_new(s.jiescbj,2) jiescbj,
	decode(jiesrz,0,0,round_new(s.jiescbj*s.daohl*(s.rucrz-s.jiesrz)/
	(jiesrz*10000),2)) as yingkkje
	from (select r.nianf,r.yuef,r.changbb_id,r.fahdwb_id,
	(select hetrz from rezwcqkfkb where nianf = r.nianf and yuef = r.yuef
	and fahdwb_id = r.fahdwb_id and changbb_id = r.changbb_id) hetrz,
	(select rucrz from rezwcqkfkb where nianf = r.nianf and yuef = r.yuef
	and fahdwb_id = r.fahdwb_id and changbb_id = r.changbb_id) rucrz,
	(select jiesrz from rezwcqkfkb where nianf = r.nianf and yuef = r.yuef
	and fahdwb_id = r.fahdwb_id and changbb_id = r.changbb_id) jiesrz,
	(select jiescbj from chebjfxb where nianf = r.nianf and yuef = r.yuef
	and fahdwb_id = r.fahdwb_id and changbb_id = r.changbb_id) jiescbj,
	(select daohl from hetlwcqkfkb where nianf = r.nianf and yuef = r.yuef
	and fahdwb_id = r.fahdwb_id and changbb_id = r.changbb_id) daohl
	from rezwcqkfkb r) s,fahdwb f where s.fahdwb_id = f.id union
	select s.nianf,s.yuef,s.changbb_id,fahdwb_id,f.jianc,'累计' xiangm,
	round_new(s.hetrz,0) hetrz,round_new(s.rucrz,0) rucrz,
	round_new(s.jiesrz,0) jiesrz,round_new(s.daohl,2) daohl,
	round_new(s.hetrz-s.rucrz,0) hrc,round_new(s.rucrz-s.jiesrz,0) rjc,
	round_new(s.jiescbj,2) jiescbj,
	decode(jiesrz,0,0,
	round_new(s.jiesrz*s.daohl*(s.rucrz-s.jiesrz)/(jiesrz*10000),2)) as yingkkje
	from (select r.nianf,r.yuef,r.changbb_id,r.fahdwb_id,
	(select decode(sum(h.daohl),0,0,sum(z.hetrz*h.daohl)/sum(h.daohl))
	from rezwcqkfkb z,hetlwcqkfkb h where z.nianf = r.nianf
	and z.yuef <= r.yuef and z.fahdwb_id = r.fahdwb_id and z.changbb_id = r.changbb_id
	and z.nianf = h.nianf and z.yuef = h.yuef and z.fahdwb_id = h.fahdwb_id
	and z.changbb_id = h.changbb_id) hetrz,
	(select decode(sum(h.daohl),0,0,sum(z.rucrz*h.daohl)/sum(h.daohl))
	from rezwcqkfkb z,hetlwcqkfkb h where z.nianf = r.nianf
	and z.yuef <= r.yuef and z.fahdwb_id = r.fahdwb_id and z.changbb_id = r.changbb_id
	and z.nianf = h.nianf and z.yuef = h.yuef and z.fahdwb_id = h.fahdwb_id
	and z.changbb_id = h.changbb_id) rucrz,
	(select decode(sum(h.daohl),0,0,sum(z.jiesrz*h.daohl)/sum(h.daohl))
	from rezwcqkfkb z,hetlwcqkfkb h where z.nianf = r.nianf
	and z.yuef <= r.yuef and z.fahdwb_id = r.fahdwb_id and z.changbb_id = r.changbb_id
	and z.nianf = h.nianf and z.yuef = h.yuef and z.fahdwb_id = h.fahdwb_id
	and z.changbb_id = h.changbb_id) jiesrz,
	(select decode(sum(h.daohl),0,0,sum(c.jiescbj*h.daohl)/sum(h.daohl))
	from chebjfxb c,hetlwcqkfkb h where c.nianf = r.nianf and c.yuef <= r.yuef
	and c.fahdwb_id = r.fahdwb_id and c.changbb_id = r.changbb_id) jiescbj,
	(select sum(daohl) daohl from hetlwcqkfkb where nianf = r.nianf and yuef <= r.yuef
	and fahdwb_id = r.fahdwb_id and changbb_id = r.changbb_id) daohl
  from rezwcqkfkb r ) s,fahdwb f where s.fahdwb_id = f.id


create FUNCTION        "GET_ZHUANGT" (strdiancId In number,strriq In date,stryear In varchar2,strbiaob In varchar2)
  Return  varchar2 as
  begin
    declare
      strzhuangt number;
      dc_jb number;
    begin
      select max(dc.jib) into dc_jb from diancxxb dc where dc.id=strdiancId;
      if strbiaob='yueslb' then
        if dc_jb=3 then
          select min(str.zhuangt) into strzhuangt  from yueslb str,yuetjkjb tj,diancxxb dc
          where str.yuetjkjb_id=tj.id and tj.diancxxb_id=dc.id and dc.id=strdiancId and tj.riq=strriq;
        elsif dc_jb=2 then
          select min(str.zhuangt) into strzhuangt  from yueslb str,yuetjkjb tj,diancxxb dc
          where str.yuetjkjb_id=tj.id and tj.diancxxb_id=dc.id and ( dc.fuid=strdiancId or dc.shangjgsid=strdiancId) and tj.riq=strriq;
        elsif dc_jb=1 then
          select min(str.zhuangt) into strzhuangt  from yueslb str,yuetjkjb tj,diancxxb dc
          where str.yuetjkjb_id=tj.id and tj.diancxxb_id=dc.id  and tj.riq=strriq;
        end if;
      elsif strbiaob='yuezlb' then
        if dc_jb=3 then
          select min(str.zhuangt) into strzhuangt  from yuezlb str,yuetjkjb tj,diancxxb dc
          where str.yuetjkjb_id=tj.id and tj.diancxxb_id=dc.id and dc.id=strdiancId  and tj.riq=strriq;
        elsif dc_jb=2 then
          select min(str.zhuangt) into strzhuangt  from yuezlb str,yuetjkjb tj,diancxxb dc
          where str.yuetjkjb_id=tj.id and tj.diancxxb_id=dc.id and ( dc.fuid=strdiancId or dc.shangjgsid=strdiancId) and tj.riq=strriq;
        elsif dc_jb=1 then
          select min(str.zhuangt) into strzhuangt  from yuezlb str,yuetjkjb tj,diancxxb dc
          where str.yuetjkjb_id=tj.id and tj.diancxxb_id=dc.id and tj.riq=strriq;
        end if;
      elsif strbiaob='yuercbmdj' then
        if dc_jb=3 then
          select min(str.zhuangt) into strzhuangt from yuercbmdj str,yuetjkjb tj,diancxxb dc
          where str.yuetjkjb_id=tj.id and tj.diancxxb_id= dc.id and dc.id=strdiancId and tj.riq=strriq;
        elsif dc_jb=2 then
          select min(str.zhuangt) into strzhuangt from yuercbmdj str,yuetjkjb tj,diancxxb dc
          where str.yuetjkjb_id=tj.id and tj.diancxxb_id= dc.id and ( dc.fuid=strdiancId or dc.shangjgsid=strdiancId) and tj.riq=strriq;
        elsif dc_jb=1 then
          select min(str.zhuangt) into strzhuangt from yuercbmdj str,yuetjkjb tj,diancxxb dc
          where str.yuetjkjb_id=tj.id and tj.diancxxb_id= dc.id and tj.riq=strriq;
        end if;
      elsif  strbiaob='yuejhbb' then
        if dc_jb=3 then
          select min(str.zhuangt) into strzhuangt from yuecgjhb str,diancxxb dc
          where str.diancxxb_id=dc.id and dc.id=strdiancId  and str.riq=strriq;
        elsif dc_jb=2 then
          select min(str.zhuangt) into strzhuangt from yuecgjhb str,diancxxb dc
          where str.diancxxb_id=dc.id and ( dc.fuid=strdiancId or dc.shangjgsid=strdiancId)  and str.riq=strriq;
        elsif dc_jb=1 then
          select min(str.zhuangt) into strzhuangt from yuecgjhb str,diancxxb dc
          where str.diancxxb_id=dc.id  and str.riq=strriq;
        end if;
      elsif  strbiaob='yuezbb' then
        if dc_jb=3 then
          select min(str.zhuangt) into strzhuangt from yuezbb str,diancxxb dc
          where str.diancxxb_id=dc.id and dc.id=strdiancId and str.riq=strriq;
        elsif dc_jb=2 then
          select min(str.zhuangt) into strzhuangt from yuezbb str,diancxxb dc
          where str.diancxxb_id=dc.id and ( dc.fuid=strdiancId or dc.shangjgsid=strdiancId) and str.riq=strriq;
        elsif dc_jb=1 then
          select min(str.zhuangt) into strzhuangt from yuezbb str,diancxxb dc
          where str.diancxxb_id=dc.id  and str.riq=strriq;
        end if;
      elsif  strbiaob='rucycbb' then
        if dc_jb=3 then
          select min(str.zhuangt) into strzhuangt from rucycbb str,diancxxb dc
          where str.diancxxb_id=dc.id and dc.id=strdiancId and str.riq=strriq;
        elsif dc_jb=2 then
          select min(str.zhuangt) into strzhuangt from rucycbb str,diancxxb dc
          where str.diancxxb_id=dc.id and ( dc.fuid=strdiancId or dc.shangjgsid=strdiancId) and str.riq=strriq;
        elsif dc_jb=1 then
          select min(str.zhuangt) into strzhuangt from rucycbb str,diancxxb dc
          where str.diancxxb_id=dc.id  and str.riq=strriq;
        end if;
      elsif strbiaob='yuexqjhh' then
        if dc_jb=3 then
          select min(str.zhuangt) into strzhuangt  from yuexqjhh str,diancxxb dc
          where str.diancxxb_id=dc.id and dc.id=strdiancId  and str.riq=strriq;
        elsif dc_jb=2 then
          select min(str.zhuangt) into strzhuangt  from yuexqjhh str,diancxxb dc
          where str.diancxxb_id=dc.id and ( dc.fuid=strdiancId or dc.shangjgsid=strdiancId)  and str.riq=strriq;
        elsif dc_jb=1 then
          select min(str.zhuangt) into strzhuangt  from yuexqjhh str,diancxxb dc
          where str.diancxxb_id=dc.id and dc.id=strdiancId  and str.riq=strriq;
          select min(str.zhuangt) into strzhuangt  from yuezlb str,yuetjkjb tj,diancxxb dc
          where str.yuetjkjb_id=tj.id and tj.diancxxb_id=dc.id and tj.riq=strriq;
        end if;

      elsif  strbiaob='yueshcyb' then
        if dc_jb=3 then
          select min(str.zhuangt) into strzhuangt from yueshcyb str,diancxxb dc
          where str.diancxxb_id=dc.id and dc.id=strdiancId and str.riq=strriq;
        elsif dc_jb=2 then
          select min(str.zhuangt) into strzhuangt from yueshcyb str,diancxxb dc
          where str.diancxxb_id=dc.id and ( dc.fuid=strdiancId or dc.shangjgsid=strdiancId) and str.riq=strriq;
        elsif dc_jb=1 then
          select min(str.zhuangt) into strzhuangt from yueshcyb str,diancxxb dc
          where str.diancxxb_id=dc.id and str.riq=strriq;
        end if;
      elsif  strbiaob='yueshchjb' then
        if dc_jb=3 then
          select min(str.zhuangt) into strzhuangt from yueshchjb str,diancxxb dc
          where str.diancxxb_id=dc.id and dc.id=strdiancId and str.riq=strriq;
        elsif dc_jb=2 then
          select min(str.zhuangt) into strzhuangt from yueshchjb str,diancxxb dc
          where str.diancxxb_id=dc.id and ( dc.fuid=strdiancId or dc.shangjgsid=strdiancId) and str.riq=strriq;
        elsif dc_jb=1 then
          select min(str.zhuangt) into strzhuangt from yueshchjb str,diancxxb dc
          where str.diancxxb_id=dc.id and str.riq=strriq;
        end if;
      elsif  strbiaob='niandhtzxqkb' then
        if dc_jb=3 then
          select min(str.zhuangt) into strzhuangt from niandhtzxqkb str,diancxxb dc
          where str.diancxxb_id=dc.id and dc.id=strdiancId and str.riq=strriq;
        elsif dc_jb=2 then
          select min(str.zhuangt) into strzhuangt from niandhtzxqkb str,diancxxb dc
          where str.diancxxb_id=dc.id and ( dc.fuid=strdiancId or dc.shangjgsid=strdiancId) and str.riq=strriq;
        elsif dc_jb=1 then
          select min(str.zhuangt) into strzhuangt from niandhtzxqkb str,diancxxb dc
          where str.diancxxb_id=dc.id and str.riq=strriq;
        end if;
      end if;
      dbms_output.put_line(strzhuangt);
      if dc_jb=3 then
        if strzhuangt is null then
          return '未填写';
        elsif strzhuangt=0  then
          return '未上报分公司';
        elsif strzhuangt=1 then
          return '已上报分公司';
        elsif strzhuangt=2 then
          return '已上报集团';
        end if;
      elsif dc_jb=2 then
        if strzhuangt is null then
          return '未上报分公司';
        elsif strzhuangt=0 then
          return '未上报分公司';
        elsif strzhuangt=1 then
          return '未审核';
        elsif strzhuangt=2 then
          return '已审核';
        end if;
      elsif dc_jb=1 then
        if strzhuangt=2 then
          return '已审核';
        elsif strzhuangt is null then
          return '未审核';
        else
          return '未审核';
        end if;
      end if;
    end;
  End;

 
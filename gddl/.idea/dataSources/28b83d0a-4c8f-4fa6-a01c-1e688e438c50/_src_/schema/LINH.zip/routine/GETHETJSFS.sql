create FUNCTION        "GETHETJSFS" (v_hetb_id number)--合同查询用
Return  VARCHAR2 as
begin
     declare
     v_jiesfs VARCHAR2(200);
     begin
          select hetjsfsb.mingc jiesfs
            into v_jiesfs
            from hetjgb, hetjsfsb
            where hetjgb.xiax =(
            select max(xiax)shangx
            from hetjgb,zhibb
            where hetb_id=v_hetb_id and hetjgb.zhibb_id=zhibb.id
            ) and  hetb_id=v_hetb_id and hetjgb.hetjsfsb_id=hetjsfsb.id;
            return v_jiesfs;
     end;
end;

 
create Function getYunsfsbId(strYunsfsName In varchar2)
Return  number as
begin
     declare
     yunsfsbid number;
     begin
     --用max(id) 不用id是防止车站名称重复
     select max(id) into yunsfsbid from yunsfsb y where y.mingc=strYunsfsName;
     return yunsfsbid;
     end;
End;

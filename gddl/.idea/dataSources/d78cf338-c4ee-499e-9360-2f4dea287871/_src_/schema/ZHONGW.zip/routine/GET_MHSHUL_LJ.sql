create function get_mhshul_lj(lngDiancxxb_id in number,datDate in
date,StrZhi in varchar2) return number is
  Result number(10,2);
begin
    declare
        ljslzhi number(10,2);
        begin
          if StrZhi='fadhy' then
             select sum(fadhy) into ljslzhi  from meihyb
                        where diancxxb_id =lngDiancxxb_id
                        and rulrq>=First_day(datDate)
                        and rulrq<=datDate
                        group by diancxxb_id;
          elsif StrZhi='gongrhy' then
               select sum(gongrhy) into ljslzhi  from meihyb
                          where diancxxb_id =lngDiancxxb_id
                          and rulrq>=First_day(datDate)
                          and rulrq<=datDate
                          group by diancxxb_id;
          elsif StrZhi='qity' then
               select sum(qity) into ljslzhi  from meihyb
                          where diancxxb_id =lngDiancxxb_id
                          and rulrq>=First_day(datDate)
                          and rulrq<=datDate
                          group by diancxxb_id;
           end if;
        return ljslzhi;
        Exception
        WHEN NO_DATA_FOUND  THEN
             return  0;
        When Others Then
        Return  0;
End;
end;

create view VWGONGYS as
select gy.id,gy.mingc,gy.xuh ,
       nvl(dgys.id,gy.id) as dqid,
       nvl(dgys.mingc,gy.mingc) as dqmc,
       nvl(dgys.xuh,gy.xuh) as dqxh,
       nvl(s.id,ds.id) as sid,nvl(s.quanc,ds.quanc) as smc,nvl(s.xuh,ds.xuh) as sxh,gy.bianm
 from gongysb gy,gongysb dgys,shengfb s,shengfb ds
       where gy.fuid=dgys.id(+)
       and gy.shengfb_id=s.id(+)
       and dgys.shengfb_id=ds.id(+)


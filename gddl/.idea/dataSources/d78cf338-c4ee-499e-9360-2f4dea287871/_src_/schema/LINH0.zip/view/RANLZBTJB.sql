create view RANLZBTJB as
select nvl(s.zuorkc, 0) qickc,t.biaoz as benyrcyml,t.farl as benyrcmfrl,
       nvl(hy.haoyl, 0) benyhyl,
       t.riq
  from shouhcrbmb s,
       (select guohsj as riq,
               sum(c) as biaoz,
               round_new(sum(c * q) / sum(c) / 0.0041816, 0) as farl
          from (select fahb_id,
                       to_char(guohsj, 'yyyy-mm') as guohsj,
                       round_new(sum(chepb.biaoz), 0) +
                       round_new(sum(chepb.yingd), 0) -
                       round_new(sum(chepb.kuid), 0) as c,
                       round_new(avg(zhilb.farl), 2) as q
                  from chepb, fahb, zhilb
                 where chepb.fahb_id = fahb.id
                   and fahb.zhilb_id = zhilb.id
                 group by fahb_id, to_char(guohsj, 'yyyy-mm')) c
         group by guohsj) t,
       (select sum(h.fadyy + h.gongryy + h.qityy) as haoyl,
               to_char(h.riq, 'yyyy-mm') as riq
          from haoyqkyb h
         where banzh = '合计'
         group by to_char(h.riq, 'yyyy-mm')) hy
 where s.riq(+) = to_date(t.riq || '-01', 'yyyy-mm-dd')
   and t.riq = hy.riq(+)
   order by riq desc


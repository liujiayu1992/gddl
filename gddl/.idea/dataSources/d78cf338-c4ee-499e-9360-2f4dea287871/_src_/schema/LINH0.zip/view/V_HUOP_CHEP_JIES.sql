create view V_HUOP_CHEP_JIES as
Select c.Id As chepb_id,c.tuosbh,c.Kuangftsh,c.cheph,c.daozch,yd.zongje,
  				GET_YUNF(yd.Id ,0,0) As disyf,GET_YUNF(yd.Id ,0,1) As budsyf,
  		yd.Id As yunfdjb_id, yd.ches As ches, c.jiesb_id,
  				q.meikdqmc As meikdq,k.meikdwmc As meikdw,cz.jianc As faz,
  				Decode(f.Yunsfs,'汽运',c.maoz - c.piz - c.yuns,c.biaoz) As biaoz,round_new(round_new(z.farl,2)*1000/4.1816,0) As farl,
  				to_char(c.fahrq,'yyyy-mm-dd') As fahrq,to_char(c.guohsj,'yyyy-mm-dd') As daohrq,yd.yunfl_id
  				From fahb f,zhilb z,meikdqb q,meikxxb k,chezxxb cz,chepb c
  		, yunfdjb yd, danjcpb dc
  		Where f.zhilb_id = z.Id
  		And f.meikxxb_id = k.Id
  		And q.Id = k.meikdqb_id
  		And f.faz_id = cz.Id
  		And f.Id = c.fahb_id
  		And c.Id = dc.chepb_id
  		And yd.Id = dc.yunfdjb_id
      And c.jiesb_id !=0
      With Read Only


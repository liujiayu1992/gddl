create function getTableId(TableName in varchar2, ColName in varchar2, Value in varchar2) return number is

  Result number;



  Resvalue number;

begin

  execute immediate ' select id from '||TableName||' where '||ColName||'='''||Value||''''

         into Resvalue;

         if not (Resvalue is null)  then



            Result:=Resvalue;

         else



            Result:=0;

         end if;

  return(Result);

end getTableId;

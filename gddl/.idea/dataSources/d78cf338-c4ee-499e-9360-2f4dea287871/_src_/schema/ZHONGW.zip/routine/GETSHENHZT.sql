create function getShenhzt(koujid    in number,
                                      diancfuid in varchar2,
                                      dqmc      in varchar2,
                                      fgsmc     in varchar2,
                                      dcmc      in varchar2,
                                      fDate     in date, --riq1
                                      lDate     in date, --riq2
                                      tablename in varchar2,
                                      fenx      in varchar2,
                                      UserJib   in number) return integer is
  rtn integer;
begin
  declare
    sql_stmt  varchar2(1000);
    sql_fenkj varchar2(500);
  begin
    sql_fenkj := ' and dc.id in (select dcid.diancxxb_id' || chr(10) ||
                 '       from (select distinct diancxxb_id' || chr(10) ||
                 '          from yuetjkjb' || chr(10) ||
                 '         where (riq = :fDate or' || chr(10) ||
                 '               riq = :lDate)) dcid,' || chr(10) ||
                 '       diancxxb  dc,' || chr(10) ||
                 '       dianckjmx kjmx' || chr(10) ||
                 ' where dc.id = dcid.diancxxb_id' || chr(10) ||
                 '   and kjmx.diancxxb_id(+) = dc.id' || chr(10) ||
                 '   and kjmx.dianckjb_id =:koujid)';
    if tablename = 'yueslb' then
      --cpi05
      if UserJib = 1 then
        --集团用户
        if dqmc is null and fgsmc is null and dcmc is null then
          --集团
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl, yuetjkjb tj,jihkjb j,vwdianc dc where sl.yuetjkjb_id = tj.id and tj.jihkjb_id=j.id  and tj.diancxxb_id=dc.id and dc.fuid <> -1 and tj.riq >=:fDate and tj.riq <= :lDate and sl.zhuangt <> 2 and sl.fenx=:fenx and dc.id not in(122,1          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using fDate, lDate, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using fDate, lDate, fenx;
          end if;
        elsif dqmc is null and fgsmc is not null and dcmc is null then
          --按分公司统计公司层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl, yuetjkjb tj,jihkjb j,vwdianc dc where sl.yuetjkjb_id = tj.id and tj.jihkjb_id=j.id  and tj.diancxxb_id=dc.id and dc.fuid <> -1 and dc.fgsmc = :fgsmc and  tj.riq >=:fDate and tj.riq <= :lDate  and sl.zhuangt <> 2 and sl.fenx=:fen          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using fgsmc, fDate, lDate, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using fgsmc, fDate, lDate, fenx;
          end if;
        elsif dqmc is not null and fgsmc is null and dcmc is null then
          --按地区统计地区层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl, yuetjkjb tj,jihkjb j,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.yuetjkjb_id = tj.id and tj.jihkjb_id=j.id  and tj.diancxxb_id=dc.id and dc.fuid <> -1 and dq.mingc = :dqmc a          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using dqmc, fDate, lDate, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using dqmc, fDate, lDate, fenx;
          end if;
        else
          if dqmc is not null and fgsmc is null and dcmc is not null then
            --按地区统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl, yuetjkjb tj,jihkjb j,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.yuetjkjb_id = tj.id and tj.jihkjb_id=j.id  and tj.diancxxb_id=dc.id and dc.fuid <> -1 and dc.mingc = :dcmc            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fenx;
          elsif dqmc is null and fgsmc is not null and dcmc is not null then
            --按电厂统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl, yuetjkjb tj,jihkjb j,vwdianc dc where sl.yuetjkjb_id = tj.id and tj.jihkjb_id=j.id  and tj.diancxxb_id=dc.id and dc.fuid <> -1 and dc.mingc = :dcmc and  tj.riq >=:fDate and tj.riq <= :lDate  and sl.zhuangt <> 2 and sl.fenx=:fe            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fenx;
          end if;
        end if;
      elsif Userjib = 2 then
        --公司级用户
        if dqmc is null and fgsmc is null and dcmc is null then
          --总计
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl, yuetjkjb tj,jihkjb j,vwdianc dc where sl.yuetjkjb_id = tj.id and tj.jihkjb_id=j.id  and tj.diancxxb_id=dc.id and dc.fuid <> -1 and dc.fuid=:diancfuid  and  tj.riq >=:fDate and tj.riq <= :lDate  and sl.zhuangt =0 and sl.fenx=:fen          execute immediate sql_stmt
            into rtn
            using diancfuid, fDate, lDate, fenx;
        elsif dqmc is null and fgsmc is not null and dcmc is null then
          --按电厂统计公司层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl, yuetjkjb tj,jihkjb j,vwdianc dc where sl.yuetjkjb_id = tj.id and tj.jihkjb_id=j.id  and tj.diancxxb_id=dc.id and dc.fuid <> -1 and dc.fuid=:diancfuid and dc.fgsmc=:fgsmc and  tj.riq >=:fDate and tj.riq <= :lDate  and sl.zhuangt           execute immediate sql_stmt
            into rtn
            using diancfuid, fgsmc, fDate, lDate, fenx;
        elsif dqmc is not null and fgsmc is null and dcmc is null then
          --按地区统计地区层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl, yuetjkjb tj,jihkjb j,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.yuetjkjb_id = tj.id and tj.jihkjb_id=j.id  and tj.diancxxb_id=dc.id and dc.fuid <> -1 and dc.fuid=:diancfuid          execute immediate sql_stmt
            into rtn
            using diancfuid, dqmc, fDate, lDate, fenx;
        else
          --电厂层
          if dqmc is not null and fgsmc is null and dcmc is not null then
            --按地区统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl, yuetjkjb tj,jihkjb j,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.yuetjkjb_id = tj.id and tj.jihkjb_id=j.id  and tj.diancxxb_id=dc.id and dc.fuid <> -1 and dc.mingc = :dcmc            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fenx;
          else
            if dqmc is null and fgsmc is not null and dcmc is not null then
              --按电厂统计电厂层
              sql_stmt := 'select count(distinct(dc.id)) from ' ||
                          tablename ||
                          ' sl, yuetjkjb tj,jihkjb j,vwdianc dc where sl.yuetjkjb_id = tj.id and tj.jihkjb_id=j.id  and tj.diancxxb_id=dc.id and dc.fuid <> -1 and dc.mingc = :dcmc and  tj.riq >=:fDate and tj.riq <= :lDate  and sl.zhuangt =0 and sl.fenx=:fe              execute immediate sql_stmt
                into rtn
                using dcmc, fDate, lDate, fenx;
            end if;
          end if;
        end if;
      end if;
    elsif tablename = 'yueshchjb' then
      --cpi06
      if UserJib = 1 then
        --集团用户
        if dqmc is null and fgsmc is null and dcmc is null then
          --总计
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuezbb zb,vwdianc dc where sl.diancxxb_id = dc.id and zb.diancxxb_id=dc.id and dc.fuid <> -1 and sl.riq >=:fDate and sl.riq <= :lDate and zb.riq >=:fDate and zb.riq <= :lDate and (sl.zhuangt <> 2 or zb.zhuangt <> 2) and zb.fenx=:          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using fDate, lDate, fDate, lDate, fenx, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using fDate, lDate, fDate, lDate, fenx, fenx;
          end if;
        elsif dqmc is null and fgsmc is not null and dcmc is null then
          --按分公司统计公司层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuezbb zb,vwdianc dc where sl.diancxxb_id = dc.id and zb.diancxxb_id=dc.id and dc.fuid <> -1  and dc.fgsmc=:fgsmc and sl.riq >=:fDate and sl.riq <= :lDate and zb.riq >=:fDate and zb.riq <= :lDate and (sl.zhuangt <> 2 or zb.zhuang          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using fgsmc, fDate, lDate, fDate, lDate, fenx, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using fgsmc, fDate, lDate, fDate, lDate, fenx, fenx;
          end if;
        elsif dqmc is not null and fgsmc is null and dcmc is null then
          --按地区统计地区层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuezbb zb,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.diancxxb_id = dc.id and zb.diancxxb_id=dc.id and dc.fuid <> -1 and dq.mingc=:dqmc and sl.riq >=:fDate and sl.riq <= :lDa          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using dqmc, fDate, lDate, fDate, lDate, fenx, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using dqmc, fDate, lDate, fDate, lDate, fenx, fenx;
          end if;
        else
          --电厂层
          if dqmc is not null and fgsmc is null and dcmc is not null then
            --按地区统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl,yuezbb zb,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.diancxxb_id = dc.id and zb.diancxxb_id=dc.id and dc.fuid <> -1 and dc.mingc=:dcmc and sl.riq >=:fDate and sl.riq <= :l            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fDate, lDate, fenx, fenx;
          else
            if dqmc is null and fgsmc is not null and dcmc is not null then
              --按电厂统计电厂层
              sql_stmt := 'select count(distinct(dc.id)) from ' ||
                          tablename ||
                          ' sl,yuezbb zb,vwdianc dc where sl.diancxxb_id = dc.id and zb.diancxxb_id=dc.id and dc.fuid <> -1  and dc.mingc=:mingc and sl.riq >=:fDate and sl.riq <= :lDate and zb.riq >=:fDate and zb.riq <= :lDate and (sl.zhuangt <> 2 or zb.zh              execute immediate sql_stmt
                into rtn
                using dcmc, fDate, lDate, fDate, lDate, fenx, fenx;
            end if;
          end if;
        end if;
      elsif Userjib = 2 then
        --公司级用户
        if dqmc is null and fgsmc is null and dcmc is null then
          --总计
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuezbb zb,vwdianc dc where sl.diancxxb_id = dc.id and zb.diancxxb_id=dc.id and dc.fuid <> -1 and dc.fuid=:diancfuid and sl.riq >=:fDate and sl.riq <= :lDate and zb.riq >=:fDate and zb.riq <= :lDate and (sl.zhuangt =0 or zb.zhuang          execute immediate sql_stmt
            into rtn
            using diancfuid, fDate, lDate, fDate, lDate, fenx, fenx;
        elsif dqmc is null and fgsmc is not null and dcmc is null then
          --按电厂统计公司层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuezbb zb,vwdianc dc where sl.diancxxb_id = dc.id and zb.diancxxb_id=dc.id and dc.fuid <> -1 and dc.fuid=:diancfuid and dc.fgsmc=:fgsmc and sl.riq >=:fDate and sl.riq <= :lDate and zb.riq >=:fDate and zb.riq <= :lDate and (sl.zhu          execute immediate sql_stmt
            into rtn
            using diancfuid, fgsmc, fDate, lDate, fDate, lDate, fenx, fenx;
        elsif dqmc is not null and fgsmc is null and dcmc is null then
          --按地区统计地区层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuezbb zb,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.diancxxb_id = dc.id and zb.diancxxb_id=dc.id and dc.fuid <> -1 and and dc.fuid=:diancfuid dq.mingc=:dqmc and sl.riq >=:f          execute immediate sql_stmt
            into rtn
            using diancfuid, dqmc, fDate, lDate, fDate, lDate, fenx, fenx;
        else
          if dqmc is not null and fgsmc is null and dcmc is not null then
            --按地区统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl,yuezbb zb,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.diancxxb_id = dc.id and zb.diancxxb_id=dc.id and dc.fuid <> -1 and dc.mingc=:dcmc and sl.riq >=:fDate and sl.riq <= :l            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fDate, lDate, fenx, fenx;
          else
            if dqmc is null and fgsmc is not null and dcmc is not null then
              --按电厂统计电厂层
              sql_stmt := 'select count(distinct(dc.id)) from ' ||
                          tablename ||
                          ' sl,yuezbb zb,vwdianc dc where sl.diancxxb_id = dc.id and zb.diancxxb_id=dc.id and dc.fuid <> -1  and dc.mingc=:mingc and sl.riq >=:fDate and sl.riq <= :lDate and zb.riq >=:fDate and zb.riq <= :lDate and (sl.zhuangt =0 or zb.zhua              execute immediate sql_stmt
                into rtn
                using dcmc, fDate, lDate, fDate, lDate, fenx, fenx;
            end if;
          end if;
        end if;
      end if;
    elsif tablename = 'yueshcyb' then
      --cpi07
      if UserJib = 1 then
        --集团用户
        if dqmc is null and fgsmc is null and dcmc is null then
          --总计
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,vwdianc dc where sl.diancxxb_id = dc.id and dc.fuid <> -1 and sl.riq >=:fDate and sl.riq <= :lDate and sl.zhuangt <> 2 and sl.fenx=:fenx and dc.id not in(122,133,134,135,182,912)';
          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using fDate, lDate, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using fDate, lDate, fenx;
          end if;
        elsif dqmc is null and fgsmc is not null and dcmc is null then
          --按分公司统计公司层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,vwdianc dc where sl.diancxxb_id = dc.id and dc.fuid <> -1 and dc.fgsmc = :fgsmc and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt <> 2 and sl.fenx=:fenx and dc.id not in(122,133,134,135,182,912)';
          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using fgsmc, fDate, lDate, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using fgsmc, fDate, lDate, fenx;
          end if;
        elsif dqmc is not null and fgsmc is null and dcmc is null then
          --按地区统计地区层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.diancxxb_id = dc.id and  dc.fuid <> -1 and dq.mingc=:dqmc and sl.riq >=:fDate and sl.riq <= :lDate and sl.zhuangt <> 2 and sl.fenx          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using dqmc, fDate, lDate, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using dqmc, fDate, lDate, fenx;
          end if;
        else
          --电厂
          if dqmc is not null and fgsmc is null and dcmc is not null then
            --按地区统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.diancxxb_id = dc.id and  dc.fuid <> -1 and dc.mingc=:dcmc and sl.riq >=:fDate and sl.riq <= :lDate and sl.zhuangt <> 2 and sl.fe            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fenx;
          else
            if dqmc is null and fgsmc is not null and dcmc is not null then
              --按电厂统计电厂层
              sql_stmt := 'select count(distinct(dc.id)) from ' ||
                          tablename ||
                          ' sl,vwdianc dc where sl.diancxxb_id = dc.id and dc.fuid <> -1 and dc.mingc = :mingc and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt <> 2 and sl.fenx=:fenx and dc.id not in(122,133,134,135,182,912)';
              execute immediate sql_stmt
                into rtn
                using dcmc, fDate, lDate, fenx;
            end if;
          end if;
        end if;
      elsif Userjib = 2 then
        --公司级用户
        if dqmc is null and fgsmc is null and dcmc is null then
          --总计
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,vwdianc dc where sl.diancxxb_id = dc.id and dc.fuid <> -1 and dc.fuid=:diancfuid and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt =0 and sl.fenx=:fenx and dc.id not in(122,133,134,135,182,912)';
          execute immediate sql_stmt
            into rtn
            using diancfuid, fDate, lDate, fenx;
        elsif dqmc is null and fgsmc is not null and dcmc is null then
          --按电厂统计公司层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,vwdianc dc where sl.diancxxb_id = dc.id and dc.fuid <> -1 and dc.fuid=:diancfuid and dc.fgsmc = :fgsmc and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt =0 and sl.fenx=:fenx and dc.id not in(122,133,134,135,182,912)';
          execute immediate sql_stmt
            into rtn
            using diancfuid, fgsmc, fDate, lDate, fenx;
        elsif dqmc is not null and fgsmc is null and dcmc is null then
          --按地区统计地区层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.diancxxb_id = dc.id and  dc.fuid <> -1 and dc.fuid=:diancfuid and dq.mingc=:dqmc and sl.riq >=:fDate and sl.riq <= :lDate and sl.z          execute immediate sql_stmt
            into rtn
            using diancfuid, dqmc, fDate, lDate, fenx;
        else
          --电厂层
          if dqmc is not null and fgsmc is null and dcmc is not null then
            --按地区统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.diancxxb_id = dc.id and  dc.fuid <> -1 and dc.mingc=:dcmc and sl.riq >=:fDate and sl.riq <= :lDate and sl.zhuangt =0 and sl.fenx            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fenx;
          else
            if dqmc is null and fgsmc is not null and dcmc is not null then
              --按电厂统计电厂层
              sql_stmt := 'select count(distinct(dc.id)) from ' ||
                          tablename ||
                          ' sl,vwdianc dc where sl.diancxxb_id = dc.id and dc.fuid <> -1 and dc.mingc = :mingc and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt =0 and sl.fenx=:fenx and dc.id not in(122,133,134,135,182,912)';
              execute immediate sql_stmt
                into rtn
                using dcmc, fDate, lDate, fenx;
            end if;
          end if;
        end if;
      end if;
    elsif tablename = 'rucycbb' then
      --cpi09
      if UserJib = 1 then
        --集团用户
        if dqmc is null and fgsmc is null and dcmc is null then
          --总计
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,yuezbb zb,vwdianc dc where tj.diancxxb_id=dc.id and zb.diancxxb_id=dc.id and sl.diancxxb_id=dc.id and dc.fuid<>-1 and slb.yuetjkjb_id=tj.id and zl.yuetjkjb_id=slb.yuetjkjb_id and sl.riq>=:fDate an          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx;
          end if;
        elsif dqmc is null and fgsmc is not null and dcmc is null then
          --按分公司统计公司层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,yuezbb zb,vwdianc dc where dc.fgsmc=:fgsmc and tj.diancxxb_id=dc.id and zb.diancxxb_id=dc.id and sl.diancxxb_id=dc.id and dc.fuid<>-1 and slb.yuetjkjb_id=tj.id and zl.yuetjkjb_id=slb.yuetjkjb_id a          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using fgsmc, fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using fgsmc, fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx;
          end if;
        elsif dqmc is not null and fgsmc is null and dcmc is null then
          --按地区统计地区层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,yuezbb zb,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and dq.mingc=:dqmc and tj.diancxxb_id=dc.id and zb.diancxxb_id=dc.id and sl.diancxxb_id=dc.id           if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using dqmc, fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using dqmc, fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx;
          end if;
        else
          --电厂层
          if dqmc is not null and fgsmc is null and dcmc is not null then
            --按地区统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,yuezbb zb,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and dc.mingc=:dcmc and tj.diancxxb_id=dc.id and zb.diancxxb_id=dc.id and sl.diancxxb_id=dc.i            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx;
          else
            if dqmc is null and fgsmc is not null and dcmc is not null then
              --按电厂统计电厂层
              sql_stmt := 'select count(distinct(dc.id)) from ' ||
                          tablename ||
                          ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,yuezbb zb,vwdianc dc where dc.mingc=:mingc and tj.diancxxb_id=dc.id and zb.diancxxb_id=dc.id and sl.diancxxb_id=dc.id and dc.fuid<>-1 and slb.yuetjkjb_id=tj.id and zl.yuetjkjb_id=slb.yuetjkjb_              execute immediate sql_stmt
                into rtn
                using dcmc, fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx;
            end if;
          end if;
        end if;
      elsif Userjib = 2 then
        --公司级用户
        if dqmc is null and fgsmc is null and dcmc is null then
          --总计
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,yuezbb zb,vwdianc dc where dc.fuid=:diancfuid and tj.diancxxb_id=dc.id and zb.diancxxb_id=dc.id and sl.diancxxb_id=dc.id and dc.fuid<>-1 and slb.yuetjkjb_id=tj.id and zl.yuetjkjb_id=slb.yuetjkjb_i          execute immediate sql_stmt
            into rtn
            using diancfuid, fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx;
        elsif dqmc is null and fgsmc is not null and dcmc is null then
          --按电厂统计公司层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,yuezbb zb,vwdianc dc where dc.fuid=:diancfuid and dc.fgsmc=:fgsmc and tj.diancxxb_id=dc.id and zb.diancxxb_id=dc.id and sl.diancxxb_id=dc.id and dc.fuid<>-1 and slb.yuetjkjb_id=tj.id and zl.yuetjk          execute immediate sql_stmt
            into rtn
            using diancfuid, fgsmc, fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx;
        elsif dqmc is not null and fgsmc is null and dcmc is null then
          --按地区统计地区层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,yuezbb zb,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and dc.fuid=:diancfuid and dq.mingc=:dqmc and tj.diancxxb_id=dc.id and zb.diancxxb_id=dc.id an          execute immediate sql_stmt
            into rtn
            using diancfuid, dqmc, fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx;
        else
          --电厂层
          if dqmc is not null and fgsmc is null and dcmc is not null then
            --按地区统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,yuezbb zb,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and dc.mingc=:dcmc and tj.diancxxb_id=dc.id and zb.diancxxb_id=dc.id and sl.diancxxb_id=dc.i
            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx;
          else
            if dqmc is null and fgsmc is not null and dcmc is not null then
              --按电厂统计电厂层
              sql_stmt := 'select count(distinct(dc.id)) from ' ||
                          tablename ||
                          ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,yuezbb zb,vwdianc dc where dc.mingc=:mingc and tj.diancxxb_id=dc.id and zb.diancxxb_id=dc.id and sl.diancxxb_id=dc.id and dc.fuid<>-1 and slb.yuetjkjb_id=tj.id and zl.yuetjkjb_id=slb.yuetjkjb_              execute immediate sql_stmt
                into rtn
                using dcmc, fDate, lDate, fDate, lDate, fDate, lDate, fenx, fenx, fenx;
            end if;
          end if;
        end if;
      end if;
    elsif tablename = 'yuercbmdj' then
      --cpi10
      if UserJib = 1 then
        --集团用户
        if dqmc is null and fgsmc is null and dcmc is null then
          --总计
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,rucycbb rcy,vwdianc dc where tj.diancxxb_id = dc.id and rcy.diancxxb_id=dc.id and sl.yuetjkjb_id = tj.id and slb.yuetjkjb_id = tj.id and zl.yuetjkjb_id = tj.id and dc.fuid <> -1 and tj.riq >=:fDat          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using fDate, lDate, fDate, lDate, fenx, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using fDate, lDate, fDate, lDate, fenx, fenx;
          end if;
        elsif dqmc is null and fgsmc is not null and dcmc is null then
          --按分公司统计公司层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,rucycbb rcy,vwdianc dc where tj.diancxxb_id = dc.id and rcy.diancxxb_id=dc.id and sl.yuetjkjb_id = tj.id and slb.yuetjkjb_id = tj.id and zl.yuetjkjb_id = tj.id and dc.fuid <> -1 and dc.fgsmc = :fg          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using fgsmc, fDate, lDate, fDate, lDate, fenx, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using fgsmc, fDate, lDate, fDate, lDate, fenx, fenx;
          end if;
        elsif dqmc is not null and fgsmc is null and dcmc is null then
          --按地区统计地区层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,rucycbb rcy,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and tj.diancxxb_id = dc.id and rcy.diancxxb_id=dc.id and sl.yuetjkjb_id = tj.id and slb.yuet          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using dqmc, fDate, lDate, fDate, lDate, fenx, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using dqmc, fDate, lDate, fDate, lDate, fenx, fenx;
          end if;
        else
          --电厂层
          if dqmc is null and fgsmc is null and dcmc is not null then
            --按地区统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,rucycbb rcy,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and tj.diancxxb_id = dc.id and rcy.diancxxb_id=dc.id and sl.yuetjkjb_id = tj.id and slb.yu            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fDate, lDate, fenx, fenx;
          else
            if dqmc is null and fgsmc is not null and dcmc is not null then
              --按电厂统计电厂层
              sql_stmt := 'select count(distinct(dc.id)) from ' ||
                          tablename ||
                          ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,rucycbb rcy,vwdianc dc where tj.diancxxb_id = dc.id and rcy.diancxxb_id=dc.id and sl.yuetjkjb_id = tj.id and slb.yuetjkjb_id = tj.id and zl.yuetjkjb_id = tj.id and dc.fuid <> -1 and dc.mingc =              execute immediate sql_stmt
                into rtn
                using dcmc, fDate, lDate, fDate, lDate, fenx, fenx;
            end if;
          end if;
        end if;
      elsif Userjib = 2 then
        --公司级用户
        if dqmc is null and fgsmc is null and dcmc is null then
          --总计
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,rucycbb rcy,vwdianc dc where tj.diancxxb_id = dc.id and rcy.diancxxb_id=dc.id and sl.yuetjkjb_id = tj.id and slb.yuetjkjb_id = tj.id and zl.yuetjkjb_id = tj.id and dc.fuid <> -1 and dc.fuid = :dia          execute immediate sql_stmt
            into rtn
            using diancfuid, fDate, lDate, fDate, lDate, fenx, fenx;
        elsif dqmc is null and fgsmc is not null and dcmc is null then
          --按电厂统计公司层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,rucycbb rcy,vwdianc dc where tj.diancxxb_id = dc.id and rcy.diancxxb_id=dc.id and sl.yuetjkjb_id = tj.id and slb.yuetjkjb_id = tj.id and zl.yuetjkjb_id = tj.id and dc.fuid <> -1 and dc.fuid = :dia          execute immediate sql_stmt
            into rtn
            using diancfuid, fgsmc, fDate, lDate, fDate, lDate, fenx, fenx;
        elsif dqmc is not null and fgsmc is null and dcmc is null then
          --按地区统计地区层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,rucycbb rcy,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and tj.diancxxb_id = dc.id and rcy.diancxxb_id=dc.id and sl.yuetjkjb_id = tj.id and slb.yuet          execute immediate sql_stmt
            into rtn
            using diancfuid, dqmc, fDate, lDate, fDate, lDate, fenx, fenx;
        else
          --电厂层
          if dqmc is null and fgsmc is null and dcmc is not null then
            --按地区统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,rucycbb rcy,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and tj.diancxxb_id = dc.id and rcy.diancxxb_id=dc.id and sl.yuetjkjb_id = tj.id and slb.yu            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fDate, lDate, fenx, fenx;
          else
            if dqmc is null and fgsmc is not null and dcmc is not null then
              --按电厂统计电厂层
              sql_stmt := 'select count(distinct(dc.id)) from ' ||
                          tablename ||
                          ' sl,yuetjkjb tj,yueslb slb,yuezlb zl,rucycbb rcy,vwdianc dc where tj.diancxxb_id = dc.id and rcy.diancxxb_id=dc.id and sl.yuetjkjb_id = tj.id and slb.yuetjkjb_id = tj.id and zl.yuetjkjb_id = tj.id and dc.fuid <> -1 and dc.mingc =              execute immediate sql_stmt
                into rtn
                using dcmc, fDate, lDate, fDate, lDate, fenx, fenx;
            end if;
          end if;
        end if;
      end if;
    elsif tablename = 'yuezbb' then
      --cpi08、cpi11、cpi12
      if UserJib = 1 then
        --集团用户
        if dqmc is null and fgsmc is null and dcmc is null then
          --总计
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,vwdianc dc where sl.diancxxb_id = dc.id and dc.fuid <> -1 and sl.riq >=:fDate and sl.riq <= :lDate and sl.zhuangt <> 2 and sl.fenx=:fenx and dc.id not in(122,133,134,135,182,912)';
          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using fDate, lDate, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using fDate, lDate, fenx;
          end if;
        elsif dqmc is null and fgsmc is not null and dcmc is null then
          --按分公司统计公司层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,vwdianc dc where sl.diancxxb_id = dc.id and dc.fuid <> -1 and dc.fgsmc = :fgsmc and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt <> 2 and sl.fenx=:fenx and dc.id not in(122,133,134,135,182,912)';
          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using fgsmc, fDate, lDate, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using fgsmc, fDate, lDate, fenx;
          end if;
        elsif dqmc is not null and fgsmc is null and dcmc is null then
          --按地区统计地区层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.diancxxb_id = dc.id and dc.fuid <> -1 and dq.mingc = :dqmc and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt <> 2 and sl.fe          if koujid > 0 then
            sql_stmt := sql_stmt || sql_fenkj;
            execute immediate sql_stmt
              into rtn
              using dqmc, fDate, lDate, fenx, fDate, lDate, koujid;
          else
            execute immediate sql_stmt
              into rtn
              using dqmc, fDate, lDate, fenx;
          end if;
        else
          if dqmc is not null and fgsmc is null and dcmc is not null then
            --按地区统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.diancxxb_id = dc.id and dc.fuid <> -1 and dc.mingc = :dcmc and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt <> 2 and sl.            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fenx;
          else
            if dqmc is null and fgsmc is not null and dcmc is not null then
              --按电厂统计电厂层
              sql_stmt := 'select count(distinct(dc.id)) from ' ||
                          tablename ||
                          ' sl,vwdianc dc where sl.diancxxb_id = dc.id and dc.fuid <> -1 and dc.mingc = :dcmc and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt <> 2 and sl.fenx=:fenx and dc.id not in(122,133,134,135,182,912)';
              execute immediate sql_stmt
                into rtn
                using dcmc, fDate, lDate, fenx;
            end if;
          end if;
        end if;
      elsif Userjib = 2 then
        --公司级用户
        if dqmc is null and fgsmc is null and dcmc is null then
          --总计
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,vwdianc dc where sl.diancxxb_id = dc.id and dc.fuid <> -1 and dc.fuid=:diancfuid and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt =0 and sl.fenx=:fenx and dc.id not in(122,133,134,135,182,912)';
          execute immediate sql_stmt
            into rtn
            using diancfuid, fDate, lDate, fenx;
        elsif dqmc is null and fgsmc is not null and dcmc is null then
          --按电厂统计公司层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,vwdianc dc where sl.diancxxb_id = dc.id and dc.fuid <> -1 and dc.fuid=:diancfuid and dc.fgsmc = :fgsmc and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt =0 and sl.fenx=:fenx and dc.id not in(122,133,134,135,182,912)';
          execute immediate sql_stmt
            into rtn
            using diancfuid, fgsmc, fDate, lDate, fenx;
        elsif dqmc is not null and fgsmc is null and dcmc is null then
          --按地区统计地区层
          sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                      ' sl,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.diancxxb_id = dc.id and dc.fuid <> -1 and dq.mingc = :dqmc and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt =0 and sl.fenx          execute immediate sql_stmt
            into rtn
            using dqmc, fDate, lDate, fenx;
        else
          if dqmc is not null and fgsmc is null and dcmc is not null then
            --按地区统计电厂层
            sql_stmt := 'select count(distinct(dc.id)) from ' || tablename ||
                        ' sl,diancxxb dc,shengfb sf,shengfdqb dq where dc.shengfb_id = sf.id and sf.shengfdqb_id = dq.id and sl.diancxxb_id = dc.id and dc.fuid <> -1 and dc.mingc = :dcmc and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt =0 and sl.fe            execute immediate sql_stmt
              into rtn
              using dcmc, fDate, lDate, fenx;
          else
            if dqmc is null and fgsmc is not null and dcmc is not null then
              --按电厂统计电厂层
              sql_stmt := 'select count(distinct(dc.id)) from ' ||
                          tablename ||
                          ' sl,vwdianc dc where sl.diancxxb_id = dc.id and dc.fuid <> -1 and dc.mingc = :dcmc and sl.riq >=:fDate and sl.riq <= :lDate  and sl.zhuangt =0 and sl.fenx=:fenx and dc.id not in(122,133,134,135,182,912)';
              execute immediate sql_stmt
                into rtn
                using dcmc, fDate, lDate, fenx;
            end if;
          end if;
        end if;
      end if;
    end if;
  end;
  return(rtn);
end getShenhzt;

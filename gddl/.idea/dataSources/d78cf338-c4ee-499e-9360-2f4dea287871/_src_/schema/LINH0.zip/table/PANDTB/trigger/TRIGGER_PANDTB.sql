create trigger TRIGGER_PANDTB
	before insert or update or delete
	on PANDTB
	for each row
Declare
      v_path  jiekrwb.minglcs%Type;
Begin
      select zhi into v_path
      from xitxxb
      where duixm='盘点图表目录';
     if inserting then
          AddInterfaceTask ('pandtb',:new.id,0,:new.changbb_id,'xml',:new.id,:new.riq);
          AddInterfaceTask ('pandtb',:new.id,0,:new.changbb_id,'file',v_path||'\'||:new.fuj,:new.riq);

     elsif deleting then
          AddInterfaceTask ('pandtb',:old.id,1,:old.changbb_id,'xml',:old.id,:old.riq);
          AddInterfaceTask ('pandtb',:old.id,1,:old.changbb_id,'file',v_path||'\'||:old.fuj,:old.riq);
     elsif updating then
          if :new.fuj<>:old.fuj then
           AddInterfaceTask ('pandtb',:new.id,2,:new.changbb_id,'xml',:new.id,:new.riq);
           AddInterfaceTask ('pandtb',:new.id,2,:new.changbb_id,'file',v_path||'\'||:new.fuj,:new.riq);
          end if;
     end if;
     exception
     when others then
        if inserting then
           zengjrz('trigger_pandtb',:new.id,'增加',SQLCODE,SQLERRM);
        elsif deleting  then
           zengjrz('trigger_pandtb',:old.id,'删除',SQLCODE,SQLERRM);
        else
           zengjrz('trigger_pandtb',:old.id,'修改',SQLCODE,SQLERRM);
        end if;
End;
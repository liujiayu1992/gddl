create Function getMiekdw (in_tuosbh Varchar2) Return Varchar2 Is
--得到结算指标中的煤矿单位
Begin
    Declare
      meikdw  Varchar2(4000) :='';
      v_loopcounter Integer :=1;
      v_meikdw Varchar2(200) :='';
      Cursor my_cursor Is
       select  Distinct m.meikdwmc
       From chepb c, fahb f, meikxxb m
       Where     c.fahb_id = f.Id
       and f.meikxxb_id = m.Id
       and c.tuosbh = in_tuosbh;
      my_rec my_cursor%Rowtype;
    Begin
      Open my_cursor;
        Loop
          Fetch my_cursor Into my_rec;
            Exit When my_cursor%Notfound;
            If v_loopcounter = 1 Then
              v_meikdw := my_rec.meikdwmc;
              meikdw := v_meikdw;
            Else
                meikdw := meikdw||','||my_rec.meikdwmc;
            End If;
          v_loopcounter := v_loopcounter + 1;
        End Loop;
      Close my_cursor;
      Return meikdw;
    End;
End;

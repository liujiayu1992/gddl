create FUNCTION getNeirsAll (hetxxbid number) return VARCHAR2 is
begin
    declare
      wenbs VARCHAR2(10000) :='';
      mingcPre VARCHAR2(200):='';
      xuh number:=1;
     CURSOR my_cursor IS select mingc,neir  from hettkmxb h
            where h.hetxxb_id=hetxxbid
            order by zhuxuh,xuh;
      my_rec my_cursor%ROWTYPE;
    begin
      OPEN my_cursor;
           loop
                FETCH my_cursor INTO my_rec;
                   exit when  my_cursor%NOTFOUND ;
                   if my_rec.mingc<>mingcPre or  mingcPre is null  then
                     if xuh=1 then
                        wenbs := xuh||','||my_rec.mingc||my_rec.neir||';';
                     else
                        wenbs := wenbs ||'<br>'||xuh||','||my_rec.mingc||my_rec.neir||';';
                     end if;
                     xuh:=xuh+1;
                     mingcPre:= my_rec.mingc;
                else
                    wenbs := wenbs ||my_rec.neir||';';
                end if;
           end loop;
      CLOSE my_cursor;
      RETURN wenbs;
    END;
END;
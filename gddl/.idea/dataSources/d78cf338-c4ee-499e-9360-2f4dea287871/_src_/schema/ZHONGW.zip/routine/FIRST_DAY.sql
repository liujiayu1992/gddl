create function First_day(datDate in date) return date is
begin
  return  add_months(last_day(datDate),-1)+1;
end First_day;

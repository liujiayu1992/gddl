create procedure UpdateMimName(aviNAME in varchar2, varmim varchar2) AS
      numof    number(7);
      blob_loc blob;
    BEGIN

      update renyxxb set mim = empty_blob() where mingc = aviNAME;

      SELECT mim
        INTO blob_loc --   获取定位器并锁定行
        FROM renyxxb
       WHERE mingc = aviNAME
         FOR UPDATE;

      numof := LENGTHB(varmim);
      dbms_lob.write(blob_loc, numof, 1, UTL_RAW.cast_to_raw(varmim));

      COMMIT;
    END;

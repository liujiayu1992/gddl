create view VWHETL as
select n.hetxxb_id,n.meiz,to_char(h.qissj,'YYYY')||'-01' as riq,n.y1 hetl from nianjhhtb n,hetxxb h
where n.hetxxb_id=h.id
union
select n.hetxxb_id,n.meiz,to_char(h.qissj,'YYYY')||'-02' as riq,n.y2 hetl from nianjhhtb n,hetxxb h
where n.hetxxb_id=h.id
union
select n.hetxxb_id,n.meiz,to_char(h.qissj,'YYYY')||'-03' as riq,n.y3 hetl from nianjhhtb n,hetxxb h
where n.hetxxb_id=h.id
union
select n.hetxxb_id,n.meiz,to_char(h.qissj,'YYYY')||'-04' as riq,n.y4 hetl from nianjhhtb n,hetxxb h
where n.hetxxb_id=h.id
union
select n.hetxxb_id,n.meiz,to_char(h.qissj,'YYYY')||'-05' as riq,n.y5 hetl from nianjhhtb n,hetxxb h
where n.hetxxb_id=h.id
union
select n.hetxxb_id,n.meiz,to_char(h.qissj,'YYYY')||'-06' as riq,n.y6 hetl from nianjhhtb n,hetxxb h
where n.hetxxb_id=h.id
union
select n.hetxxb_id,n.meiz,to_char(h.qissj,'YYYY')||'-07' as riq,n.y7 hetl from nianjhhtb n,hetxxb h
where n.hetxxb_id=h.id
union
select n.hetxxb_id,n.meiz,to_char(h.qissj,'YYYY')||'-08' as riq,n.y8 hetl from nianjhhtb n,hetxxb h
where n.hetxxb_id=h.id
union
select n.hetxxb_id,n.meiz,to_char(h.qissj,'YYYY')||'-09' as riq,n.y9 hetl from nianjhhtb n,hetxxb h
where n.hetxxb_id=h.id
union
select n.hetxxb_id,n.meiz,to_char(h.qissj,'YYYY')||'-10' as riq,n.y10 hetl from nianjhhtb n,hetxxb h
where n.hetxxb_id=h.id
union
select n.hetxxb_id,n.meiz,to_char(h.qissj,'YYYY')||'-11' as riq,n.y11 hetl from nianjhhtb n,hetxxb h
where n.hetxxb_id=h.id
union
select n.hetxxb_id,n.meiz,to_char(h.qissj,'YYYY')||'-12' as riq,n.y12 hetl from nianjhhtb n,hetxxb h
where n.hetxxb_id=h.id


create FUNCTION getHuayFhrq4zl(zhilbId long)  return varchar2 is
       Result varchar2(2000);
-- 根据质量id 得到发货信息
  begin
      declare
      tmp varchar2(500);
      cursor fah is
          select distinct to_char(f.fahrq,'yyyy-mm-dd') fahrq
                 from fahb f
          where f.zhilb_id = zhilbId ;
      begin
          open fah;
               loop
                     fetch fah into tmp;
                     EXIT when fah%NOTFOUND;
                     if Result is null then
                        Result:=tmp;
                     Else
                        Result:=Result||','||tmp;
                     end if;
               end loop;
          close fah;
      end;
      if Result is null then
         Result := '';
      end if;
      return(Result);
  end getHuayFhrq4zl;

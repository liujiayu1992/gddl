create view V_JIESZBB as
Select j.Id,
       j.Tuosbh,
       CASE WHEN j.Farl<100 THEN j.Farl ELSE ROUND_NEW(j.Farl*0.0041816,2) END AS FARL,
       CASE WHEN j.Farl>=100 THEN j.Farl ELSE ROUND_NEW(j.Farl/0.0041816,0) END AS QNET,
       j.Quansf As Mt,
       j.Kongqgzjsf As Mad,
       j.Shoudjhf As Aar,
       j.Ganzjhf As Ad,
       j.Kongqgzjhf As Aad,
       j.Shoudjhff As Var,
       j.Kongqgzjhff As Vad,
       j.Huiff As Vdaf,
       j.Star,
       j.Liuf As Stad,
       j.Ganzjl As Std,
       j.Shifks,
       j.meijb_id
  From Jieszbb j
 WITH READ Only

create FUNCTION        "KEYTS_RB" (lngDiancxxb_id in number,datRiq date) return varchar2 is
begin
    declare
        dblKeytszc number(10,2);
        dblKeytshj number(10,2);
        begin
              --上海电力的几个厂共用一个库存计算可用天数
              if lngDiancxxb_id=137 or lngDiancxxb_id=138 or lngDiancxxb_id=133 or lngDiancxxb_id=134 or lngDiancxxb_id=135 or lngDiancxxb_id=136 then
                  select decode(rijhm,0,0,round(nvl(kuc,0)/(rijhm),1))  into dblKeytshj
                    from
                     (select sum(kuc) as kuc,sum(keyts_rijhm(lngDiancxxb_id,haoyqkdr,datriq)) as rijhm from shouhcrbb
                            where riq=datRiq
                            and diancxxb_id in(137,138,133,134,135,136)) rb;
                           if dblKeytszc>100 then ----判断可用天数>100，显示''
                               return '';
                          else
                               return dblKeytshj;
                          end if;
               else
                  select decode(rijhm,0,0,round(nvl(kuc,0)/(rijhm),1)) into  dblKeytszc
                      from
                         (select kuc,keyts_rijhm(lngDiancxxb_id,rb.haoyqkdr,datriq) as rijhm
                             from shouhcrbb rb
                             where riq=datRiq
                             and diancxxb_id=lngDiancxxb_id);
                        if dblKeytszc>100 then ----判断可用天数>100，显示''
                            return '';
                        else
                            return dblKeytszc;
                       end if;
                  end if;

        end;
end keyts_rb;

 
create PROCEDURE        "CREATEDEFAULTUSER" (lngDiancxxb_id number,lngJib number,strPy varchar2) is
begin
     declare
       blnHasZu boolean;
       blnHasUser boolean;
       lngZuxxb_id number;
       lngRenyxxb_id number;
       cursor c_z is select id from zuxxb  where mingc='admin';
       cursor c_u is select id from renyxxb where diancxxb_id=lngDiancxxb_id;
       begin
           blnHasUser:=false;
           blnHasZu:=false;
            open c_u;
                 loop
                     fetch c_u into lngRenyxxb_id;
                           exit when c_u%notfound;
                           blnHasUser:=true;
                 end loop;
            close c_u;

            open c_z;
                 loop
                     fetch  c_z into lngZuxxb_id;
                            exit when c_z%notfound;
                            blnHasZu:=true;
                 end loop;
            close c_z;

            if not blnHasZu then
               --创建组
               select xl_xul_id.nextval into lngZuxxb_id from dual;
               insert into zuxxb values( lngZuxxb_id,'admin','管理员',lngdiancxxb_id);

               --增加权限管理资源，日报维护资源
               if lngJib=1 then

                 insert into zuqxb values( xl_xul_id.nextval,lngZuxxb_id,51);
                 insert into zuqxb values( xl_xul_id.nextval,lngZuxxb_id,5105);
                 insert into zuqxb values( xl_xul_id.nextval,lngZuxxb_id,5103);
                 insert into zuqxb values( xl_xul_id.nextval,lngZuxxb_id,5104);

                 insert into zuqxb values( xl_xul_id.nextval,lngZuxxb_id,510303);
                 insert into zuqxb values( xl_xul_id.nextval,lngZuxxb_id,510304);

                 insert into zuqxb values( xl_xul_id.nextval,lngZuxxb_id,510503);
                 insert into zuqxb values( xl_xul_id.nextval,lngZuxxb_id,510504);


               end if;

       
            end if;

            if not blnHasUser then
               --创建用户,用电厂id 作为电厂的用户
               select xl_xul_id.nextval into lngRenyxxb_id from dual;
               insert into renyxxb (id,MINGC,mim,diancxxb_id,zhuangt)
                      values(lngRenyxxb_id,lngDiancxxb_id,(select mim from renyxxb where id=2014339),lngDiancxxb_id,1);

               --绑定用户和组
               insert into renyzqxb(id,renyxxb_id,zuxxb_id)
                      values(xl_xul_id.nextval,lngRenyxxb_id,lngZuxxb_id);
            end if;


       end;
end createDefaultUser;

 
create FUNCTION getYub (rq date) return VARCHAR2 is
begin
    declare
           strJu varchar2(50);
           qingk VARCHAR2(500) :='';
           v_loopcounter integer :=1;
      CURSOR my_cursor IS
             select  banjh||'次'||l.mingc as ju, c.jianc,  ches
             from tielybb t,lujxxb l,chezxxb c
             Where t.chezxxb_id = c.id (+)
                    and c.lujxxb_id = l.id(+)
                    And  riq=rq
             order by banjh||'次'||l.mingc, c.jianc;
      my_rec my_cursor%ROWTYPE;
    begin
      strJu:='';
      OPEN my_cursor;
        LOOP
          FETCH my_cursor INTO my_rec;
            EXIT WHEN my_cursor%NOTFOUND;
            if strJu<>my_rec.ju or strJu is null  then
               if strJu is null then
                   qingk:=my_rec.ju;
               else
                   qingk:=qingk||my_rec.ju ;
               end if;

               v_loopcounter:=1;
               strJu:=my_rec.ju;
            end if;

            if v_loopcounter<>1 then
               qingk:=qingk||'; ';
            end if;
             qingk:=qingk||my_rec.jianc||''||my_rec.ches||'车    ';
             v_loopcounter:=v_loopcounter+1;
        END LOOP;
      CLOSE my_cursor;
      RETURN qingk;
    END;
END;

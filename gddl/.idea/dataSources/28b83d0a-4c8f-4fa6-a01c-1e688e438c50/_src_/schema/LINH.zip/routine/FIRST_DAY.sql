create FUNCTION        "FIRST_DAY" (datDate in date) return date is
begin
  return  add_months(last_day(datDate),-1)+1;
end First_day;

 
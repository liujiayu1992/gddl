create view VWRUCMTJ as
select a.daohrq,a.farl,a.vdaf,a.aar,sum(a.meitlml) as meitlml,
sum(b.meitlmltg) as  meitlmltg,
sum(b.meitlmlzg) as meitlmlzg
from
(select  f.daohrq,sum(f.biaoz) as meitlml,
      round_new( sum(z.qnet_ar * f.biaoz) / sum(f.biaoz),2) as farl,
       round_new(sum(z.vdaf * f.biaoz) / sum(f.biaoz),2) as vdaf,
       round_new(sum(z.aar * f.biaoz) / sum(f.biaoz),2) as aar
  from fahb f, zhillsb z
 where f.zhilb_id = z.zhilb_id(+)
 group by f.daohrq
order by f.daohrq) a,
(select f.daohrq,sum(decode(f.jihkjb_id,1,f.biaoz,0))as meitlmltg,
sum(decode(f.jihkjb_id,1,0,f.biaoz)) as meitlmlzg
 from fahb f group by f.daohrq) b
where a.daohrq=b.daohrq(+)
group by a.daohrq,a.farl,a.vdaf,a.aar
order by a.daohrq

 
